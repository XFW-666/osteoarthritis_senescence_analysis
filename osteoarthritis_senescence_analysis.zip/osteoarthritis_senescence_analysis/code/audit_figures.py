"""
audit_figures.py — regenerate every matplotlib figure and run all three gates on it,
including the new full-text audit.  Figure 1 is a raster composite (no artists to query),
so it is reported separately.
"""
import os, sys, traceback
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

import viz_style
from viz_style import qa_layout, qa_axes, qa_full

captured = {}


def cap(fig, path, *a, **k):
    # mirror what viz_style.save actually does before auditing, otherwise the audit measures
    # a figure the real build never produces
    try:
        viz_style.thin_ticks_auto(fig)
    except Exception as e:
        print("   thinning failed:", type(e).__name__, str(e)[:60])
    captured[os.path.basename(path)] = fig


_orig_save = viz_style.save
viz_style.save = cap

import step5_figures as S
import step13_figures_causal as C9
import step23_figure10 as F10
S.save = cap
C9.save = cap
F10.save = cap

builders = [("Fig2", S.figure2), ("Fig3", S.figure3), ("Fig4", S.figure4),
            ("Fig5", S.figure5), ("Fig6", S.figure6), ("Fig7", S.figure7),
            ("Fig8", S.figure8), ("Fig9", C9.figure9), ("Fig10", F10.figure10)]

for tag, fn in builders:
    try:
        fn()
    except Exception as e:
        print(f"!! {tag} failed to build: {type(e).__name__}: {e}")
        traceback.print_exc()

viz_style.save = _orig_save
S.save = C9.save = F10.save = _orig_save

print("\n" + "=" * 100)
print("FULL FIGURE AUDIT  (text-vs-text on ALL text artists, clipping, legend-covers-data)")
print("=" * 100)
grand = 0
for name, fig in captured.items():
    try:
        i1 = qa_layout(fig, name=name, verbose=False)
        i2 = qa_axes(fig, name=name, verbose=False)
        i3, notes = qa_full(fig, name=name, verbose=False)
    except Exception as e:
        print(f"{name}: audit error {type(e).__name__}: {e}")
        continue
    all_iss = i1 + i2 + i3
    grand += len(all_iss)
    print(f"\n{name}: {'CLEAN' if not all_iss else str(len(all_iss)) + ' PROBLEM(S)'}"
          f"   [layout {len(i1)}, axes {len(i2)}, text/data {len(i3)}]")
    for s in all_iss[:20]:
        print("     *", s)
    for s in notes[:5]:
        print("     ~", s)
    plt.close(fig)

print("\n" + "=" * 100)
print(f"TOTAL problems across {len(captured)} figures: {grand}")
print("Figure1_conceptual_framework.png is a raster composite built by figure1_panels.py;")
print("it has no matplotlib artists, so it cannot be audited this way.")
