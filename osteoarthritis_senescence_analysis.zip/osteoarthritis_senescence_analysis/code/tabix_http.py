"""
tabix_http.py — minimal tabix-over-HTTP reader for bgzipped remote files.

Lets us pull only the genomic regions we need out of a multi-hundred-megabyte
summary-statistics file, using the accompanying .tbi index and HTTP range requests.
"""
import os, gzip, zlib, struct, ssl, json, time
import urllib.request

CTX = ssl.create_default_context()
UA = {"User-Agent": "Mozilla/5.0"}


def _http_range(url, start, end, tries=4, timeout=180):
    """Fetch bytes [start, end) from url.  An end past EOF is clamped by the server contract
    only if we ask open-ended, so callers must clamp against the known file size."""
    for a in range(tries):
        try:
            req = urllib.request.Request(url, headers={**UA, "Range": f"bytes={start}-{end - 1}"})
            with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 416:
                # range beyond EOF: retry open-ended and truncate
                try:
                    req = urllib.request.Request(url, headers={**UA, "Range": f"bytes={start}-"})
                    with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
                        return r.read(max(0, end - start))
                except Exception:
                    return b""
            if a == tries - 1:
                raise
            time.sleep(2)
        except Exception:
            if a == tries - 1:
                raise
            time.sleep(2)
    return b""


def _content_length(url, tries=3):
    for a in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA, method="HEAD")
            with urllib.request.urlopen(req, timeout=60, context=CTX) as r:
                return int(r.headers.get("Content-Length") or 0)
        except Exception:
            time.sleep(1)
    return 0


def download(url, dest, chunk=1 << 20):
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=600, context=CTX) as r, \
            open(tmp, "wb") as f:
        while True:
            b = r.read(chunk)
            if not b:
                break
            f.write(b)
    os.replace(tmp, dest)
    return dest


def bgzf_decompress(data):
    """Decompress a concatenated BGZF stream, tolerating a truncated final block."""
    out = []
    i = 0
    n = len(data)
    while i + 18 <= n:
        if data[i:i + 2] != b"\x1f\x8b":
            break
        xlen = int.from_bytes(data[i + 10:i + 12], "little")
        extra = data[i + 12:i + 12 + xlen]
        bsize = None
        j = 0
        while j + 4 <= len(extra):
            si1, si2 = extra[j], extra[j + 1]
            slen = int.from_bytes(extra[j + 2:j + 4], "little")
            if si1 == 66 and si2 == 67 and slen == 2:
                bsize = int.from_bytes(extra[j + 4:j + 6], "little") + 1
                break
            j += 4 + slen
        if bsize is None or i + bsize > n:
            break
        cdata = data[i + 12 + xlen:i + bsize - 8]
        try:
            out.append(zlib.decompress(cdata, -15))
        except Exception:
            pass
        i += bsize
    return b"".join(out)


def parse_tbi(path):
    raw = gzip.open(path, "rb").read()
    if raw[:4] != b"TBI\x01":
        raise ValueError("not a tabix index")
    p = 4
    n_ref = struct.unpack("<i", raw[p:p + 4])[0]; p += 4
    fmt, col_seq, col_beg, col_end, meta, skip, l_nm = struct.unpack("<7i", raw[p:p + 28]); p += 28
    names = raw[p:p + l_nm].split(b"\x00"); p += l_nm
    refs = {}
    for k in range(n_ref):
        n_bin = struct.unpack("<i", raw[p:p + 4])[0]; p += 4
        bins = {}
        for _ in range(n_bin):
            bin_id = struct.unpack("<I", raw[p:p + 4])[0]; p += 4
            n_chunk = struct.unpack("<i", raw[p:p + 4])[0]; p += 4
            ch = []
            for _ in range(n_chunk):
                cbeg = struct.unpack("<Q", raw[p:p + 8])[0]; p += 8
                cend = struct.unpack("<Q", raw[p:p + 8])[0]; p += 8
                ch.append((cbeg, cend))
            bins[bin_id] = ch
        n_intv = struct.unpack("<i", raw[p:p + 4])[0]; p += 4
        lin = [struct.unpack("<Q", raw[p + 8 * i:p + 8 * i + 8])[0] for i in range(n_intv)]
        p += 8 * n_intv
        refs[names[k].decode()] = {"bins": bins, "linear": lin}
    return {"names": [x.decode() for x in names if x], "refs": refs,
            "col_seq": col_seq, "col_beg": col_beg, "col_end": col_end, "meta": meta}


def _reg2bins(beg, end):
    end -= 1
    out = [0]
    out += list(range(1 + (beg >> 26), 1 + (end >> 26) + 1))
    out += list(range(9 + (beg >> 23), 9 + (end >> 23) + 1))
    out += list(range(73 + (beg >> 20), 73 + (end >> 20) + 1))
    out += list(range(585 + (beg >> 17), 585 + (end >> 17) + 1))
    out += list(range(4681 + (beg >> 14), 4681 + (end >> 14) + 1))
    return out


class TabixHTTP:
    """Query a remote bgzipped, tabix-indexed TSV by genomic region."""

    def __init__(self, url, tbi_path):
        self.url = url
        self.idx = parse_tbi(tbi_path)
        self.size = _content_length(url)

    def _chr_key(self, chrom):
        for c in (chrom, f"chr{chrom}", str(chrom)):
            if c in self.idx["refs"]:
                return c
        raise KeyError(f"{chrom} not in index ({self.idx['names'][:6]}...)")

    def fetch(self, chrom, beg, end, max_bytes=32 << 20):
        """Return the raw text lines overlapping [beg, end) on chrom (0-based, half-open).

        max_bytes is a budget in *bytes of the compressed file*.  Note that tabix chunk
        offsets are virtual (block_byte_offset << 16 | offset_within_block), so the budget
        has to be shifted into virtual units before it is compared with a chunk span --
        comparing the two directly silently caps a query at a few hundred bytes.
        """
        key = self._chr_key(chrom)
        ref = self.idx["refs"][key]
        chunks = []
        for b in _reg2bins(beg, end):
            if b in ref["bins"]:
                chunks.extend(ref["bins"][b])
        if not chunks:
            return []
        chunks.sort()
        merged = []
        for c in chunks:
            if merged and c[0] <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], c[1]))
            else:
                merged.append(list(c) if isinstance(c, tuple) else c)
        merged = [tuple(m) for m in merged]
        # The linear index gives a safe lower bound for the first chunk.
        li = beg >> 14
        if li < len(ref["linear"]):
            first = min(ref["linear"][li], merged[0][0])
            merged[0] = (first, merged[0][1])
        cap = max_bytes << 16                     # byte budget -> virtual-offset budget
        used = 0
        texts = []
        for cbeg, cend in merged:
            if used >= cap:
                break
            take = min(cend - cbeg, cap - used)
            used += take
            # A virtual offset points at a byte offset (voffset >> 16) plus an in-block
            # position, so the byte range to request starts at cbeg >> 16.
            start = cbeg >> 16
            endb = ((cbeg + take) >> 16) + 2 * 65536   # block holding the end, plus slack
            if self.size:
                if start >= self.size:
                    continue
                endb = min(endb, self.size)
            # Decompress each chunk on its own: concatenating byte ranges would splice a
            # truncated final block into the next range and abort the BGZF walk there.
            texts.append(bgzf_decompress(_http_range(self.url, start, endb)))
        text = b"".join(texts).decode("utf8", "ignore")
        out = []
        seen = set()
        for line in text.split("\n"):
            if not line or line.startswith("#") or line in seen:
                continue
            f = line.split("\t")
            if len(f) <= max(self.idx["col_beg"], self.idx["col_end"]):
                continue
            try:
                if f[self.idx["col_seq"] - 1] != key and f[self.idx["col_seq"] - 1] != chrom:
                    continue
                b0 = int(f[self.idx["col_beg"] - 1])
            except Exception:
                continue
            if b0 >= beg and b0 < end:
                seen.add(line)
                out.append(f)
        return out
