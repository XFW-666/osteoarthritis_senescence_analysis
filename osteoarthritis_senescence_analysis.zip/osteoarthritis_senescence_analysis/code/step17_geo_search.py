"""Search GEO DataSets via E-utilities (curl, since the local Python TLS stack is unreliable)."""
import json, subprocess, time, urllib.parse

E = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"


def curl_json(url, tries=4):
    for a in range(tries):
        p = subprocess.run(["curl", "-sS", "-m", "60", url], capture_output=True, text=True)
        if p.returncode == 0 and p.stdout.strip().startswith("{"):
            try:
                return json.loads(p.stdout)
            except Exception:
                pass
        time.sleep(3 + 3 * a)
    return {}


def search(term, n=40):
    q = urllib.parse.urlencode({"db": "gds", "term": term, "retmax": n,
                                "retmode": "json", "sort": "relevance"})
    j = curl_json(f"{E}/esearch.fcgi?{q}")
    ids = j.get("esearchresult", {}).get("idlist", [])
    if not ids:
        return []
    q2 = urllib.parse.urlencode({"db": "gds", "id": ",".join(ids), "retmode": "json"})
    s = curl_json(f"{E}/esummary.fcgi?{q2}")
    res = s.get("result", {})
    out = []
    for i in ids:
        r = res.get(i)
        if not r:
            continue
        out.append({"acc": r.get("accession"), "n": r.get("n_samples"),
                    "title": (r.get("title") or "")[:110],
                    "type": r.get("gdstype"), "taxon": r.get("taxon"),
                    "summary": (r.get("summary") or "")[:200]})
    return out


QUERIES = [
    "osteoarthritis cartilage DNA methylation profiling",
    "osteoarthritis cartilage methylation Illumina",
    "osteoarthritis articular cartilage expression profiling by high throughput sequencing",
    "knee osteoarthritis cartilage RNA-seq",
    "osteoarthritis cartilage transcriptome",
]
for term in QUERIES:
    print("=" * 100)
    print("QUERY:", term)
    for r in search(term):
        if r["taxon"] != "Homo sapiens":
            continue
        print(f"  {r['acc']:>10s} n={r['n']:>4} [{r['type']}] {r['title']}")
    time.sleep(0.5)
