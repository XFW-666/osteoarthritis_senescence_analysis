"""
step23_figure10.py — Figure 10: independent replication, disease specificity and two
orthogonal layers (epigenetic and genetic-programme).

Panels
  A  independent re-discovery: the two programme arms reproduce in GSE57218
  B  independent re-discovery: what the frozen signature does and does not separate
  C  disease specificity: osteoarthritis versus rheumatoid arthritis
  D  epigenetic layer: promoter methylation of the signature genes in two cohorts
  E  programme-level Mendelian randomisation across four osteoarthritis phenotypes
  F  programme-level MR: leave-one-gene-out stability
"""
import os, sys, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
import matplotlib.patheffects as pe

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from viz_style import (NEON, CYCLE, BG, GRID, TXT, MUTED, ACCENT, apply_style,
                       neon_axes, neon_text, neon_scatter, neon_bar, save)
import fig_helpers as H

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "results"); FIG = os.path.join(BASE, "figures")
apply_style()

COHORT_COL = {"GSE43269": NEON["teal"], "GSE73626": NEON["violet"]}


def panel_a(ax):
    d = pd.read_csv(os.path.join(OUT, "rediscovery_arms.csv"))
    # several suppressed genes share almost identical fold changes, so their balls are drawn
    # on top of one another; spread coincident points on a small circle so each ball and its
    # label are individually visible
    d = pd.read_csv(os.path.join(OUT, "rediscovery_arms.csv"))
    # 21 genes, several with almost identical fold changes: colour each gene its own colour
    # and identify them from a legend, so no floating label can ever drift off its ball
    genes_sorted = sorted(d["gene"].unique())
    palette = plt.get_cmap("tab20")
    GCOL = {g: palette(i / max(len(genes_sorted) - 1, 1)) for i, g in enumerate(genes_sorted)}
    for _, r in d.iterrows():
        ax.scatter(r["logFC_discovery"], r["logFC_GSE57218"], s=72,
                   color=GCOL[r["gene"]], zorder=5, edgecolors="#FFFFFF", linewidths=0.8,
                   label=r["gene"])
    lim = max(abs(d["logFC_discovery"]).max(), abs(d["logFC_GSE57218"]).max()) * 1.25
    ax.add_patch(Rectangle((-lim, -lim), lim, lim, facecolor="#E4F1E6", alpha=0.55, zorder=0))
    ax.add_patch(Rectangle((0, 0), lim, lim, facecolor="#E4F1E6", alpha=0.55, zorder=0))
    ax.axhline(0, color=TXT, lw=1.0); ax.axvline(0, color=MUTED, lw=1.0, ls=":")
    ax.plot([-lim, lim], [-lim, lim], color=MUTED, lw=1.0, ls="--", zorder=1)
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
    ax.set_xlabel("$\\log_2$ FC in discovery (GSE114007)")
    ax.set_ylabel("$\\log_2$ FC in GSE57218")
    j = json.load(open(os.path.join(OUT, "rediscovery_summary.json")))
    su, ind = j["arms"]["suppressed"], j["arms"]["induced"]
    ax.set_title("The two programme arms reproduce independently")
    ax.text(0.03, 0.97,
            f"suppressed arm  {su['concordant']}/{su['n']} concordant, sign-test $P$ = {su['sign_test_p']:.3f}\n"
            f"induced arm     {ind['concordant']}/{ind['n']} concordant, sign-test $P$ = {ind['sign_test_p']:.3f}",
            transform=ax.transAxes, fontsize=7.0, va="top", ha="left", color=TXT,
            linespacing=1.5)
    h_, l_ = ax.get_legend_handles_labels()
    u_ = dict(zip(l_, h_))
    ax.legend(u_.values(), u_.keys(), fontsize=5.6, ncol=4, loc="lower right",
              frameon=True, framealpha=0.95, edgecolor="#C9D6EA", handlelength=0.5,
              handletextpad=0.25, columnspacing=0.4, labelspacing=0.22, title="gene",
              title_fontsize=6.0)
    H.letter(ax, "A", x=-0.10)

    # Final pass using the ACTUAL rendered label boxes: any two labels that still touch are
    # separated until they clear, so a collision can never survive the estimate above.
    fig = ax.figure
    fig.canvas.draw()
    _r = fig.canvas.get_renderer()
    _names = {r["gene"] for _, r in d.iterrows()}
    for _pass in range(8):
        _ann = [a for a in ax.texts
                if a.get_text() in _names]
        _bx = [(a, a.get_window_extent(renderer=_r)) for a in _ann]
        _moved = False
        for _i in range(len(_bx)):
            for _j in range(_i + 1, len(_bx)):
                a1, b1 = _bx[_i]
                a2, b2 = _bx[_j]
                dx = min(b1.x1, b2.x1) - max(b1.x0, b2.x0)
                dy = min(b1.y1, b2.y1) - max(b1.y0, b2.y0)
                if dx <= 1 or dy <= 1:
                    continue
                # With 21 genes and several near-identical fold changes, no offset can
                # separate two labels that sit on the same ball, so the lower label is
                # dropped; the complete gene list is in Table S19.
                a2.set_visible(False)
                _moved = True
        fig.canvas.draw()
        if not _moved:
            break

def _auc_panel(ax, df, col_auc, col_lo, col_hi, labels, title, note=None, colors=None):
    y = np.arange(len(df))[::-1]
    ax.axvspan(0.30, 0.5, color="#F4F6F9", zorder=0)
    for i, (yy, (_, r)) in enumerate(zip(y, df.iterrows())):
        c = (colors or CYCLE)[i % len(colors or CYCLE)]
        if i % 2 == 0:
            ax.axhspan(yy - 0.5, yy + 0.5, color="#F7F9FC", zorder=0)
        ax.fill_between([0.5, r[col_auc]], yy - 0.22, yy + 0.22, color=c, alpha=0.30, zorder=1)
        ax.plot([r[col_lo], r[col_hi]], [yy, yy], color=c, lw=2.4, alpha=0.95,
                solid_capstyle="round", zorder=3)
        ax.scatter(r[col_auc], yy, s=78, color=c, zorder=5, edgecolors="#FFFFFF", linewidths=0.8)
        ax.text(r[col_hi] + 0.02, yy, f"{r[col_auc]:.3f}", fontsize=7.4, color=TXT,
                va="center", ha="left")
    ax.axvline(0.5, color=MUTED, lw=1.2, ls="--", zorder=2)
    ax.set_yticks(y); ax.set_yticklabels(labels, fontsize=8)
    ax.set_ylim(-0.6, len(df) - 0.4)
    ax.set_xlim(0.30, 1.20)
    ax.set_xlabel("area under the curve")
    ax.set_title(title)
    if note:
        ax.text(0.5, -0.135, note, transform=ax.transAxes, fontsize=6.2, color=MUTED,
                va="top", ha="center", linespacing=1.35)



def panel_b(ax):
    d = pd.read_csv(os.path.join(OUT, "rediscovery_contrasts.csv"))
    order = ["OA_vs_Healthy", "Preserved_vs_Healthy", "OA_vs_Preserved"]
    d = d.set_index("contrast").loc[order].reset_index()
    # 'ci' is written as a stringified two-element list
    ci = d["ci"].astype(str).str.strip("[]").str.split(",", expand=True).astype(float)
    d["ci_lo"], d["ci_hi"] = ci[0].values, ci[1].values
    _auc_panel(ax, d, "auc_panel", "ci_lo", "ci_hi",
               ["OA vs healthy\ncartilage", "preserved vs healthy\ncartilage",
                "OA vs preserved\n(same joints)"],
               "Frozen signature in an independent cohort",
               note="GSE57218 (HT-12 V3): tracks joint status, not lesion severity",
               colors=[NEON["blue"], NEON["violet"], NEON["teal"]])
    H.letter(ax, "B", x=-0.10)


def panel_c(ax):
    d = pd.read_csv(os.path.join(OUT, "ra_specificity.csv"))
    d["ci"] = d["ci_lo"]
    order = ["OA vs Normal", "OA vs RA", "RA vs Normal"]
    d = d.set_index("contrast").loc[order].reset_index()
    _auc_panel(ax, d, "panel_AUC", "ci_lo", "ci_hi",
               ["OA vs normal", "OA vs rheumatoid\narthritis", "rheumatoid arthritis\nvs normal"],
               "Disease specificity in GSE55235 synovium",
               note="also separates rheumatoid arthritis from normal tissue",
               colors=[NEON["blue"], NEON["magenta"], NEON["amber"]])
    H.letter(ax, "C", x=-0.10)


def panel_d(ax):
    frames = []
    for name in ("GSE43269", "GSE73626"):
        t = pd.read_csv(os.path.join(OUT, f"methylation_{name}.csv"))
        t = t[t["is_signature"]]
        frames.append(t[["gene", "delta_OA_minus_normal", "fdr", "n_cpg", "cohort"]])
    d = pd.concat(frames)
    genes = sorted(d["gene"].unique())
    ypos = {g: i for i, g in enumerate(genes)}
    h = 0.36
    for i, g in enumerate(genes):
        if i % 2 == 0:
            ax.axhspan(i - 0.5, i + 0.5, color="#F7F9FC", zorder=0)
    for _, r in d.iterrows():
        yy = ypos[r["gene"]]
        off = -h / 2 - 0.03 if r["cohort"] == "GSE43269" else h / 2 + 0.03
        c = COHORT_COL[r["cohort"]]
        ax.barh(yy + off, r["delta_OA_minus_normal"], height=h, color=c, alpha=0.92,
                edgecolor="#FFFFFF", linewidth=0.6, zorder=4)
    ax.axvline(0, color=TXT, lw=1.1, zorder=5)
    ax.set_yticks(list(ypos.values())); ax.set_yticklabels(genes, fontsize=8)
    ax.set_xlabel("$\\Delta$ methylation (OA $-$ normal)")
    ax.set_title("No promoter hypermethylation")
    sm = json.load(open(os.path.join(OUT, "methylation_summary.json")))
    ax.text(0.5, -0.125,
            "no gene reaches FDR < 0.05;  programme methylation unchanged:\n"
            f"GSE43269 $\\Delta$={sm['GSE43269']['programme_delta']:+.3f} "
            f"($P$={sm['GSE43269']['programme_p']:.2f}),  "
            f"GSE73626 $\\Delta$={sm['GSE73626']['programme_delta']:+.3f} "
            f"($P$={sm['GSE73626']['programme_p']:.3f})\n"
            "teal = 27K (n = 41), violet = 450K (n = 18)",
            transform=ax.transAxes, fontsize=6.2, va="top", ha="center", color=MUTED,
            linespacing=1.3)

    H.letter(ax, "D", x=-0.10)


def panel_e(ax):
    d = pd.read_csv(os.path.join(OUT, "mr_aggregate_results.csv"))
    y = np.arange(len(d))[::-1]
    for i, (yy, (_, r)) in enumerate(zip(y, d.iterrows())):
        c = NEON["blue"]
        if i % 2 == 0:
            ax.axhspan(yy - 0.5, yy + 0.5, color="#F7F9FC", zorder=0)
        ax.fill_between([r["OR_lo"], r["OR_hi"]], yy - 0.22, yy + 0.22, color=c,
                        alpha=0.32, zorder=1)
        ax.plot([r["OR_lo"], r["OR_hi"]], [yy, yy], color=c, lw=2.4, alpha=0.95,
                solid_capstyle="round", zorder=3)
        ax.scatter(r["OR"], yy, s=84, color=c, zorder=5, edgecolors="#FFFFFF", linewidths=0.8)
        ax.scatter(r["detectable_OR_80pct"], yy - 0.34, s=42, marker="|", color=NEON["amber"],
                   zorder=6, linewidths=1.8)
        ax.text(r["OR_hi"] + 0.004, yy, f"{r['OR']:.3f}  ($P$={r['p']:.2f})", fontsize=7.3,
                color=TXT, va="center", ha="left")
    ax.axvline(1.0, color=TXT, lw=1.2, ls="--", zorder=2)
    ax.set_yticks(y)
    ax.set_ylim(-0.6, len(d) - 0.4)
    ax.set_yticklabels([s.replace(", ", ",\n") for s in d["label"]], fontsize=7.8)
    ax.set_xlim(0.93, 1.14)
    ax.set_xlabel("OR per 1-SD composite signature score")
    ax.set_title("Programme-level Mendelian randomisation")

    k = int(d["n_instruments"].iloc[0])
    ax.text(0.5, -0.150, f"{k} composite instruments, all 8 genes, mean $F$ = "
                        f"{d['mean_F'].iloc[0]:,.0f}", transform=ax.transAxes,
            fontsize=6.2, color=MUTED, va="top", ha="center")
    ax.legend(handles=[Line2D([], [], marker="|", ls="", color=NEON["amber"], markersize=11,
                              markeredgewidth=2.2,
                              label="amber tick = smallest OR detectable at 80% power")],
              fontsize=6.8, loc="lower left", frameon=True, framealpha=0.95,
              edgecolor="#C9D6EA", handlelength=0.9)
    H.letter(ax, "E", x=-0.10)


def panel_f(ax):
    d = pd.read_csv(os.path.join(OUT, "mr_aggregate_leave_one_out.csv"))
    res = pd.read_csv(os.path.join(OUT, "mr_aggregate_results.csv"))
    labels = dict(zip(res["phenotype"], res["label"]))
    ph = list(dict.fromkeys(d["phenotype"]))
    for i, p in enumerate(ph):
        s = d[d["phenotype"] == p]
        yy = len(ph) - 1 - i
        if i % 2 == 0:
            ax.axhspan(yy - 0.5, yy + 0.5, color="#F7F9FC", zorder=0)
        ax.fill_between([s["OR"].min(), s["OR"].max()], yy - 0.26, yy + 0.26,
                        color="#C9D6EA", zorder=1)
        ax.plot([s["OR"].min(), s["OR"].max()], [yy, yy], color="#9FB4D2", lw=1.4, zorder=2)
        ax.scatter(s["OR"], np.full(len(s), yy), s=38, color=NEON["violet"], zorder=5,
                   edgecolors="#FFFFFF", linewidths=0.6)
        full = res[res["phenotype"] == p]["OR"].iloc[0]
        ax.scatter(full, yy, s=92, marker="D", color=NEON["magenta"], zorder=6,
                   edgecolors="#FFFFFF", linewidths=0.8)
    ax.axvline(1.0, color=TXT, lw=1.2, ls="--", zorder=1)
    ax.set_yticks(np.arange(len(ph))[::-1])
    ax.set_ylim(-0.6, len(ph) - 0.4)
    ax.set_yticklabels([labels[p].replace(", ", ",\n") for p in ph], fontsize=7.8)
    ax.set_xlabel("OR after dropping one signature gene")
    ax.set_title("Stable to leave-one-gene-out")
    ax.legend(handles=[Line2D([], [], marker="D", ls="", color=NEON["magenta"],
                              label="all eight genes"),
                       Line2D([], [], marker="o", ls="", color=NEON["violet"],
                              label="one gene dropped")], fontsize=7.2, loc="lower right")
    H.letter(ax, "F", x=-0.10)


def figure10():
    fig = plt.figure(figsize=(16.8, 11.6), facecolor=BG)
    gs = fig.add_gridspec(2, 3, height_ratios=[1, 1], hspace=0.46, wspace=0.40,
                          left=0.115, right=0.975, top=0.935, bottom=0.075)
    panel_a(fig.add_subplot(gs[0, 0])); neon_axes(fig.axes[-1])
    panel_b(fig.add_subplot(gs[0, 1])); neon_axes(fig.axes[-1])
    panel_c(fig.add_subplot(gs[0, 2])); neon_axes(fig.axes[-1])
    panel_d(fig.add_subplot(gs[1, 0])); neon_axes(fig.axes[-1])
    panel_e(fig.add_subplot(gs[1, 1])); neon_axes(fig.axes[-1])
    panel_f(fig.add_subplot(gs[1, 2])); neon_axes(fig.axes[-1])
    save(fig, os.path.join(FIG, "Figure10_replication_specificity_layers.png"))


if __name__ == "__main__":
    figure10()
