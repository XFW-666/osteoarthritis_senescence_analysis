"""
step4b_immune.py — curated immune/stromal infiltration panel (ssGSEA) + hallmark pathway
activity, computed on the discovery cohort.  Cell-type gene sets are taken from real curated
marker libraries (CellMarker 2024 tissue-agnostic human terms, PanglaoDB 2021).
"""
import os, json
import numpy as np
import pandas as pd
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); GS = os.path.join(BASE, "genesets"); OUT = os.path.join(BASE, "results")

CURATED = [
    ("Chondrocyte",            "PanglaoDB_Augmented_2021", "Chondrocytes"),
    ("Fibroblast",             "CellMarker_2024", "Fibroblast Undefined Human"),
    ("Macrophage",             "CellMarker_2024", "Macrophage Undefined Human"),
    ("M1 macrophage",          "CellMarker_2024", "M1 Macrophage Undefined Human"),
    ("M2 macrophage",          "CellMarker_2024", "M2 Macrophage Undefined Human"),
    ("Monocyte",               "PanglaoDB_Augmented_2021", "Monocytes"),
    ("Dendritic cell",         "CellMarker_2024", "Dendritic Cell Undefined Human"),
    ("Neutrophil",             "CellMarker_2024", "Neutrophil Undefined Human"),
    ("Mast cell",              "CellMarker_2024", "Mast Cell Undefined Human"),
    ("Eosinophil",             "CellMarker_2024", "Eosinophil Undefined Human"),
    ("Basophil",               "CellMarker_2024", "Basophil Undefined Human"),
    ("Natural killer cell",    "CellMarker_2024", "Natural Killer Cell Undefined Human"),
    ("T cell",                 "CellMarker_2024", "T Cell Undefined Human"),
    ("CD4+ T cell",            "CellMarker_2024", "CD4+ T Cell Undefined Human"),
    ("CD8+ T cell",            "CellMarker_2024", "CD8+ T Cell Undefined Human"),
    ("Regulatory T cell",      "CellMarker_2024", "Regulatory T (Treg) Cell Undefined Human"),
    ("Th17 cell",              "CellMarker_2024", "T Helper17 (Th17) Cell Undefined Human"),
    ("B cell",                 "CellMarker_2024", "B Cell Undefined Human"),
    ("Plasma cell",            "CellMarker_2024", "Plasma Cell Undefined Human"),
]

HALLMARK = {
    "Inflammatory response": "Inflammatory Response",
    "IL-6/JAK/STAT3 signalling": "IL6 JAK STAT3 Signaling",
    "TNF-alpha signalling via NF-kB": "TNFA Signaling Via NFKB",
    "Interferon gamma response": "Interferon Gamma Response",
    "Interferon alpha response": "Interferon Alpha Response",
    "Complement system": "Complement",
    "Apoptosis": "Apoptosis",
    "p53 pathway": "P53 Pathway",
    "G2-M checkpoint": "G2M Checkpoint",
    "E2F targets": "E2F Targets",
}


def norm_key(s):
    return "".join(ch for ch in s.lower() if ch.isalnum())


def ssgsea_scores(expr, gene_sets, alpha=0.25):
    genes = np.array(expr.index)
    X = expr.values.astype(float)
    N = X.shape[0]
    order = np.argsort(-X, axis=0)
    ranks = np.empty_like(order)
    for j in range(X.shape[1]):
        ranks[order[:, j], j] = np.arange(1, N + 1)
    out = {}
    for name, gs in gene_sets.items():
        gs = [g for g in set(gs) if g in expr.index]
        if len(gs) < 5:
            continue
        mask = np.zeros(N, dtype=bool)
        mask[np.isin(genes, gs)] = True
        w = np.abs(ranks) ** alpha
        wg = w * mask[:, None]; wng = w * (~mask)[:, None]
        Pg = np.cumsum(wg, axis=0) / np.maximum(wg.sum(0), 1e-12)
        Png = np.cumsum(wng, axis=0) / np.maximum(wng.sum(0), 1e-12)
        out[name] = (Pg - Png).sum(0)
    return pd.DataFrame(out, index=expr.columns)


def main():
    expr = pd.read_csv(os.path.join(WORK, "expr_GSE114007.csv"), index_col=0)
    labels = pd.read_csv(os.path.join(WORK, "labels_GSE114007.csv"), index_col=0).iloc[:, 0]
    y = (labels == "OA").astype(int)
    sig = json.load(open(os.path.join(OUT, "signature.json")))

    # ---- curated infiltration panel
    sets, used = {}, {}
    for nice, lib, term in CURATED:
        p = os.path.join(GS, lib + ".json")
        if not os.path.exists(p):
            print("missing library", lib); continue
        d = json.load(open(p, encoding="utf8"))
        k = term if term in d else next((kk for kk in d if norm_key(kk) == norm_key(term)), None)
        if k is None:
            print("  term not found:", term); continue
        sets[nice] = d[k]
        used[nice] = (lib, k, len(d[k]))
    print("curated cell-type sets:", len(sets))
    for k, v in used.items():
        print(f"   {k:24s} {v[2]:4d} genes  [{v[0]}]")

    infil = ssgsea_scores(expr, sets)
    infil.to_csv(os.path.join(OUT, "ssgsea_immune.csv"))
    rows = []
    for c in infil.columns:
        a = infil.loc[y == 1, c].values; b = infil.loc[y == 0, c].values
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        rows.append({"cell_type": c, "mean_OA": a.mean(), "mean_Normal": b.mean(),
                     "delta": a.mean() - b.mean(), "p": p,
                     "effect": 2 * u / (len(a) * len(b)) - 1, "n_genes": used[c][2]})
    t = pd.DataFrame(rows).sort_values("p")
    t["adjp"] = np.minimum(1, t["p"] * len(t) / t["p"].rank())
    t.to_csv(os.path.join(OUT, "immune_infiltration_stats.csv"), index=False)
    print("\ncurated infiltration results:")
    print(t.round(4).to_string(index=False))

    # ---- hallmark activity
    hp = os.path.join(GS, "MSigDB_Hallmark_2020.json")
    hd = json.load(open(hp, encoding="utf8"))
    hsets = {}
    for nice, term in HALLMARK.items():
        k = next((kk for kk in hd if norm_key(kk) == norm_key(term)), None)
        if k:
            hsets[nice] = hd[k]
    hsets["Senescence programme (curated union)"] = json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))
    print("\nhallmark sets matched:", list(hsets.keys()))
    hsc = ssgsea_scores(expr, hsets)
    hsc.to_csv(os.path.join(OUT, "ssgsea_hallmark.csv"))
    hr = []
    for c in hsc.columns:
        a = hsc.loc[y == 1, c].values; b = hsc.loc[y == 0, c].values
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        hr.append({"pathway": c, "mean_OA": a.mean(), "mean_Normal": b.mean(),
                   "delta": a.mean() - b.mean(), "p": p, "effect": 2 * u / (len(a) * len(b)) - 1})
    ht = pd.DataFrame(hr).sort_values("p")
    ht.to_csv(os.path.join(OUT, "hallmark_stats.csv"), index=False)
    print("\nhallmark activity:")
    print(ht.round(4).to_string(index=False))

    # ---- signature genes vs senescence score and vs infiltration
    sen = hsc["Senescence programme (curated union)"]
    rows = []
    for g in sig:
        r, p = stats.pearsonr(expr.loc[g], sen)
        rows.append({"gene": g, "r_senescence_score": r, "p": p})
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "signature_vs_senescence_score.csv"), index=False)

    top = t.head(14)["cell_type"].tolist()
    cm = pd.DataFrame(index=sig, columns=top, dtype=float)
    for g in sig:
        for c in top:
            cm.loc[g, c] = stats.pearsonr(expr.loc[g], infil[c])[0]
    cm.to_csv(os.path.join(OUT, "signature_vs_immune_corr.csv"))
    print("\nsignature vs senescence-score correlations:")
    print(pd.DataFrame(rows).round(3).to_string(index=False))
    print("STEP4B DONE")


if __name__ == "__main__":
    main()
