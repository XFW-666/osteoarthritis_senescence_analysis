"""
audit_refs.py — verify every reference in the bibliography against live PubMed.

The reference list was built from PubMed E-utilities, but a record can go stale or be keyed to
the wrong PMID.  This re-fetches each PMID by id and checks that the year, journal and first
author still match what the manuscript prints.
"""
import json, re, subprocess, sys, time

refs = json.load(open("results/references.json", encoding="utf-8"))
pmids = [r["pmid"] for r in refs]
print(f"verifying {len(pmids)} PMIDs against PubMed")

E = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"


def esummary(ids):
    url = f"{E}?db=pubmed&id={','.join(ids)}&retmode=json"
    for a in range(5):
        p = subprocess.run(["curl", "-sS", "-m", "90", url], capture_output=True, text=True)
        if p.returncode == 0 and p.stdout.strip().startswith("{"):
            try:
                return json.loads(p.stdout).get("result", {})
            except Exception:
                pass
        time.sleep(3 + 3 * a)
    return {}


bad, missing, ok = [], [], 0
CHUNK = 50
res = {}
for i in range(0, len(pmids), CHUNK):
    r = esummary(pmids[i:i + CHUNK])
    res.update({k: v for k, v in r.items() if k != "uids"})
    print(f"  fetched {min(i + CHUNK, len(pmids))}/{len(pmids)}")
    time.sleep(0.5)

for rec in refs:
    pid = rec["pmid"]
    r = res.get(pid)
    if not r or not isinstance(r, dict) or r.get("error"):
        missing.append((rec["n"], pid))
        continue
    title = (r.get("title") or "").strip()
    src = (r.get("source") or "").strip()
    year = (r.get("pubdate") or "").split(" ")[0]
    authors = [a.get("name", "") for a in r.get("authors", [])]
    printed = rec["text"]
    problems = []
    if title[:40].rstrip(".") not in printed.replace("\u2019", "'"):
        # titles are truncated in AMA rendering; compare the leading words
        lead = " ".join(title.split()[:6]).rstrip(".")
        if lead.lower()[:24] not in printed.lower():
            problems.append(f"title mismatch: {title[:50]!r}")
    if src and src not in printed:
        problems.append(f"journal {src!r} not in printed citation")
    if year and year not in printed:
        problems.append(f"year {year} not in printed citation")
    if authors and authors[0] and authors[0].split()[-1] not in printed:
        problems.append(f"first author {authors[0]!r} not in printed citation")
    if problems:
        bad.append((rec["n"], pid, problems))
    else:
        ok += 1

print(f"\nOK: {ok}/{len(refs)}")
print(f"NOT FOUND in PubMed: {len(missing)}  {missing[:10]}")
print(f"MISMATCHES: {len(bad)}")
for n, pid, probs in bad[:20]:
    print(f"  ref {n} [PMID {pid}]: {'; '.join(probs)}")
