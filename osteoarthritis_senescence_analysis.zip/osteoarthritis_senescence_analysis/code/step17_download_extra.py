"""Download the additional public datasets for the depth upgrades, using curl (the local Python
TLS stack cannot reach NCBI reliably).  HEAD-checks sizes first so nothing unexpectedly huge
is pulled."""
import os, subprocess, sys

OUT = "data/extra"
os.makedirs(OUT, exist_ok=True)

FILES = [
    # independent cartilage transcriptome cohorts
    ("GSE57218", "GSE57nnn/GSE57218/matrix/GSE57218_series_matrix.txt.gz"),
    ("GSE117999", "GSE117nnn/GSE117999/matrix/GSE117999_series_matrix.txt.gz"),
    # DNA methylation case/control cohorts
    ("GSE43269", "GSE43nnn/GSE43269/matrix/GSE43269_series_matrix.txt.gz"),
    ("GSE73626", "GSE73nnn/GSE73626/matrix/GSE73626_series_matrix.txt.gz"),
    # platform annotations (probe -> gene / position)
    ("GPL8490", "GPL8490/GPL8490_family.soft.gz"),
    ("GPL13534", "GPL13534/GPL13534_family.soft.gz"),
    ("GPL6947", "GPL6947/GPL6947.annot.gz"),
    ("GPL20844", "GPL20844/GPL20844.annot.gz"),
]
BASES = ["https://ftp.ncbi.nlm.nih.gov/geo/series/", "https://ftp.ncbi.nlm.nih.gov/geo/platforms/"]


def head_size(url):
    p = subprocess.run(["curl", "-sSI", "-m", "40", url], capture_output=True, text=True)
    for line in p.stdout.splitlines():
        if line.lower().startswith("content-length:"):
            return int(line.split(":")[1].strip())
    return None


def fetch(url, dest):
    if os.path.exists(dest) and os.path.getsize(dest) > 1000:
        print(f"  have {os.path.basename(dest)} ({os.path.getsize(dest):,})")
        return dest
    tmp = dest + ".part"
    p = subprocess.run(["curl", "-sS", "-L", "-m", "1800", "-o", tmp, url])
    if p.returncode != 0 or not os.path.exists(tmp) or os.path.getsize(tmp) < 1000:
        print(f"  FAIL {url}")
        if os.path.exists(tmp):
            os.remove(tmp)
        return None
    os.replace(tmp, dest)
    print(f"  got  {os.path.basename(dest)} ({os.path.getsize(dest):,})")
    return dest


for name, rel in FILES:
    urls = []
    if rel.startswith("GPL"):
        urls = [f"https://ftp.ncbi.nlm.nih.gov/geo/platforms/{rel}"]
    else:
        urls = [f"https://ftp.ncbi.nlm.nih.gov/geo/series/{rel}"]
    dest = os.path.join(OUT, os.path.basename(rel))
    print(f"[{name}]")
    ok = False
    for u in urls:
        sz = head_size(u)
        if sz is None:
            print(f"  no HEAD: {u}")
            continue
        print(f"  size {sz:,} bytes  {u}")
        if sz > 900_000_000:
            print("  SKIP: too large")
            continue
        if fetch(u, dest):
            ok = True
            break
    if not ok:
        print(f"  !! could not obtain {name}")
print("EXTRA DOWNLOADS DONE")
