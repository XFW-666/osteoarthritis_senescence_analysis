"""
viz_style.py — shared clean-academic plotting theme for all study figures.

Light background (no dark board), vivid but print-safe palette, no neon glow.
The public API is unchanged so the figure scripts keep working.
"""
import os
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

# ---------------------------------------------------------------- palette
NEON = {                       # key names kept for backwards compatibility
    "cyan":    "#0891B2",      # deep cyan
    "blue":    "#2563EB",      # strong blue
    "violet":  "#7C3AED",      # violet
    "magenta": "#DB2777",      # magenta / crimson
    "pink":    "#EC4899",
    "red":     "#DC2626",
    "orange":  "#EA580C",
    "amber":   "#D97706",
    "lime":    "#65A30D",
    "green":   "#16A34A",
    "teal":    "#0D9488",
    "slate":   "#64748B",
    "white":   "#1A2233",
}
CYCLE = [NEON["blue"], NEON["magenta"], NEON["teal"], NEON["amber"], NEON["violet"],
         NEON["orange"], NEON["green"], NEON["pink"], NEON["cyan"], NEON["red"],
         NEON["lime"], NEON["slate"]]

BG = "#FFFFFF"
PANEL = "#F7F9FC"
GRID = "#DCE3ED"
TXT = "#16203A"
MUTED = "#5A6B87"
ACCENT = NEON["blue"]

LIGHT_RC = {
    "figure.facecolor": BG,
    "savefig.facecolor": BG,
    "axes.facecolor": BG,
    "axes.edgecolor": "#9AA9C0",
    "axes.labelcolor": TXT,
    "axes.titlecolor": TXT,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.alpha": 0.9,
    "grid.linewidth": 0.7,
    "text.color": TXT,
    "xtick.major.pad": 4, "ytick.major.pad": 4,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "axes.labelsize": 9.5,
    "axes.titlesize": 10.5,
    "axes.titleweight": "bold",
    "axes.titlepad": 7,
    "legend.fontsize": 8.5,
    "legend.facecolor": "#FFFFFF",
    "legend.edgecolor": GRID,
    "legend.labelcolor": TXT,
    "legend.framealpha": 0.95,
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "axes.linewidth": 1.0,
    "figure.dpi": 120,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "lines.linewidth": 2.0,
    "lines.solid_capstyle": "round",
}


def apply_style():
    plt.rcParams.update(LIGHT_RC)


def neon_axes(ax, glow=True):
    """Clean spines: hide top/right, keep bottom/left in a light grey."""
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#9AA9C0")
        ax.spines[s].set_linewidth(1.0)
    ax.tick_params(length=3, width=0.9)
    return ax


def panel_label(ax, text, color=None, x=-0.10, y=1.045):
    ax.text(x, y, text, transform=ax.transAxes, fontsize=12.5, fontweight="bold",
            color=color or ACCENT, va="bottom", ha="left", zorder=30)


def _halo(color="#FFFFFF", lw=2.4, alpha=0.9):
    import matplotlib.patheffects as pe
    return [pe.withStroke(linewidth=lw, foreground=color, alpha=alpha)]


def neon_line(ax, x, y, color, label=None, lw=2.2, alpha=1.0, ls="-", zorder=5, glow=True):
    ln, = ax.plot(x, y, color=color, lw=lw, alpha=alpha, ls=ls, label=label,
                  zorder=zorder, solid_capstyle="round")
    return ln


def neon_scatter(ax, x, y, color, size=30, alpha=0.9, label=None, marker="o", zorder=6,
                 edge=None, lw=0.6):
    return ax.scatter(x, y, s=size, c=color, alpha=alpha, label=label, marker=marker,
                      zorder=zorder, edgecolors=edge or "none", linewidths=lw)


def neon_bar(ax, x, h, color, width=0.7, label=None, alpha=1.0, zorder=4, glow=True, edge=None):
    return ax.bar(x, h, width=width, color=color, alpha=alpha, label=label, zorder=zorder,
                  edgecolor=edge or "none", linewidth=0.8)


def neon_text(ax, x, y, s, color=None, size=9, weight="bold", ha="left", va="center",
              glow=True, transform=None, style="normal"):
    """Text with a white halo so it stays legible over data.  matplotlib reads an explicit
    transform=None as the identity transform, so the keyword is only forwarded when set."""
    kw = dict(color=color or TXT, fontsize=size, fontweight=weight, ha=ha, va=va,
              style=style, zorder=20)
    if transform is not None:
        kw["transform"] = transform
    t = ax.text(x, y, s, **kw)
    if glow:
        t.set_path_effects(_halo("#FFFFFF", 2.6, 0.9))
    return t


def rounded_box(ax, xy, w, h, face="#FFFFFF", edge=None, lw=1.6, radius=0.03, alpha=1.0, zorder=3):
    box = FancyBboxPatch(xy, w, h, boxstyle=f"round,pad=0.008,rounding_size={radius}",
                         facecolor=face, edgecolor=edge or ACCENT, linewidth=lw, alpha=alpha,
                         zorder=zorder, mutation_aspect=1.0)
    ax.add_patch(box)
    return box


def arrow(ax, p0, p1, color=None, lw=1.8, style="-|>", rad=0.0, zorder=2, alpha=1.0, ms=11):
    a = FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=ms, color=color or ACCENT,
                        lw=lw, connectionstyle=f"arc3,rad={rad}", zorder=zorder, alpha=alpha,
                        shrinkA=1, shrinkB=1)
    ax.add_patch(a)
    return a


def significance_stars(p):
    return "****" if p < 1e-4 else "***" if p < 1e-3 else "**" if p < 0.01 else "*" if p < 0.05 else "ns"


def add_sig(ax, x1, x2, y, p, color=None, lw=1.1, text=None, fs=8.5):
    color = color or MUTED
    ax.plot([x1, x1, x2, x2], [y, y * 1.01, y * 1.01, y], lw=lw, color=color, zorder=10)
    ax.text((x1 + x2) / 2, y * 1.02, text or significance_stars(p), ha="center", va="bottom",
            color=color, fontsize=fs, fontweight="bold", zorder=11)


# ---------------------------------------------------------------- layout QA gate
def _bbox_overlap(a, b):
    dx = min(a.x1, b.x1) - max(a.x0, b.x0)
    dy = min(a.y1, b.y1) - max(a.y0, b.y0)
    if dx <= 0 or dy <= 0:
        return 0.0
    inter = dx * dy
    small = min((a.x1 - a.x0) * (a.y1 - a.y0), (b.x1 - b.x0) * (b.y1 - b.y0))
    return inter / small if small > 0 else 0.0


def qa_layout(fig, name="figure", verbose=True):
    """Detect clipped text and text-on-text collisions."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    fw, fh = fig.canvas.get_width_height()
    items = []
    for ax in fig.axes:
        for t in ax.texts:
            s = t.get_text()
            if not s or not s.strip():
                continue
            try:
                bb = t.get_window_extent(renderer=r)
            except Exception:
                continue
            if bb.width > 0 and bb.height > 0:
                items.append((s.replace("\n", " / ")[:42], bb))
    for t in fig.texts:
        s = t.get_text()
        if not s or not s.strip():
            continue
        try:
            items.append((s.replace("\n", " / ")[:42], t.get_window_extent(renderer=r)))
        except Exception:
            pass

    issues = []
    for s, bb in items:
        if bb.x0 < -2 or bb.y0 < -2 or bb.x1 > fw + 2 or bb.y1 > fh + 2:
            issues.append(f"CLIPPED text '{s}' extends outside the canvas")
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            ov = _bbox_overlap(items[i][1], items[j][1])
            if ov > 0.45:
                issues.append(f"OVERLAP ({ov*100:.0f}%) '{items[i][0]}' vs '{items[j][0]}'")
    if verbose:
        print(f"   layout QA [{name}]: {'OK' if not issues else str(len(issues)) + ' issue(s)'}"
              f"  (canvas {fw}x{fh}, {len(items)} text items)")
        for s in issues[:14]:
            print("      -", s)
    return issues


def _walk_axes(fig):
    """Every axes in the figure, including inset axes (which live in ax.child_axes and are
    therefore invisible to fig.axes).  Returns [(axes, parent_or_None), ...]."""
    out, stack = [], [(a, None) for a in fig.axes]
    seen = set()
    while stack:
        a, par = stack.pop()
        if id(a) in seen:
            continue
        seen.add(id(a))
        out.append((a, par))
        for c in getattr(a, "child_axes", []) or []:
            stack.append((c, a))
    return out


def qa_axes(fig, name="figure", verbose=True, tol=0.02):
    """Detect axes that overlap each other.

    Panel overlap is a layout bug a text-only check cannot see.  Two overlaps are legitimate and
    are skipped: a twin axis (twinx/twiny), which shares its parent's box exactly, and an inset
    axis while it stays inside its own parent.  An inset that escapes its parent is reported.
    """
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    items = []
    for a, par in _walk_axes(fig):
        if not a.get_visible():
            continue
        try:
            items.append((a, par, a.get_window_extent(renderer=r)))
        except Exception:
            continue
    issues = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            a, pa, ba = items[i]; b, pb, bb = items[j]
            if pa is b or pb is a:                       # parent / inset pair
                inner, outer = (ba, bb) if pa is b else (bb, ba)
                if (inner.x0 >= outer.x0 - 1 and inner.x1 <= outer.x1 + 1
                        and inner.y0 >= outer.y0 - 1 and inner.y1 <= outer.y1 + 1):
                    continue                             # inset sits inside its parent: fine
            try:
                if tuple(a.get_position().bounds) == tuple(b.get_position().bounds):
                    continue                             # twin axis
            except Exception:
                pass
            ov = _bbox_overlap(ba, bb)
            if ov > tol:
                la = (a.get_title() or a.get_ylabel() or "axes")[:30]
                lb = (b.get_title() or b.get_ylabel() or "axes")[:30]
                tag = "  <-- INSET ESCAPES ITS PARENT" if (pa is b or pb is a) else ""
                issues.append(f"AXES OVERLAP ({ov*100:.0f}%) {la!r} vs {lb!r}{tag}")
    if verbose:
        print(f"   axes QA [{name}]: {'OK' if not issues else str(len(issues)) + ' overlap(s)'}"
              f"  ({len(items)} axes incl. insets)")
        for s in issues:
            print("      -", s)
    return issues


def _all_text_items(fig, r):
    """Every visible string in the figure, with the axes it belongs to.

    qa_layout only looks at ax.texts, so it cannot see a panel title colliding with a
    neighbouring panel's tick labels, or a legend entry running into another panel.
    Axes that are twins of one another (identical position) are collapsed to the first one,
    otherwise their coincident tick labels are reported as overlapping each other.
    """
    out = []
    seen_pos = set()

    def add(owner, artist, where, axbox):
        if artist is None:
            return
        try:
            if not artist.get_visible():
                return          # axis("off") leaves the tick Text objects in place
        except Exception:
            pass
        try:
            s = artist.get_text()
        except Exception:
            return
        if s is None or not str(s).strip():
            return
        try:
            bb = artist.get_window_extent(renderer=r)
        except Exception:
            return
        if bb.width <= 0 or bb.height <= 0:
            return
        out.append((owner, str(s).replace("\n", " / ")[:38], bb, where, axbox))

    for t in fig.texts:
        add("fig", t, "figtext", None)
    for ax, _par in _walk_axes(fig):
        if not ax.get_visible():
            continue
        try:
            pos = tuple(round(v, 6) for v in ax.get_position().bounds)
        except Exception:
            pos = None
        if pos is not None and pos in seen_pos:
            continue                       # twin axis: its labels duplicate the parent's
        if pos is not None:
            seen_pos.add(pos)
        try:
            axbox = ax.get_window_extent(renderer=r)
        except Exception:
            axbox = None
        for t in ax.texts:
            add("anno", t, "annotation", axbox)
        for which in ("title", "_left_title", "_right_title"):
            add("title", getattr(ax, which, None), "title", axbox)
        add("axis", ax.xaxis.get_label(), "xlabel", axbox)
        add("axis", ax.yaxis.get_label(), "ylabel", axbox)
        for t in ax.get_xticklabels() + ax.get_yticklabels():
            # axis("off") hides the whole Axis object, not each Text's own visible flag
            if t in ax.get_xticklabels() and not ax.xaxis.get_visible():
                continue
            if t in ax.get_yticklabels() and not ax.yaxis.get_visible():
                continue
            add("tick", t, "ticklabel", axbox)
        leg = ax.get_legend()
        if leg is not None:
            for t in leg.get_texts():
                add("legend", t, "legend", axbox)
            add("legend", leg.get_title(), "legend-title", axbox)
    return out


def _data_points_in(ax, box):
    """How many plotted data points fall inside a display-coordinate box."""
    n_in = n_tot = 0
    for c in ax.collections:
        off = getattr(c, "offsets", None)
        try:
            if off is None or len(off) == 0:
                continue
            pts = ax.transData.transform(np.asarray(off, float))
        except Exception:
            continue
        n_tot += len(pts)
        n_in += int(((pts[:, 0] >= box.x0) & (pts[:, 0] <= box.x1) &
                     (pts[:, 1] >= box.y0) & (pts[:, 1] <= box.y1)).sum())
    for ln in ax.lines:
        try:
            xy = ln.get_xydata()
        except Exception:
            continue
        if xy is None or len(xy) == 0:
            continue
        pts = ax.transData.transform(xy)
        n_tot += len(pts)
        n_in += int(((pts[:, 0] >= box.x0) & (pts[:, 0] <= box.x1) &
                     (pts[:, 1] >= box.y0) & (pts[:, 1] <= box.y1)).sum())
    for cont in ax.containers:
        for p in cont.patches:
            try:
                bb = p.get_window_extent()
            except Exception:
                continue
            n_tot += 1
            if _bbox_overlap(box, bb) > 0.5:
                n_in += 1
    return n_in, n_tot


def qa_full(fig, name="figure", verbose=True, text_tol=0.20):
    """Full figure audit: any text on any text, text spilling into a neighbouring panel,
    and legends covering data.

    Note on clipping: the figures are saved with bbox_inches="tight", so matplotlib grows the
    canvas to include every artist and nothing is ever truly clipped.  What matters instead is
    whether a label escapes its own panel and lands on another panel's plot area, which this
    does check.

    Returns (issues, notes).
    """
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    items = _all_text_items(fig, r)

    axboxes = []
    for ax, _par in _walk_axes(fig):
        if not ax.get_visible():
            continue
        try:
            axboxes.append(((ax.get_title() or ax.get_ylabel() or "axes")[:30],
                            ax.get_window_extent(renderer=r)))
        except Exception:
            continue

    issues, notes = [], []
    for owner, s, bb, where, axbox in items:
        if axbox is None:
            continue
        for aname, abox in axboxes:
            if abox is axbox:
                continue
            ov = _bbox_overlap(bb, abox)
            if ov > 0.6 and bb.width * bb.height > 0:
                # only a problem if the text has genuinely left its own panel
                own_out = (bb.x0 < axbox.x0 - 1 or bb.x1 > axbox.x1 + 1
                           or bb.y0 < axbox.y0 - 1 or bb.y1 > axbox.y1 + 1)
                if own_out:
                    issues.append(f"TEXT IN NEIGHBOURING PANEL: {where} '{s}' sits on {aname!r}")
                break

    n = len(items)
    for i in range(n):
        o1, s1, b1, w1, a1 = items[i]
        for j in range(i + 1, n):
            o2, s2, b2, w2, a2 = items[j]
            if o1 == "legend" and o2 == "legend":
                continue                       # legend entries never overlap by construction
            ov = _bbox_overlap(b1, b2)
            if ov > text_tol:
                same = "same panel" if a1 is a2 else "ACROSS PANELS"
                line = (f"TEXT OVERLAP ({ov*100:.0f}%, {same}) {w1} '{s1}' vs {w2} '{s2}'")
                if ov > 0.5 or a1 is not a2:
                    issues.append(line)
                else:
                    notes.append(line)

    for ax, _par in _walk_axes(fig):
        if not ax.get_visible():
            continue
        leg = ax.get_legend()
        if leg is None:
            continue
        try:
            lb = leg.get_window_extent(renderer=r)
        except Exception:
            continue
        n_in, n_tot = _data_points_in(ax, lb)
        ttl = (ax.get_title() or ax.get_ylabel() or "axes")[:34]
        if n_in and n_tot:
            frac = n_in / n_tot
            if frac > 0.05:
                issues.append(f"LEGEND COVERS DATA in {ttl!r}: {n_in}/{n_tot} points under the legend box")
            else:
                notes.append(f"legend overlaps {n_in}/{n_tot} points in {ttl!r} (small fraction)")
    if verbose:
        bad = "OK" if not issues else f"{len(issues)} issue(s)"
        print(f"   full QA [{name}]: {bad}  ({n} text items, {len(notes)} note(s))")
        for s in issues[:30]:
            print("      -", s)
    return issues, notes


def thin_ticks(fig, n=5):
    """Cap tick density so adjacent tick labels cannot grow into each other.

    Panels are short relative to their data range, and matplotlib's automatic locator happily
    places labels that collide.  Called at the end of a figure build, after every limit is set.
    """
    from matplotlib.ticker import MaxNLocator
    for ax, _par in _walk_axes(fig):
        try:
            ax.xaxis.set_major_locator(MaxNLocator(n))
            ax.yaxis.set_major_locator(MaxNLocator(n))
        except Exception:
            pass


def thin_ticks_auto(fig, pad=1.35):
    """Reduce tick counts until no two tick labels can possibly touch.

    Hand-tuning spacing while unable to see the result makes things worse, so this derives the
    maximum number of ticks from the *measured* pixel size of the rendered labels and the pixel
    size of the axes.  Called from save() before the QA gates, so every figure gets it.
    """
    from matplotlib.ticker import MaxNLocator
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    for ax, _par in _walk_axes(fig):
        if not ax.get_visible():
            continue
        try:
            bb = ax.get_window_extent(renderer=r)
        except Exception:
            continue
        for axis, avail, vertical in ((ax.yaxis, bb.height, True), (ax.xaxis, bb.width, False)):
            try:
                if not axis.get_visible():
                    continue
                labs = [t for t in axis.get_ticklabels() if t.get_visible() and t.get_text().strip()]
            except Exception:
                continue
            if len(labs) < 2:
                continue
            need = []
            for t in labs:
                try:
                    tb = t.get_window_extent(renderer=r)
                    need.append(tb.height if vertical else tb.width)
                except Exception:
                    pass
            if not need:
                continue
            slot = max(need) * pad + 2.0
            nbins = max(2, int(avail // slot) + 1)
            if nbins < len(labs):
                axis.set_major_locator(MaxNLocator(nbins))
    fig.canvas.draw()


def save(fig, path, dpi=600, qa=True):
    try:
        thin_ticks_auto(fig)
    except Exception as e:
        print("   tick thinning failed:", type(e).__name__, str(e)[:80])
    if qa:
        try:
            qa_layout(fig, name=os.path.basename(path))
        except Exception as e:
            print("   layout QA failed:", type(e).__name__, str(e)[:80])
        try:
            qa_axes(fig, name=os.path.basename(path))
        except Exception as e:
            print("   axes QA failed:", type(e).__name__, str(e)[:80])
        try:
            qa_full(fig, name=os.path.basename(path))
        except Exception as e:
            print("   full QA failed:", type(e).__name__, str(e)[:80])
    fig.savefig(path, dpi=dpi, facecolor=BG)
    plt.close(fig)
    print("saved", path)


def image_stats(path):
    from PIL import Image
    im = Image.open(path).convert("RGB")
    a = np.asarray(im).astype(float)
    bg = np.array([255, 255, 255], dtype=float)
    nonbg = (np.abs(a - bg).sum(2) > 24).mean()
    h, w, _ = a.shape
    quads = {}
    for qi, (ys, ye) in enumerate([(0, h // 2), (h // 2, h)]):
        for qj, (xs, xe) in enumerate([(0, w // 2), (w // 2, w)]):
            sub = a[ys:ye, xs:xe]
            quads[f"Q{qi}{qj}"] = float((np.abs(sub - bg).sum(2) > 24).mean())
    return {"size": (w, h), "nonbg_frac": float(nonbg), "quadrants": quads}
