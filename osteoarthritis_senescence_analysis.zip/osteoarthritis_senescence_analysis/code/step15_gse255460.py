"""
step15_gse255460.py — second single-cell dataset, this time with real normal controls.

GSE255460 ships 135,896 cells with pre-annotated chondrocyte subtypes and a genuine
control arm (16,507 cells), which lets us ask two questions the first single-cell
dataset could not answer: (i) is the senescence signature enriched in homeostatic
chondrocytes rather than in any cartilage cell, and (ii) does it separate control from
osteoarthritic cartilage at single-cell resolution.

The counts matrix is 10.5 GB uncompressed (genes x 135,896 cells) inside a 279 MB tar.gz,
so the script streams the archive once and keeps only the rows we need.
"""
import gzip, io, os, tarfile, csv, json
import numpy as np
import pandas as pd

TAR = "data/GSE255460_sc_counts.txt.tar.gz"
META = "data/GSE255460_metadata.csv.gz"
OUT = "data/gse255460"
os.makedirs(OUT, exist_ok=True)

SIG = ["ETS2", "GADD45B", "JUN", "CDKN1B", "UBC", "CDKN1A", "HLA-F", "CDK2"]
# Canonical subtype markers, used only to show that the pre-annotated labels behave.
MARKERS = {
    "PRG4": "HomC", "CHAD": "HomC", "ACAN": "HomC", "SOX9": "HomC", "COL2A1": "HomC",
    "CILP": "HomC", "TIMP3": "HomC", "PRELP": "HomC",
    "COL10A1": "HTC", "RUNX2": "HTC", "ALPL": "HTC", "IBSP": "HTC",
    "COL1A1": "FC", "COL1A2": "FC", "THY1": "FC",
    "IL6": "InfC", "CXCL8": "InfC", "CCL2": "InfC", "NFKB1": "InfC",
    "MKI67": "ProC", "TOP2A": "ProC", "UBE2C": "ProC",
    "PECAM1": "EC", "VWF": "EC",
}
WANT = set(SIG) | set(MARKERS)


def load_meta():
    md = pd.read_csv(META, compression="gzip")
    md["key"] = md["X"].str.replace(".", "-", regex=False)
    return md


def stream_counts():
    """Yield (gene, np.uint32 array over cells) for the genes we want, plus the header."""
    t = tarfile.open(TAR, "r:gz")
    member = t.getmember("sc_counts.txt")
    fh = t.extractfile(member)
    buf = io.BufferedReader(fh, buffer_size=1 << 22)
    header = None
    found = {}
    nline = 0
    while True:
        raw = buf.readline()
        if not raw:
            break
        nline += 1
        if nline % 5000 == 0:
            print(f"    ...{nline} rows, {len(found)} genes kept", flush=True)
        line = raw.decode("utf-8", "replace").rstrip("\n")
        if not line:
            continue
        if header is None:
            # The header has no leading corner cell: its first field is already a cell ID.
            header = line.split("\t")
            continue
        tab = line.find("\t")
        if tab < 0:
            continue
        gene = line[:tab]
        if gene not in WANT or gene in found:
            continue
        vals = line[tab + 1:].split("\t")
        if len(vals) != len(header):
            print(f"    !! {gene}: {len(vals)} values vs {len(header)} cells, skipped")
            continue
        found[gene] = np.array(vals, dtype=np.uint32)
        print(f"    kept {gene} ({len(found)}/{len(WANT)})", flush=True)
        if len(found) == len(WANT):
            break
    return header, found


def main():
    md = load_meta()
    print(f"metadata: {len(md)} cells; trait={md['trait'].value_counts().to_dict()}")
    print("streaming counts (single pass over 10.5 GB)...")
    header, found = stream_counts()
    print(f"kept {len(found)}/{len(WANT)} genes; header cells={len(header)}")

    missing = WANT - set(found)
    if missing:
        print("MISSING:", sorted(missing))

    cells = [c.replace(".", "-") for c in header]
    mat = pd.DataFrame({g: found[g] for g in found}, index=cells)
    mat.index.name = "key"

    md = md.set_index("key")
    common = mat.index.intersection(md.index)
    print(f"cells matched to metadata: {len(common)}/{len(mat)}")
    mat = mat.loc[common]
    md = md.loc[common]

    mat.to_pickle(os.path.join(OUT, "selected_genes.pkl"))
    md.to_pickle(os.path.join(OUT, "meta.pkl"))
    with open(os.path.join(OUT, "genes.json"), "w") as f:
        json.dump({"signature": SIG, "markers": MARKERS, "kept": sorted(found)}, f, indent=2)
    print("STEP15 EXTRACT DONE")


if __name__ == "__main__":
    main()
