"""Word-level layout audit: real glyph collisions, real margin violations, real image/text
overlap.  Block-level bboxes in tables routinely overlap without any glyph colliding, so the
check is done on words."""
import fitz, sys, itertools

PDF = sys.argv[1] if len(sys.argv) > 1 else "Osteoarthritis_senescence_manuscript.pdf"
d = fitz.open(PDF)
LM, RM, TM, BM = 72, d[0].rect.width - 72, 64.8, d[0].rect.height - 64.8
print(f"page box: width {d[0].rect.width:.0f} height {d[0].rect.height:.0f}; "
      f"margins L{LM} R{RM:.0f} T{TM} B{BM:.0f}")

worst_right = 0.0
n_margin = 0
n_word_overlap = 0
n_img_text = 0
for pno, page in enumerate(d, 1):
    words = page.get_text("words")          # x0,y0,x1,y1,word,block,line,wordno
    # margin violations beyond a 1pt tolerance (justification/rounding)
    for w in words:
        if w[2] > RM + 1.0 or w[0] < LM - 1.0 or w[1] < TM - 1.0 or w[3] > BM + 1.0:
            n_margin += 1
            if n_margin <= 8:
                print(f"  p{pno} WORD OUTSIDE MARGIN: {w[4]!r} bbox=({w[0]:.1f},{w[1]:.1f},{w[2]:.1f},{w[3]:.1f})")
    worst_right = max(worst_right, max((w[2] for w in words), default=0))
    # glyph collisions: compare words on the same page, ignore same-line neighbours
    for a, b in itertools.combinations(words, 2):
        if a[5] == b[5] and a[6] == b[6]:
            continue
        ra = fitz.Rect(a[:4]); rb = fitz.Rect(b[:4])
        inter = ra & rb
        if inter.is_empty or inter.width <= 0.5 or inter.height <= 0.5:
            continue
        frac = inter.get_area() / min(ra.get_area(), rb.get_area())
        if frac > 0.35:
            n_word_overlap += 1
            if n_word_overlap <= 10:
                print(f"  p{pno} GLYPH COLLISION {frac*100:.0f}%: {a[4]!r} vs {b[4]!r}")
    # image vs word
    for blk in page.get_text("blocks"):
        if blk[6] != 1:
            continue
        im = fitz.Rect(blk[:4])
        for w in words:
            rw = fitz.Rect(w[:4])
            inter = im & rw
            if inter.is_empty or inter.get_area() <= 0:
                continue
            frac = inter.get_area() / min(im.get_area(), rw.get_area())
            if frac > 0.2:
                n_img_text += 1
                if n_img_text <= 10:
                    print(f"  p{pno} IMAGE OVER WORD {frac*100:.0f}%: {w[4]!r}")

print(f"\nwords outside the margin (1pt tolerance): {n_margin}")
print(f"glyph collisions: {n_word_overlap}")
print(f"image-over-text overlaps: {n_img_text}")
print(f"rightmost glyph x1 on any page: {worst_right:.2f} (margin {RM:.2f})")
