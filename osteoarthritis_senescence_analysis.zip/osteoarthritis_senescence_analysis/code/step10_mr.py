"""
step10_mr.py — two-sample Mendelian randomisation of the eight signature genes on osteoarthritis.

Exposure : GTEx v8 single-tissue cis-eQTLs.  For each gene the tissue with the strongest cis-eQTL
           signal is used (cultured fibroblasts — the synovial-fibroblast lineage — is the best
           single tissue and is used wherever it has signal).  The API reports the normalised
           effect size (nes) and the p-value; the standard error is recovered as
           se = |nes| / |z| with z = Phi^-1(p/2), which is exact for the linear-model z-test GTEx
           reports.  Instruments are the significant cis-eQTLs (p < 1e-5) clumped at 1 Mb.
Outcome  : FinnGen R11 M13_ARTHROSIS and M13_ARTHROSIS_KNEE summary statistics, read on demand
           through the tabix index (only the gene loci are fetched from the 820 MB files).
"""
import os, sys, json, math, time
import numpy as np
import pandas as pd
import urllib.request, urllib.parse, ssl
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
from tabix_http import TabixHTTP, download, _http_range, bgzf_decompress

DATA = os.path.join(BASE, "data", "gwas"); os.makedirs(DATA, exist_ok=True)
OUT = os.path.join(BASE, "results"); os.makedirs(OUT, exist_ok=True)
CTX = ssl.create_default_context()
UA = {"User-Agent": "Mozilla/5.0", "Accept": "application/json"}

GENES = ["ETS2", "GADD45B", "JUN", "CDKN1B", "UBC", "CDKN1A", "HLA-F", "CDK2"]
TISSUES = ["Cells_Cultured_fibroblasts", "Whole_Blood", "Muscle_Skeletal",
           "Adipose_Subcutaneous", "Artery_Tibial", "Lung", "Thyroid",
           "Skin_Sun_Exposed_Lower_leg", "Nerve_Tibial", "Colon_Transverse"]
FINNGEN = {"M13_ARTHROSIS": "Arthrosis, all sites",
           "M13_ARTHROSIS_KNEE": "Gonarthrosis (knee OA)",
           "M13_ARTHTROSIS_COX": "Coxarthrosis (hip OA)",
           "M13_ARTHROSIS_KNEE_PRIM_KNEESURG": "Knee OA requiring surgery"}
CLUMP_WINDOW = 250_000
P_THRESHOLD = 1e-4
CACHE = os.path.join(DATA, "gtex_cis_eqtl_cache.json")


# ------------------------------------------------------------------ GTEx access
def _get(u, tries=4):
    for a in range(tries):
        try:
            return json.loads(urllib.request.urlopen(
                urllib.request.Request(u, headers=UA), timeout=90, context=CTX).read())
        except Exception:
            time.sleep(2)
    return None


def gtex_gencode(gene):
    j = _get(f"https://gtexportal.org/api/v2/reference/gene?geneId={urllib.parse.quote(gene)}")
    return j["data"][0]["gencodeId"] if j and j.get("data") else None


def gtex_tissue_eqtl(gid, tissue):
    j = _get("https://gtexportal.org/api/v2/association/singleTissueEqtl"
             f"?gencodeId={gid}&tissueSiteDetailId={tissue}&datasetId=gtex_v8")
    return j["data"] if j and j.get("data") else []


def build_exposure():
    """For each gene: pick the best tissue and return its cis-eQTL table (cached)."""
    if os.path.exists(CACHE):
        return json.load(open(CACHE, encoding="utf8"))
    out = {}
    for g in GENES:
        gid = gtex_gencode(g)
        if not gid:
            continue
        best, best_t = [], None
        for t in TISSUES:
            d = gtex_tissue_eqtl(gid, t)
            if len(d) > len(best):
                best, best_t = d, t
            time.sleep(0.15)
        if best:
            out[g] = {"gencodeId": gid, "tissue": best_t, "eqtls": best}
            print(f"   {g:9s} best tissue {best_t:30s} n={len(best)}")
    json.dump(out, open(CACHE, "w", encoding="utf8"))
    return out


# ------------------------------------------------------------------ MR statistics
def parse_variant(vid):
    p = vid.split("_")
    if len(p) < 4:
        return None
    try:
        return p[0].replace("chr", ""), int(p[1]), p[2].upper(), p[3].upper()
    except ValueError:
        return None


def z_from_p(p):
    return abs(stats.norm.isf(min(max(p, 1e-300), 1 - 1e-16) / 2))


def clump(df, window=1_000_000):
    df = df.sort_values("pValue")
    keep = []
    for _, r in df.iterrows():
        if all(abs(int(r["pos"]) - int(k["pos"])) > window for k in keep):
            keep.append(r)
    return pd.DataFrame(keep)


def ivw(r, s):
    w = 1.0 / np.square(s)
    return float(np.sum(w * r) / np.sum(w)), float(math.sqrt(1.0 / np.sum(w)))


def mr_egger(bx, by, sy):
    w = 1.0 / np.square(sy)
    X = np.column_stack([np.ones(len(bx)), bx]); W = np.diag(w)
    c = np.linalg.pinv(X.T @ W @ X) @ (X.T @ W @ by)
    resid = by - X @ c
    dof = max(len(bx) - 2, 1)
    s2 = float((w * resid ** 2).sum() / dof)
    cov = s2 * np.linalg.pinv(X.T @ W @ X)
    return float(c[1]), float(math.sqrt(max(cov[1, 1], 0))), float(c[0]), float(math.sqrt(max(cov[0, 0], 0)))


def wmedian(r, s):
    w = 1.0 / np.square(s); o = np.argsort(r)
    rr, ww = np.asarray(r)[o], w[o]
    cw = np.cumsum(ww) / np.sum(ww)
    k = int(np.searchsorted(cw, 0.5))
    return float(rr[min(k, len(rr) - 1)]), float(math.sqrt(1.0 / np.sum(ww)))


def cochran_q(r, s):
    w = 1.0 / np.square(s)
    b = float(np.sum(w * r) / np.sum(w))
    q = float(np.sum(w * (np.asarray(r) - b) ** 2))
    dof = max(len(r) - 1, 1)
    return q, dof, float(stats.chi2.sf(q, dof))


def finngen_header(url):
    txt = bgzf_decompress(_http_range(url, 0, 200000)).decode("utf8", "ignore")
    for line in txt.split("\n"):
        if line.startswith("#"):
            return line.lstrip("#").split("\t")
    return []


# ------------------------------------------------------------------ main
def main():
    print("=" * 96); print("EXPOSURE: GTEx v8 cis-eQTLs")
    exp = build_exposure()
    for g, d in exp.items():
        print(f"   {g:9s} {d['tissue']:30s} n_cis_eQTL={len(d['eqtls'])}")

    tb, meta = {}, {}
    for pheno in FINNGEN:
        url = ("https://storage.googleapis.com/finngen-public-data-r11/summary_stats/"
               f"finngen_R11_{pheno}.gz")
        tbi = download(url + ".tbi", os.path.join(DATA, f"finngen_R11_{pheno}.gz.tbi"))
        tb[pheno] = TabixHTTP(url, tbi)
        meta[pheno] = {"url": url, "columns": finngen_header(url),
                       "size_bytes": tb[pheno].size, "description": FINNGEN[pheno]}
        print(f"\nOUTCOME {pheno} ({FINNGEN[pheno]})  file {tb[pheno].size/1e6:.0f} MB")

    results, per_snp = [], []
    for gene, d in exp.items():
        inst = clump(pd.DataFrame(d["eqtls"]), window=CLUMP_WINDOW)
        inst = inst[inst["pValue"] < P_THRESHOLD]
        if not len(inst):
            print(f"\n{gene}: no instrument at p<{P_THRESHOLD:g} after clumping"); continue
        # one FinnGen fetch covering all instruments of this gene
        lo = int(inst["pos"].min()) - 5000
        hi = int(inst["pos"].max()) + 5000
        chrom = parse_variant(inst.iloc[0]["variantId"])[0]
        print(f"\n{gene}  tissue={d['tissue']}  instruments={len(inst)}  "
              f"chr{chrom}:{lo}-{hi}")

        for pheno, t in tb.items():
            try:
                hits = t.fetch(chrom, lo, hi)
            except Exception as e:
                print(f"   fetch failed: {type(e).__name__} {str(e)[:60]}"); continue
            by_pos = {}
            for f in hits:
                try:
                    by_pos[int(f[1])] = (f[2].upper(), f[3].upper(), float(f[8]), float(f[9]),
                                         float(f[6]))
                except Exception:
                    continue
            rows = []
            for _, e in inst.iterrows():
                v = parse_variant(e["variantId"])
                if not v:
                    continue
                _, pos, ref, alt = v
                if pos not in by_pos:
                    continue
                fref, falt, b_out, se_out, p_out = by_pos[pos]
                if (fref, falt) == (ref, alt):
                    pass
                elif (fref, falt) == (alt, ref):
                    b_out = -b_out
                else:
                    continue
                b_exp = float(e["nes"]); z = z_from_p(float(e["pValue"]))
                se_exp = abs(b_exp) / z if z > 0 else np.nan
                if not np.isfinite(se_exp) or se_exp <= 0 or abs(b_exp) < 1e-8:
                    continue
                rows.append({"gene": gene, "tissue": d["tissue"], "phenotype": pheno,
                             "snp": e["snpId"], "chrom": chrom, "pos": pos, "ref": ref, "alt": alt,
                             "b_eqtl": b_exp, "se_eqtl": se_exp, "p_eqtl": float(e["pValue"]),
                             "b_oa": b_out, "se_oa": se_out, "p_oa": p_out,
                             "ratio": b_out / b_exp, "se_ratio": abs(se_out / b_exp),
                             "F": (b_exp / se_exp) ** 2})
            if not rows:
                # diagnose why nothing harmonised
                why = []
                for _, e in inst.iterrows():
                    v = parse_variant(e["variantId"])
                    if not v:
                        why.append("unparseable variantId"); continue
                    _, pos, ref, alt = v
                    if pos not in by_pos:
                        why.append(f"pos {pos} absent from outcome")
                    else:
                        fr, fa = by_pos[pos][0], by_pos[pos][1]
                        if (fr, fa) != (ref, alt) and (fr, fa) != (alt, ref):
                            why.append(f"pos {pos} allele mismatch {ref}/{alt} vs {fr}/{fa}")
                print(f"   {pheno}: no harmonised SNPs  [{len(hits)} outcome variants in region]  "
                      f"{'; '.join(why[:3])}")
                continue
            df = pd.DataFrame(rows); per_snp.append(df)
            r, s = df["ratio"].values, df["se_ratio"].values
            if len(df) == 1:
                b, se, method = float(r[0]), float(s[0]), "Wald ratio"
                egg = (np.nan,) * 4; med = (np.nan, np.nan); q = (np.nan, np.nan, np.nan)
            else:
                b, se = ivw(r, s); method = f"IVW ({len(df)})"
                egg = mr_egger(df["b_eqtl"].values, df["b_oa"].values, df["se_oa"].values) \
                    if len(df) >= 3 else (np.nan,) * 4
                med = wmedian(r, s) if len(df) >= 3 else (np.nan, np.nan)
                q = cochran_q(r, s)
            p = 2 * stats.norm.sf(abs(b / se)) if se > 0 else np.nan
            # smallest OR this design could detect with 80% power (two-sided 5%)
            detectable = math.exp(2.802 * se)
            results.append({"gene": gene, "tissue": d["tissue"], "phenotype": pheno,
                            "n_snp": len(df), "method": method,
                            "OR": math.exp(b), "OR_lo": math.exp(b - 1.96 * se),
                            "OR_hi": math.exp(b + 1.96 * se), "beta": b, "se": se, "p": p,
                            "F_mean": float(df["F"].mean()),
                            "detectable_OR_80pct": detectable,
                            "egger_intercept": egg[2], "egger_intercept_se": egg[3],
                            "wmed_beta": med[0], "Q": q[0], "Q_p": q[2]})
            print(f"   -> {pheno:20s} {method:14s} OR={math.exp(b):.3f} "
                  f"({math.exp(b-1.96*se):.3f}-{math.exp(b+1.96*se):.3f}) p={p:.3g} "
                  f"meanF={df['F'].mean():.0f}")

    res = pd.DataFrame(results); snp = pd.concat(per_snp, ignore_index=True) if per_snp else pd.DataFrame()
    if len(res):
        # Benjamini-Hochberg across all gene-outcome tests
        o = np.argsort(res["p"].values)
        n = len(res)
        adj = np.empty(n)
        ranked = res["p"].values[o] * n / (np.arange(n) + 1)
        ranked = np.minimum.accumulate(ranked[::-1])[::-1]
        adj[o] = np.clip(ranked, 0, 1)
        res["p_fdr"] = adj
    res.to_csv(os.path.join(OUT, "mr_results.csv"), index=False)
    snp.to_csv(os.path.join(OUT, "mr_instrument_snps.csv"), index=False)
    json.dump(meta, open(os.path.join(OUT, "mr_data_sources.json"), "w"), indent=1)
    print("\n" + "=" * 96)
    print(res.round(4).to_string(index=False) if len(res) else "NO ESTIMATES")
    print(f"\nwrote mr_results.csv ({len(res)} estimates) and mr_instrument_snps.csv ({len(snp)} SNPs)")


if __name__ == "__main__":
    main()
