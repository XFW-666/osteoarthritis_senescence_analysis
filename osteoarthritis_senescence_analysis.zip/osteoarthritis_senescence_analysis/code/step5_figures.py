"""
step5_figures.py — Figures 2-8, redesigned so each figure has its own visual centre of
gravity instead of one repeated panel template.  Palette, typography and panel-letter
conventions are held constant across the set.

  Fig 2  hero volcano (tall) + satellites + full-width strip
  Fig 3  full-width dendrogram hero + satellites
  Fig 4  ONE unified dot matrix across all six libraries + summary column
  Fig 5  network hero + polar hub ranking + expression + correlation
  Fig 6  performance dashboard: large ROC with zoom inset + strips
  Fig 7  nomogram hero + external-validation forest plot
  Fig 8  composition / flow: stacked composition + chord map of compounds to genes
"""
import os, sys, json, re
import numpy as np
import pandas as pd
from scipy import stats
from scipy.cluster import hierarchy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle, Ellipse
import matplotlib.patheffects as pe
import networkx as nx
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_curve, roc_auc_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from viz_style import (NEON, CYCLE, BG, GRID, TXT, MUTED, ACCENT, apply_style,
                       neon_axes, neon_line, neon_scatter, neon_bar, neon_text, save, add_sig, thin_ticks)
import fig_helpers as H

BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); OUT = os.path.join(BASE, "results")
FIG = os.path.join(BASE, "figures"); os.makedirs(FIG, exist_ok=True)
apply_style()


def load(acc):
    e = pd.read_csv(os.path.join(WORK, f"expr_{acc}.csv"), index_col=0)
    l = pd.read_csv(os.path.join(WORK, f"labels_{acc}.csv"), index_col=0).iloc[:, 0]
    return e, l


def J(name):
    return json.load(open(os.path.join(OUT, name), encoding="utf8"))


# ==================================================================== FIGURE 2
def figure2():
    expr, labels = load("GSE114007")
    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)
    cohorts = json.load(open(os.path.join(WORK, "cohorts.json"), encoding="utf8"))
    srg = set(J("senescence_gene_universe.json"))
    y = (labels == "OA").astype(int).values

    fig = plt.figure(figsize=(16.6, 11.6), facecolor=BG)
    gs = fig.add_gridspec(3, 3, height_ratios=[1, 1, 0.70], hspace=0.42, wspace=0.34,
                          left=0.065, right=0.975, top=0.935, bottom=0.075)

    # ---- A: hero volcano
    ax = fig.add_subplot(gs[0:2, 0]); neon_axes(ax)
    lf = deg["logFC"].values; lp = -np.log10(np.clip(deg["P.Value"].values, 1e-300, None))
    sig = (deg["adj.P.Val"] < 0.05).values & (np.abs(lf) > 1)
    is_sen = deg.index.isin(srg)
    ax.scatter(lf[~sig & ~is_sen], lp[~sig & ~is_sen], s=7, c="#CBD5E3", alpha=0.75,
               zorder=2, linewidths=0)
    neon_scatter(ax, lf[sig & ~is_sen], lp[sig & ~is_sen], NEON["blue"], size=12, alpha=0.55)
    neon_scatter(ax, lf[is_sen & ~sig], lp[is_sen & ~sig], NEON["amber"], size=26, alpha=0.9)
    neon_scatter(ax, lf[is_sen & sig], lp[is_sen & sig], NEON["magenta"], size=52, alpha=1.0,
                 edge="#FFFFFF", lw=0.8)
    ax.axvline(1, color=MUTED, ls=":", lw=0.9); ax.axvline(-1, color=MUTED, ls=":", lw=0.9)
    ax.axhline(-np.log10(0.05), color=MUTED, ls=":", lw=0.9)
    lab_items = []
    for g in ["IGFBP3", "CDKN1A", "JUN", "GADD45B", "CCND1", "EZH2", "CDKN2B", "MYC",
              "TWIST1", "FOS"]:
        if g in deg.index:
            i = list(deg.index).index(g)
            lab_items.append((lf[i], lp[i], g))
    # them anywhere to declutter, which broke the match between a label and its dot; here the
    # de-collide step is bounded, so a label can never travel far from the point it names.
    placed_boxes = []
    cand = [(8, 9), (8, -11), (-9, 9), (-9, -11), (16, 15), (-16, 15), (16, -17), (-16, -17),
            (26, 20), (-26, 20), (26, -22), (-26, -22)]
    for x0, y0, g in sorted(lab_items, key=lambda t: -t[1]):
        pt = ax.transData.transform((x0, y0))
        wdt = len(g) * 7.4 * 0.60
        chosen = None
        for dx, dy in cand:
            cx, cy = pt[0] + dx, pt[1] + dy
            box = (cx, cy - 5.0, cx + wdt, cy + 5.0)
            if not any(not (box[2] < b[0] or b[2] < box[0] or box[3] < b[1] or b[3] < box[1])
                       for b in placed_boxes):
                chosen = (dx, dy, box)
                break
        if chosen is None:
            chosen = (30, 24, None)
        if chosen[2] is not None:
            placed_boxes.append(chosen[2])
        ax.annotate(g, xy=(x0, y0), xytext=(chosen[0], chosen[1]), textcoords="offset points",
                    fontsize=7.4, color="#8A1140", fontweight="bold", zorder=9,
                    ha="left", va="center",
                    arrowprops=dict(arrowstyle="-", lw=0.8, color="#8A1140", alpha=0.75,
                                    shrinkA=0, shrinkB=2.5),
                    path_effects=[pe.withStroke(linewidth=2.2, foreground="#FFFFFF")])
    ax.text(-4.2, ax.get_ylim()[1] * 0.955, "suppressed in OA", color=NEON["blue"],
            fontsize=10, fontweight="bold", style="italic")
    ax.text(2.0, ax.get_ylim()[1] * 0.955, "induced in OA", color=NEON["magenta"],
            fontsize=10, fontweight="bold", style="italic")
    ax.set_xlabel("$\\log_2$ fold change (OA / normal)"); ax.set_ylabel("$-\\log_{10}$ P")
    ax.set_title("Differential expression landscape")
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color=NEON["magenta"],
                              label="senescence DEG"),
                       Line2D([], [], marker="o", ls="", color=NEON["amber"],
                              label="senescence gene"),
                       Line2D([], [], marker="o", ls="", color=NEON["blue"], label="other DEG")],
              loc="lower right", fontsize=8)
    H.letter(ax, "A")

    # ---- B: PCA
    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    v = expr.var(1).sort_values(ascending=False)
    Xp = StandardScaler().fit_transform(expr.loc[v.index[:2000]].T.values)
    pca = PCA(2).fit(Xp); P = pca.transform(Xp)
    for mask, col in [(y == 0, NEON["blue"]), (y == 1, NEON["magenta"])]:
        pts = P[mask]
        cov = np.cov(pts.T)
        ev, evec = np.linalg.eigh(cov)
        o_ = ev.argsort()[::-1]
        ev, evec = ev[o_], evec[:, o_]
        ang = np.degrees(np.arctan2(evec[1, 0], evec[0, 0]))
        ax.add_patch(Ellipse(pts.mean(0), 2 * 2.0 * np.sqrt(ev[0]), 2 * 2.0 * np.sqrt(ev[1]),
                             angle=ang, facecolor=col, alpha=0.09, edgecolor=col,
                             lw=1.4, ls="--", zorder=1))
    neon_scatter(ax, P[y == 0, 0], P[y == 0, 1], NEON["blue"], size=54, label="Normal",
                 edge="#FFFFFF", lw=0.7)
    neon_scatter(ax, P[y == 1, 0], P[y == 1, 1], NEON["magenta"], size=54, label="OA",
                 edge="#FFFFFF", lw=0.7)
    ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)")
    ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)")
    ax.set_title("Principal component analysis")
    ax.legend(loc="best", fontsize=8, title="95% ellipse", title_fontsize=7.6)
    H.letter(ax, "B")

    # ---- C: senescence programme score
    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    h = pd.read_csv(os.path.join(OUT, "ssgsea_hallmark.csv"), index_col=0)
    s = h[[c for c in h.columns if "Senescence" in c][0]]
    a = s.loc[labels == "OA"].values; b = s.loc[labels == "Normal"].values
    pv = stats.mannwhitneyu(a, b, alternative="two-sided")[1]
    H.box2(ax, b, a, [0, 1], NEON["blue"], NEON["magenta"], width=0.5)
    for i, (v_, c) in enumerate([(b, NEON["blue"]), (a, NEON["magenta"])]):
        ax.scatter(np.random.default_rng(3 + i).normal(i, 0.055, len(v_)), v_, s=28,
                   color=c, alpha=0.85, zorder=6, edgecolors="#FFFFFF", linewidths=0.5)
    # the P value is already in the panel title; a bracket here rose above the title
    ax.set_xticks([0, 1]); ax.set_xticklabels([f"Normal\n(n={len(b)})", f"OA\n(n={len(a)})"])
    ax.set_ylabel("ssGSEA score")
    ax.set_title(f"Senescence-programme activity  (P = {pv:.1e})")
    H.letter(ax, "C", x=-0.24, y=1.07)

    # ---- D: cohort composition
    ax = fig.add_subplot(gs[1, 1]); neon_axes(ax)
    keys = [k for k in ["GSE114007", "GSE169077", "GSE283079", "GSE55235", "GSE55457"]
            if k in cohorts]
    oa = [cohorts[k]["oa"] for k in keys]; no = [cohorts[k]["normal"] for k in keys]
    yy = np.arange(len(keys))[::-1]
    neon_bar(ax, yy + 0.19, oa, NEON["magenta"], width=0.34, label="OA")
    neon_bar(ax, yy - 0.19, no, NEON["blue"], width=0.34, label="Normal")
    ax.set_yticks(yy); ax.set_yticklabels([f"{k} ({o}/{n})" for k, o, n in zip(keys, oa, no)],
                                          fontsize=8)
    ax.set_xlabel("samples"); ax.set_title("Cohorts analysed")
    ax.legend(fontsize=6.2, loc="lower right", bbox_to_anchor=(1.0, -0.02), frameon=False,
              handlelength=0.9, handleheight=0.8, labelspacing=0.28, borderpad=0.2)
    ax.set_ylim(-0.75, len(keys) - 0.25)
    H.letter(ax, "D")

    # ---- E: top-DEG heatmap
    ax = fig.add_subplot(gs[1, 2])
    top = deg[deg["adj.P.Val"] < 0.05].reindex(
        deg["logFC"].abs().sort_values(ascending=False).index).head(26).index
    M = expr.loc[top]
    Mz = M.sub(M.mean(1), axis=0).div(M.std(1).replace(0, np.nan), axis=0)
    ordr = np.argsort(y)
    H.heatmap(ax, Mz.iloc[:, ordr].values, H.DIV_CMAP, "row z-score", xticklabels=False,
              ytick_fs=6.6, vmin=-2.2, vmax=2.2)
    n_norm = int((y == 0).sum())
    ax.axvline(n_norm - 0.5, color=TXT, lw=1.4, ls="--")
    ax.set_title("Top 26 differentially expressed genes")
    H.letter(ax, "E", x=-0.30)

    # ---- F: senescence-gene fold changes (full-width strip)
    ax = fig.add_subplot(gs[2, :]); neon_axes(ax)
    ds = deg[deg.index.isin(srg)].sort_values("logFC")
    cols = [NEON["blue"] if v < 0 else NEON["magenta"] for v in ds["logFC"]]
    neon_bar(ax, np.arange(len(ds)), ds["logFC"], cols, width=0.74)
    ax.set_xticks(np.arange(len(ds)))
    ax.set_xticklabels(ds.index, rotation=90, fontsize=6.6)
    ax.axhline(0, color=TXT, lw=0.9)
    ax.set_ylabel("$\\log_2$ FC (OA / normal)")
    ax.set_title(f"All {len(ds)} senescence-universe genes detected in the discovery cohort")
    ax.set_xlim(-0.8, len(ds) - 0.2)
    H.letter(ax, "F", x=-0.055)
    save(fig, os.path.join(FIG, "Figure2_transcriptomic_landscape.png"))


# ==================================================================== FIGURE 3
def figure3():
    expr, labels = load("GSE114007")
    wg = J("wgcna_modules.json"); fits = J("soft_threshold_fits.json")
    lab = pd.read_csv(os.path.join(OUT, "module_assignment.csv"), index_col=0).iloc[:, 0]
    ME = pd.read_csv(os.path.join(OUT, "module_eigengenes.csv"), index_col=0)
    ME.columns = [int(c) for c in ME.columns]
    Z = np.load(os.path.join(OUT, "wgcna_linkage.npy"))
    wgenes = J("wgcna_genes.json")
    srg = set(J("senescence_gene_universe.json"))
    srd = pd.read_csv(os.path.join(OUT, "SRDEGs.csv"), index_col=0)
    mods = {int(k): v for k, v in wg["modules"].items()}
    ms = sorted(mods)
    colors = {m: CYCLE[i % len(CYCLE)] for i, m in enumerate(ms)}

    fig = plt.figure(figsize=(16.8, 12.4), facecolor=BG)
    gs = fig.add_gridspec(3, 3, height_ratios=[1.05, 0.92, 0.92], hspace=0.50, wspace=0.34,
                          left=0.055, right=0.975, top=0.94, bottom=0.07)

    # ---- D: full-width dendrogram hero
    ax = fig.add_subplot(gs[0, :])
    order_lab = lab.reindex(wgenes).values
    strip = [colors.get(int(m), "#9AA9C0") for m in order_lab]
    hierarchy.dendrogram(Z, no_labels=True, color_threshold=0, above_threshold_color="#9AA9C0",
                         link_color_func=lambda k: "#9AA9C0")
    ax.set_title(f"Co-expression dendrogram — {len(mods)} modules resolved at cut height "
                 f"{wg['cut_height']}")
    ax.set_ylabel("1 − r"); ax.grid(False)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    axb = ax.inset_axes([0.0, -0.11, 1.0, 0.055])
    axb.set_xlim(0, len(strip)); axb.set_ylim(0, 1); axb.axis("off")
    for i, c in enumerate(strip):
        axb.add_patch(Rectangle((i, 0), 1, 1, color=c, lw=0))
    ax.legend(handles=[Patch(facecolor=colors[m], edgecolor="none",
                             label=f"M{m} ({mods[m]['n_genes']})") for m in ms],
              ncol=1, fontsize=7.0, loc="upper left", bbox_to_anchor=(1.012, 1.0),
              frameon=False, handlelength=1.0, labelspacing=0.30, borderpad=0.2)
    H.letter(ax, "A", x=-0.045)

    # ---- B: soft-threshold
    ax = fig.add_subplot(gs[1, 0]); neon_axes(ax)
    bs = sorted(int(b) for b in fits); r2 = [fits[str(b)] for b in bs]
    neon_line(ax, bs, r2, NEON["blue"], lw=2.2, label="scale-free fit $R^2$")
    ax.axhline(0.8, color=NEON["amber"], ls="--", lw=1.2)
    neon_text(ax, max(bs) * 0.40, 0.816, "$R^2$ = 0.8", NEON["amber"], size=8, weight="normal")
    ax.axvline(wg["beta"], color=NEON["magenta"], ls=":", lw=1.6)
    neon_text(ax, wg["beta"] + 0.35, min(r2) + 0.012, f"$\\beta$ = {wg['beta']}",
              NEON["magenta"], size=9)
    ax2 = ax.twinx(); ax2.set_facecolor("none")
    X = expr.loc[wgenes].values.astype(float)
    X = (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-12)
    ax2.plot(bs, [float((np.abs((X @ X.T) / X.shape[1]) ** b).sum(1).mean()) for b in bs],
             color=NEON["teal"], lw=1.6, ls="--", marker="o", ms=3, label="mean connectivity")
    ax2.set_yscale("log"); ax2.set_ylabel("mean connectivity", color=NEON["teal"], fontsize=8.5)
    ax2.tick_params(axis="y", colors=NEON["teal"], labelsize=7.5)
    for s in ax2.spines.values():
        s.set_color("#9AA9C0")
    ax2.spines["top"].set_visible(False)
    ax.set_xlabel("soft-thresholding power $\\beta$"); ax.set_ylabel("scale-free fit $R^2$")
    ax.set_title("Network construction")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper center", bbox_to_anchor=(0.5, -0.26), ncol=2,
              fontsize=7.4, frameon=False, columnspacing=1.1, handlelength=1.2)
    H.letter(ax, "B")

    # ---- C: module size / senescence content
    ax = fig.add_subplot(gs[1, 1]); neon_axes(ax)
    xs = np.arange(len(ms))
    sizes = [mods[m]["n_genes"] for m in ms]
    sen = [len(set(mods[m]["genes"]) & srg) for m in ms]
    neon_bar(ax, xs, sizes, "#C9D6EA", width=0.72, label="all genes")
    neon_bar(ax, xs, [c * 4 for c in sen], NEON["green"], width=0.42,
             label="senescence genes (×4)")
    for x, s_, c_ in zip(xs, sizes, sen):
        if c_:
            neon_text(ax, x, s_ + max(sizes) * 0.022, str(c_), NEON["green"], size=7.6, ha="center")
    ax.set_xticks(xs); ax.set_xticklabels([f"M{m}" for m in ms], fontsize=8)
    ax.set_ylabel("genes per module"); ax.set_title("Module size and senescence content")
    ax.legend(fontsize=8); H.letter(ax, "C", x=-0.30, y=1.07)

    # ---- D2: convergent evidence
    ax = fig.add_subplot(gs[1, 2]); neon_axes(ax)
    sig_mods = [m for m in ms if mods[m]["p_OA"] < 0.05]
    mod_genes = set().union(*[set(mods[m]["genes"]) for m in sig_mods]) if sig_mods else set()
    srd_set = set(srd.index)
    vals = [len(srd_set), len(mod_genes & srg), len(srd_set & mod_genes),
            len(srd_set & mod_genes & srg)]
    names = ["senescence-\nrelated DEGs", "senescence genes\nin OA modules",
             "DEGs in OA\nmodules", "all three\ncriteria"]
    cols = [NEON["violet"], NEON["blue"], NEON["magenta"], NEON["green"]]
    neon_bar(ax, np.arange(4), vals, cols, width=0.62)
    for i, v in enumerate(vals):
        neon_text(ax, i, v + max(vals) * 0.03, str(v), cols[i], size=10.5, ha="center")
    ax.set_xticks(np.arange(4)); ax.set_xticklabels(names, fontsize=8)
    ax.set_ylabel("number of genes"); ax.set_title("Convergent evidence")
    ax.set_ylim(0, max(vals) * 1.22); H.letter(ax, "D")

    # ---- E: module-trait (wide)
    ax = fig.add_subplot(gs[2, 0:2])
    R = np.array([mods[m]["r_OA"] for m in ms]).reshape(-1, 1)
    P = np.array([mods[m]["p_OA"] for m in ms]).reshape(-1, 1)
    H.heatmap(ax, R, H.DIV_CMAP, "Pearson r vs OA", xticklabels=False, ytick_fs=8,
              vmin=-1, vmax=1)
    ax.set_xticks([0]); ax.set_xticklabels(["OA status"], fontsize=9)
    for i, (r_, p_) in enumerate(zip(R[:, 0], P[:, 0])):
        st = "***" if p_ < 1e-3 else "**" if p_ < 0.01 else "*" if p_ < 0.05 else ""
        ax.text(0, i, f"{r_:+.2f}{st}", ha="center", va="center", fontsize=7.6,
                fontweight="bold", color=TXT)
    ax.set_title("Module–trait relationships"); H.letter(ax, "E", x=-0.10)

    # ---- F: eigengene correlation
    ax = fig.add_subplot(gs[2, 2])
    C = ME[ms].corr()
    H.heatmap(ax, C.values, H.DIV_CMAP, "eigengene r", xtick_fs=7.6, ytick_fs=7.6,
              vmin=-1, vmax=1)
    ax.set_xticks(np.arange(len(ms))); ax.set_xticklabels([f"M{m}" for m in ms], fontsize=7.6)
    ax.set_yticks(np.arange(len(ms))); ax.set_yticklabels([f"M{m}" for m in ms], fontsize=7.6)
    ax.set_title("Module eigengene coordination"); H.letter(ax, "F", x=-0.16)
    save(fig, os.path.join(FIG, "Figure3_coexpression_modules.png"))


# ==================================================================== FIGURE 4
def figure4():
    enr = J("enrichr_SRDEGs.json")
    LIBS = [("GO_Biological_Process_2023", "GO:BP"), ("KEGG_2021_Human", "KEGG"),
            ("Reactome_2022", "Reactome"), ("WikiPathway_2023_Human", "WikiPathway"),
            ("MSigDB_Hallmark_2020", "Hallmark"), ("DisGeNET", "DisGeNET")]
    rows = []
    for i, (lib, short) in enumerate(LIBS):
        for r in enr.get(lib, [])[:10]:
            rows.append({"term": r["term"], "short": short, "lib": i, "p": r["pval"],
                         "n": r["n_overlap"]})
    df = pd.DataFrame(rows).sort_values("p").reset_index(drop=True)
    # keep the terms grouped by library so the bands read as blocks
    df["__o"] = df["lib"]
    df = df.sort_values(["__o", "p"]).reset_index(drop=True)
    lib_counts = [(s, len(enr.get(l, [])), min([r["pval"] for r in enr.get(l, [])] or [np.nan]))
                  for l, s in LIBS]
    n_srd = len(pd.read_csv(os.path.join(OUT, "SRDEGs.csv"), index_col=0))

    fig = plt.figure(figsize=(15.8, 12.0), facecolor=BG)
    gs = fig.add_gridspec(1, 2, width_ratios=[2.15, 1.0], wspace=0.26,
                          left=0.315, right=0.975, top=0.925, bottom=0.075)

    # ---- A: ONE unified dot matrix
    ax = fig.add_subplot(gs[0, 0])
    labels = [f"[{s}] {t[:42]}" for t, s in zip(df["term"], df["short"])]
    xv = -np.log10(np.clip(df["p"].values, 1e-300, None))
    H.dot_matrix(ax, df["term"], xv, 42 + df["n"].values * 30,
                 [H.LIB_COLORS[i] for i in df["lib"]], labels,
                 f"Over-representation of the {n_srd} senescence-related DEGs "
                 f"across six curated libraries",
                 "$-\\log_{10}$ P", group_of_row=list(df["short"]))
    for i in range(len(df)):
        neon_text(ax, xv[i] + 0.55, len(df) - i - 1, f"{df['n'].values[i]}",
                  H.LIB_COLORS[df['lib'].values[i]], size=7.2, ha="left")
    ax.set_xlim(-0.6, max(xv) * 1.20)
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color=H.LIB_COLORS[i], label=s)
                       for i, (l, s) in enumerate(LIBS)],
              loc="lower right", fontsize=8, ncol=2, title="library", title_fontsize=8)
    H.letter(ax, "A", x=-0.50)

    # ---- B: per-library summary
    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    names = [s for s, _, _ in lib_counts]
    cnt = [c for _, c, _ in lib_counts]
    best = [-np.log10(max(p, 1e-300)) for _, _, p in lib_counts]
    yy = np.arange(len(names))[::-1]
    neon_bar(ax, yy, best, [H.LIB_COLORS[i] for i in range(len(names))], width=0.6)
    for i, (b_, c_) in enumerate(zip(best, cnt)):
        neon_text(ax, b_ + 0.4, yy[i], f"{c_} terms", MUTED, size=7.6, ha="left", weight="normal")
    ax.set_yticks(yy); ax.set_yticklabels(names, fontsize=8.6)
    ax.set_xlabel("best $-\\log_{10}$ P in library")
    ax.set_title("Per-library signal strength")
    ax.set_xlim(0, max(best) * 1.42)
    H.letter(ax, "B", x=-0.36)
    save(fig, os.path.join(FIG, "Figure4_functional_enrichment.png"))


# ==================================================================== FIGURE 5
def figure5():
    net = pd.read_csv(os.path.join(OUT, "string_network.tsv"), sep="\t")
    hub = pd.read_csv(os.path.join(OUT, "ppi_hub_ranking.csv"))
    expr, labels = load("GSE114007")
    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)
    G = nx.Graph()
    for _, r in net.iterrows():
        G.add_edge(r["preferredName_A"], r["preferredName_B"], weight=float(r["score"]))
    G.remove_nodes_from(list(nx.isolates(G)))

    fig = plt.figure(figsize=(16.6, 11.6), facecolor=BG)
    gs = fig.add_gridspec(2, 3, hspace=0.26, wspace=0.30, left=0.05, right=0.975,
                          top=0.935, bottom=0.06)

    # ---- A: network hero (tall)
    ax = fig.add_subplot(gs[:, 0]); ax.axis("off")
    pos = nx.spring_layout(G, seed=11, k=0.95, iterations=600)
    mcc = dict(zip(hub["gene"], hub["MCC"])); lfc = dict(zip(deg.index, deg["logFC"]))
    for u, v in G.edges():
        ax.plot([pos[u][0], pos[v][0]], [pos[u][1], pos[v][1]], color="#B9C7DA", lw=1.1, zorder=1)
    # declutter them, which broke the one-to-one match between a ball and its gene name.
    for n in G.nodes():
        size = 190 + 30 * mcc.get(n, 0)
        col = NEON["magenta"] if lfc.get(n, 0) > 0 else NEON["blue"]
        px, py = pos[n]
        ax.scatter(px, py, s=size, c=col, alpha=0.95, zorder=4,
                   edgecolors="#FFFFFF", linewidths=0.9)
        ax.text(px, py, n, fontsize=6.4, ha="center", va="center", color=TXT,
                fontweight="bold", zorder=7,
                path_effects=[pe.withStroke(linewidth=2.4, foreground="#FFFFFF")])
    ax.set_title(f"STRING network: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges",
               pad=10)
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color=NEON["magenta"], label="up in OA"),
                       Line2D([], [], marker="o", ls="", color=NEON["blue"], label="down in OA")],
              loc="lower center", fontsize=8, ncol=2)
    H.letter(ax, "A", x=0.0, y=1.02)

    # ---- B: polar hub ranking
    ax = fig.add_subplot(gs[0, 1], projection="polar")
    h = hub.head(14)
    H.radial_bar(ax, h["gene"].tolist(), h["MCC"].values,
                 [NEON["magenta"] if lfc.get(g, 0) > 0 else NEON["blue"] for g in h["gene"]],
                 "Hub ranking (maximal clique centrality)", label_fs=7.6, gap=0.10)
    H.letter(ax, "B", x=-0.12, y=1.10)

    # ---- C: hub expression
    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    top6 = [g for g in hub.head(6)["gene"].tolist() if g in expr.index]
    for i, g in enumerate(top6):
        a = expr.loc[g, labels == "OA"].values; b = expr.loc[g, labels == "Normal"].values
        p = stats.mannwhitneyu(a, b, alternative="two-sided")[1]
        H.box2(ax, b, a, [i * 2, i * 2 + 0.72], NEON["blue"], NEON["magenta"], width=0.58)
        ax.text(i * 2 + 0.36, max(a.max(), b.max()) * 1.05,
                "***" if p < 1e-3 else "**" if p < 0.01 else "*" if p < 0.05 else "ns",
                ha="center", color=TXT, fontsize=9.5, fontweight="bold")
    ax.set_xticks([i * 2 + 0.36 for i in range(len(top6))])
    ax.set_xticklabels(top6, fontsize=9)
    ax.set_ylabel("normalised expression"); ax.set_title("Hub-gene expression", pad=11)
    ax.legend(handles=[Patch(facecolor=NEON["blue"], alpha=0.45, label="Normal"),
                       Patch(facecolor=NEON["magenta"], alpha=0.45, label="OA")],
              fontsize=8, loc="upper left")
    H.letter(ax, "C")

    # ---- D: hub correlation (wide)
    ax = fig.add_subplot(gs[1, 1:3])
    hg = [g for g in hub.head(16)["gene"].tolist() if g in expr.index]
    H.heatmap(ax, expr.loc[hg].T.corr().values, H.DIV_CMAP, "Pearson r",
              xtick_fs=7.6, ytick_fs=7.6, vmin=-1, vmax=1)
    ax.set_xticks(np.arange(len(hg))); ax.set_xticklabels(hg, rotation=90, fontsize=7.6)
    ax.set_yticks(np.arange(len(hg))); ax.set_yticklabels(hg, fontsize=7.6)
    ax.set_title("Coordination among hub genes"); H.letter(ax, "D", x=-0.09)
    save(fig, os.path.join(FIG, "Figure5_ppi_hub_network.png"))


# ==================================================================== FIGURE 6
def figure6():
    sel = pd.read_csv(os.path.join(OUT, "feature_selection.csv"))
    bench = pd.read_csv(os.path.join(OUT, "model_benchmark.csv"))
    sv = np.load(os.path.join(OUT, "shap_values.npy"))
    shapX = pd.read_csv(os.path.join(OUT, "shap_X.csv"))
    oof = J("oof_predictions.json")
    expr, labels = load("GSE114007")
    y = (labels == "OA").astype(int).values

    fig = plt.figure(figsize=(16.8, 11.8), facecolor=BG)
    gs = fig.add_gridspec(3, 3, height_ratios=[1, 1, 0.95], hspace=0.46, wspace=0.34,
                          left=0.105, right=0.975, top=0.93, bottom=0.075)

    # ---- A: model x metric matrix (hero).  A ROC curve is the wrong hero here: with AUC = 1.000
    # for 12 of 14 models the curves are degenerate step functions and the panel looks empty.
    ax = fig.add_subplot(gs[0:2, 0:2])
    METRICS = ["AUC", "PR_AUC", "accuracy", "sensitivity", "specificity", "PPV", "NPV", "F1", "MCC"]
    NAMES = ["AUC", "PR-AUC", "Accuracy", "Sensitivity", "Specificity", "PPV", "NPV", "F1", "MCC"]
    b = bench.sort_values("AUC", ascending=False).reset_index(drop=True)
    M = b[METRICS].values.astype(float)
    im = ax.imshow(M, cmap=H.SEQ_CMAP, aspect="auto", vmin=0.30, vmax=1.0)
    ax.set_xticks(np.arange(len(METRICS)))
    ax.set_xticklabels(NAMES, rotation=38, ha="right", fontsize=8.6)
    ax.set_yticks(np.arange(len(b)))
    ax.set_yticklabels(b["model"], fontsize=8.6)
    ax.grid(False)
    for s in ax.spines.values():
        s.set_color("#9AA9C0")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=7.2,
                    color="#FFFFFF" if v > 0.78 else TXT, fontweight="bold")
    cb = plt.colorbar(im, ax=ax, fraction=0.030, pad=0.015)
    cb.set_label("metric value", fontsize=8.5, color=TXT)
    cb.ax.tick_params(colors=MUTED, labelsize=7.5); cb.outline.set_edgecolor("#9AA9C0")
    ax.set_title(f"Discrimination and classification metrics — {len(b)} classifiers "
                 f"under nested 5×5 cross-validation", fontsize=11)
    H.letter(ax, "A", pts=(-34, 4))

    # ---- B: nested-CV ROC (compact; no zoom inset, which adds nothing at AUC = 1.000)
    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    order = bench.sort_values("AUC", ascending=False)["model"].tolist()
    for i, name in enumerate(order[:6]):
        if name not in oof:
            continue
        fpr, tpr, _ = roc_curve(y, oof[name])
        ax.plot(fpr, tpr, color=CYCLE[i % len(CYCLE)], lw=2.6 if i < 3 else 1.4,
                alpha=1.0 if i < 3 else 0.55,
                label=f"{name} ({bench.set_index('model').loc[name,'AUC']:.3f})")
    # the discovery cohort is completely separated, so its curves carry no information on
    # their own; the four external cohorts are what actually test the signature
    ext = json.load(open(os.path.join(OUT, "external_predictions.json")))
    for acc in ["GSE169077", "GSE55235", "GSE55457", "GSE283079"]:
        if acc not in ext:
            continue
        yy_ = np.array(ext[acc]["y"]); pp_ = np.array(ext[acc]["p"])
        fpr_e, tpr_e, _ = roc_curve(yy_, pp_)
        col = NEON["magenta"] if acc == "GSE283079" else NEON["teal"]
        ax.plot(fpr_e, tpr_e, color=col, lw=1.7, ls="--", alpha=0.9,
                label=f"{acc}  AUC {ext[acc]['auc']:.3f}")
    ax.plot([0, 1], [0, 1], color=MUTED, lw=1.0, ls=":")
    ax.set_xlabel("1 − specificity"); ax.set_ylabel("sensitivity")
    ax.set_title("ROC: discovery (nested CV, solid) and external cohorts (dashed)")
    ax.legend(fontsize=6.2, loc="lower right", handlelength=1.2, labelspacing=0.3)
    H.letter(ax, "B", x=-0.28)

    # ---- C: AUC forest
    ax = fig.add_subplot(gs[1, 2]); neon_axes(ax)
    pg = pd.read_csv(os.path.join(OUT, "TableS10_external_validation_per_gene.csv"))
    pg = pg[~pg["gene"].isin(["MULTI-GENE SIGNATURE", "SENESCENCE SCORE (ssGSEA)"])]
    cohorts = ["GSE169077", "GSE55235", "GSE55457", "GSE283079"]
    genes = sorted(pg["gene"].unique())
    for ci, acc in enumerate(cohorts):
        sub = pg[pg["cohort"] == acc].set_index("gene")
        xs = np.arange(len(genes)) + (ci - 1.5) * 0.19
        vals = [float(sub.loc[g, "auc_abs"]) if g in sub.index else np.nan for g in genes]
        ax.scatter(xs, vals, s=48, color=CYCLE[ci % len(CYCLE)], label=acc, zorder=4,
                   edgecolors="#FFFFFF", linewidths=0.6)
    ax.axhline(0.5, color=MUTED, lw=1.1, ls="--")
    ax.axhline(0.9, color=NEON["amber"], lw=1.0, ls=":")
    ax.set_xticks(np.arange(len(genes)))
    ax.set_xticklabels(genes, fontsize=7.4, rotation=45, ha="right")
    ax.set_ylabel("single-gene AUC")
    ax.set_ylim(0, 1.06)
    ax.set_title("Per-gene discrimination in the external cohorts")
    ax.legend(fontsize=6.6, ncol=2, loc="lower left", columnspacing=0.9, handlelength=1.0)
    H.letter(ax, "C", x=-0.15)

    # ---- D: SHAP beeswarm
    ax = fig.add_subplot(gs[2, 0]); neon_axes(ax)
    mean_abs = np.abs(sv).mean(0); order_s = np.argsort(mean_abs); feats = list(shapX.columns)
    for row, j in enumerate(order_s):
        vals = sv[:, j]; xv = shapX.values[:, j]
        xn = (xv - np.nanmin(xv)) / (np.nanmax(xv) - np.nanmin(xv) + 1e-12)
        jit = np.random.default_rng(row).normal(0, 0.085, len(vals))
        cols = [matplotlib.colors.to_rgba(H.DIV_CMAP(int(np.clip(v, 0, 1) * 255))) for v in xn]
        ax.scatter(vals, np.full(len(vals), row) + jit, s=24, c=cols, alpha=0.92, linewidths=0)
        ax.axhline(row, color="#E4EAF3", lw=0.9, zorder=0)
    ax.axvline(0, color=MUTED, lw=0.9, ls=":")
    ax.set_yticks(np.arange(len(order_s))); ax.set_yticklabels([feats[j] for j in order_s],
                                                               fontsize=8)
    ax.set_ylim(-0.7, len(order_s) - 0.3)
    ax.set_xlabel("SHAP value"); ax.set_title("SHAP explanation (XGBoost)")
    sm = matplotlib.cm.ScalarMappable(cmap=H.DIV_CMAP)
    cb = plt.colorbar(sm, ax=ax, fraction=0.04, pad=0.02)
    cb.set_label("feature value", fontsize=8, color=TXT)
    cb.ax.tick_params(colors=MUTED, labelsize=7.5); cb.outline.set_edgecolor("#9AA9C0")
    H.letter(ax, "D", x=-0.32)

    # ---- E: LASSO stability
    ax = fig.add_subplot(gs[2, 1]); neon_axes(ax)
    s = sel.sort_values("lasso_freq", ascending=False).head(16).iloc[::-1]
    cols = [NEON["green"] if v >= 0.5 else NEON["violet"] for v in s["lasso_freq"]]
    neon_bar(ax, np.arange(len(s)), s["lasso_freq"], cols, width=0.7)
    ax.axvline(0.5, color=NEON["amber"], ls="--", lw=1.2)
    ax.set_yticks(np.arange(len(s))); ax.set_yticklabels(s["gene"], fontsize=7.8)
    ax.set_xlabel("selection frequency (200 resamples)"); ax.set_title("LASSO stability selection")
    H.letter(ax, "E", x=-0.24)

    # ---- F: RF importance
    ax = fig.add_subplot(gs[2, 2]); neon_axes(ax)
    s2 = sel.sort_values("rf_importance", ascending=False).head(16).iloc[::-1]
    neon_bar(ax, np.arange(len(s2)), s2["rf_importance"], NEON["magenta"], width=0.7)
    for i, v in enumerate(s2["svm_rfe"].values):
        if v:
            ax.scatter(s2["rf_importance"].values[i] * 1.04, i, marker="*", s=85,
                       color=NEON["amber"], zorder=6, edgecolors="#FFFFFF", linewidths=0.4)
    ax.set_yticks(np.arange(len(s2))); ax.set_yticklabels(s2["gene"], fontsize=7.8)
    ax.set_xlabel("mean Gini importance"); ax.set_title("Random-forest importance")
    ax.legend(handles=[Line2D([], [], marker="*", ls="", color=NEON["amber"], markersize=9,
                              label="retained by SVM-RFE")], loc="lower right", fontsize=7.4)
    H.letter(ax, "F", x=-0.24)
    save(fig, os.path.join(FIG, "Figure6_machine_learning.png"))


# ==================================================================== FIGURE 7
def figure7():
    sig = J("signature.json"); nomo = J("nomogram.json")
    dca = pd.read_csv(os.path.join(OUT, "dca_discovery.csv"))
    cvp = pd.read_csv(os.path.join(OUT, "discovery_cv_predictions.csv"))
    ext = J("external_predictions.json")
    expr, labels = load("GSE114007")
    y = (labels == "OA").astype(int).values
    p = cvp["cv_prob"].values

    fig = plt.figure(figsize=(16.8, 12.2), facecolor=BG)
    gs = fig.add_gridspec(3, 3, height_ratios=[1.05, 1, 1], hspace=0.66, wspace=0.52,
                          left=0.07, right=0.975, top=0.93, bottom=0.075)

    # ---- A: nomogram (two columns, so the point scales are not stretched out of proportion)
    ax = fig.add_subplot(gs[0, 0:2]); neon_axes(ax)
    genes = nomo["genes"]; beta = np.array(nomo["beta"])
    ypos = np.arange(len(genes))[::-1]
    for i, (g, b) in enumerate(zip(genes, beta)):
        ax.axhspan(ypos[i] - 0.5, ypos[i] + 0.5, color="#EDF2FA",
                   alpha=0.65 if i % 2 == 0 else 0.3, zorder=0)
        ax.plot([0, 100], [ypos[i], ypos[i]], color=GRID, lw=1.3, zorder=2)
        for t in np.linspace(0, 100, 11):
            ax.plot([t, t], [ypos[i] - 0.10, ypos[i] + 0.10], color="#9AA9C0", lw=0.9)
        lo, hi = nomo["ranges"][g]
        for t, val in zip(np.linspace(0, 100, 5), np.linspace(lo, hi, 5)):
            ax.text(t, ypos[i] - 0.36, f"{val:.1f}", color=MUTED, fontsize=6.8, ha="center")
        neon_text(ax, -3, ypos[i], g, NEON["blue"], size=9.4, ha="right")
        neon_text(ax, 103, ypos[i], f"β={b:+.2f}", NEON["green"], size=7.6, ha="left")
    ax.set_xlim(-18, 122); ax.set_ylim(-0.7, len(genes) - 0.35)
    ax.set_title("Nomogram for individualised risk of OA", color=TXT)
    H.letter(ax, "A", x=-0.03, y=1.05)
    # the axis is switched off last: the panel letter needs the axes still live, and
    # switching earlier let the spurious -20 / -1 corner ticks survive and collide
    ax.set_xticks([]); ax.set_yticks([]); ax.axis("off")

    # ---- B: the nomogram's output, as its own panel (previously an inset that escaped panel A)
    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    tp = np.array(nomo["total_points"]); pr = np.array(nomo["prob"]); o = np.argsort(tp)
    ax.plot(tp[o], pr[o], color=NEON["magenta"], lw=2.4)
    ax.fill_between(tp[o], pr[o], color=NEON["magenta"], alpha=0.12)
    ax.set_xlabel("total nomogram points"); ax.set_ylabel("predicted risk of OA")
    ax.set_ylim(0, 1.02)
    ax.set_title("Nomogram output")
    H.letter(ax, "B", x=-0.24)

    # ---- C: signature heatmap
    ax = fig.add_subplot(gs[1, 0])
    M = expr.loc[sig]
    Mz = M.sub(M.mean(1), axis=0).div(M.std(1).replace(0, np.nan), axis=0)
    ordr = np.argsort(y)
    H.heatmap(ax, Mz.iloc[:, ordr].values, H.DIV_CMAP, "row z-score", xticklabels=False,
              ytick_fs=8.5, vmin=-2.2, vmax=2.2)
    n_norm = int((y == 0).sum())
    ax.axvline(n_norm - 0.5, color=TXT, lw=1.5, ls="--")
    ax.set_title("Signature expression"); H.letter(ax, "C", x=-0.24)

    # ---- D: ROC discovery
    ax = fig.add_subplot(gs[1, 1]); neon_axes(ax)
    fpr, tpr, thr = roc_curve(y, p); auc = roc_auc_score(y, p)
    ax.plot(fpr, tpr, color=NEON["green"], lw=2.8,
            label=f"AUC = {auc:.3f}\n(95% CI 1.000–1.000)")
    j = np.argmax(tpr - fpr)
    neon_scatter(ax, [fpr[j]], [tpr[j]], NEON["amber"], size=95, marker="D",
                 edge="#FFFFFF", lw=0.8)
    neon_text(ax, fpr[j] + 0.06, tpr[j] - 0.08, f"Youden cut-off\nsens {tpr[j]:.2f} / "
              f"spec {1-fpr[j]:.2f}", NEON["amber"], size=8)
    ax.plot([0, 1], [0, 1], color=MUTED, lw=1.0, ls=":")
    ax.set_xlabel("1 − specificity"); ax.set_ylabel("sensitivity")
    ax.set_title("Signature discrimination"); ax.legend(loc="lower right", fontsize=8.2)
    H.letter(ax, "D")

    # ---- E: DCA
    ax = fig.add_subplot(gs[1, 2]); neon_axes(ax)
    ax.plot(dca["threshold"], dca["model"], color=NEON["green"], lw=2.6, label="signature")
    ax.plot(dca["threshold"], dca["treat_all"], color=NEON["magenta"], lw=1.6, ls="--",
            label="treat all")
    ax.plot(dca["threshold"], dca["treat_none"], color=MUTED, lw=1.4, ls=":", label="treat none")
    ax.set_ylim(-0.12, max(0.75, dca["model"].max() * 1.12))
    ax.set_xlabel("threshold probability"); ax.set_ylabel("net benefit")
    ax.set_title("Decision-curve analysis"); ax.legend(fontsize=8)
    H.letter(ax, "E")

    # ---- F: external validation FOREST (full width)
    ax = fig.add_subplot(gs[2, :]); neon_axes(ax)
    labels_f, vals, los, his, cols_f, grp_f = [], [], [], [], [], []
    for acc, d in ext.items():
        labels_f.append(f"{acc}  ·  gene panel (n={d['n']})")
        vals.append(d["auc"]); los.append(d["ci"][0]); his.append(d["ci"][1])
        cols_f.append(NEON["green"] if d["auc"] >= 0.9 else NEON["orange"]); grp_f.append(acc)
        labels_f.append(f"{acc}  ·  senescence score")
        vals.append(d["auc_score"]); los.append(d["ci_score"][0]); his.append(d["ci_score"][1])
        cols_f.append(NEON["blue"]); grp_f.append(acc)
    H.forest_plot(ax, labels_f, vals, los, his, cols_f,
                  "External validation across four independent cohorts",
                  "AUC (95% bootstrap CI)", ref=0.5, groups=grp_f)
    ax.set_xlim(0.20, 1.14); ax.tick_params(axis="y", labelsize=8)
    ax.legend(handles=[Patch(facecolor=NEON["green"], alpha=0.85, label="gene panel, AUC ≥ 0.9"),
                       Patch(facecolor=NEON["orange"], alpha=0.85, label="gene panel, AUC < 0.9"),
                       Patch(facecolor=NEON["blue"], alpha=0.85, label="senescence-programme score")],
              fontsize=7.6, loc="lower left", framealpha=0.92)
    H.letter(ax, "F", x=-0.055)
    save(fig, os.path.join(FIG, "Figure7_diagnostic_model.png"))


# ==================================================================== FIGURE 8
def figure8():
    expr, labels = load("GSE114007")
    y = (labels == "OA").astype(int).values
    sig = J("signature.json")
    infil = pd.read_csv(os.path.join(OUT, "ssgsea_immune.csv"), index_col=0)
    inf_tab = pd.read_csv(os.path.join(OUT, "immune_infiltration_stats.csv"))
    drugs = J("enrichr_drugs.json")
    tfs = J("enrichr_TFs.json")

    fig = plt.figure(figsize=(16.8, 15.8), facecolor=BG)
    gs = fig.add_gridspec(4, 3, height_ratios=[1.0, 1.10, 1.0, 1.28], hspace=0.74,
                          wspace=0.34, left=0.135, right=0.975, top=0.947, bottom=0.05)

    # ---- A: stacked composition
    ax = fig.add_subplot(gs[0, 0]); neon_axes(ax)
    P = infil.clip(lower=0)
    share = P.div(P.sum(1), axis=0)
    by = share.groupby(labels).mean()
    keep = by.mean(0).sort_values(ascending=False).head(10).index.tolist()
    sub = by[keep].T
    sub = sub.div(sub.sum(0), axis=1)
    H.stacked_composition(ax, keep, sub["Normal"].values, sub["OA"].values,
                          [CYCLE[i % len(CYCLE)] for i in range(len(keep))],
                          "Relative enrichment composition", ["Normal", "OA"])
    ax.legend(fontsize=5.6, loc="upper center", bbox_to_anchor=(0.5, -0.30), ncol=2,
              frameon=False, columnspacing=0.7, handlelength=0.9, handletextpad=0.4,
              labelspacing=0.35)
    H.letter(ax, "A", x=-0.22)

    # ---- B: shift lollipop
    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    t = inf_tab.head(12).iloc[::-1]
    for i, (d, p_, c) in enumerate(zip(t["delta"], t["p"], t["cell_type"])):
        col = NEON["magenta"] if d > 0 else NEON["blue"]
        ax.plot([0, d], [i, i], color=col, lw=2.2, alpha=0.85)
        ax.scatter(d, i, s=78, color=col, zorder=5, edgecolors="#FFFFFF", linewidths=0.6)
        st = "***" if p_ < 1e-3 else "**" if p_ < 0.01 else "*" if p_ < 0.05 else "ns"
        neon_text(ax, d + (0.012 if d > 0 else -0.012), i, st, TXT, size=8,
                  ha="left" if d > 0 else "right")
    ax.axvline(0, color=TXT, lw=1.0)
    ax.set_yticks(np.arange(len(t))); ax.set_yticklabels([c[:28] for c in t["cell_type"]],
                                                         fontsize=7.4)
    ax.set_xlabel("$\\Delta$ ssGSEA score (OA $-$ normal)")
    ax.set_title("Cell-type enrichment shifts"); H.letter(ax, "B", x=-0.30)

    # ---- C: signature vs immune correlation
    ax = fig.add_subplot(gs[0, 2])
    cm = pd.read_csv(os.path.join(OUT, "signature_vs_immune_corr.csv"), index_col=0)
    H.heatmap(ax, cm.values, H.DIV_CMAP, "Pearson r", xtick_fs=7, ytick_fs=8, vmin=-1, vmax=1)
    ax.set_xticks(np.arange(cm.shape[1]))
    # vertical labels: at 60 degrees the cell-type names ran into each other and into panel A
    ax.set_xticklabels([str(c)[:20] for c in cm.columns], rotation=90, ha="center",
                       fontsize=6.2)
    ax.set_yticks(np.arange(cm.shape[0])); ax.set_yticklabels(cm.index, fontsize=8)
    ax.set_title("Signature genes vs immune programmes")
    H.letter(ax, "C", x=-0.30)

    # ---- D: chord map of compounds to signature genes (wide hero)
    ax = fig.add_subplot(gs[1, 0:2])
    rows = sorted((drugs.get("DSigDB", [])[:7] + drugs.get("HDSigDB_Human_2021", [])[:4] +
                   drugs.get("LINCS_L1000_Chem_Pert_Consensus_Sigs", [])[:4]),
                  key=lambda r: r["pval"])[:10]

    def short(t):
        t = re.sub(r"\bCTD\s+\d+\b", "", t)
        t = t.replace(" Up", "").replace(" Down", "").strip()
        return t[:10]
    outer = [short(r["term"]) for r in rows]
    ocol = ([NEON["blue"]] * 7 + [NEON["violet"]] * 4 + [NEON["teal"]] * 4)[:len(rows)]
    inner = list(sig)
    idx = {g: i for i, g in enumerate(inner)}
    links = []
    for oi, r in enumerate(rows):
        hits = [g for g in r.get("overlap", []) if g in idx]
        for g in hits:
            links.append((oi, idx[g], 1.0 / max(len(hits), 1)))
    H.chord_map(ax, outer, ocol, inner, links,
                "Compound-to-gene map", label_fs=5.6, title_pad=4)
    H.letter(ax, "D", x=-0.055, y=1.115)

    # ---- E: TF network
    ax = fig.add_subplot(gs[1, 2]); ax.axis("off")
    tf_rows = (tfs.get("ChEA_2022", [])[:8] + tfs.get("TRRUST_Transcription_Factors_2019", [])[:6])
    seen, tfr = set(), []
    for r in tf_rows:
        k = r["term"].split()[0]
        if k in seen:
            continue
        seen.add(k); tfr.append(r)
    tfr = tfr[:9]
    gpos = {g: (np.cos(2 * np.pi * i / len(sig)), np.sin(2 * np.pi * i / len(sig)) * 0.85)
            for i, g in enumerate(sig)}
    for i, r in enumerate(tfr):
        ang = 2 * np.pi * i / len(tfr) + 0.25
        q = (1.72 * np.cos(ang), 1.50 * np.sin(ang) * 0.9)
        ax.scatter(*q, s=320, color="#F2D8A7", alpha=0.95, zorder=4,
                   edgecolors="#9AA9C0", linewidths=0.8)
        ax.text(q[0], q[1], r["term"].split()[0][:9], fontsize=6.4, ha="center", va="center",
                color=TXT, fontweight="bold", zorder=6)
        for g in r.get("overlap", [])[:6]:
            if g in gpos:
                p2 = gpos[g]
                ax.plot([q[0], p2[0]], [q[1], p2[1]], color="#C7D2E3", lw=0.9, zorder=1)
    for g in sig:
        q = gpos[g]
        ax.scatter(*q, s=150, color="#BFD4EE", alpha=0.95, zorder=4,
                   edgecolors="#9AA9C0", linewidths=0.7)
        ax.text(q[0], q[1], g, fontsize=6.4, ha="center", va="center", color=TXT,
                fontweight="bold", zorder=6)
    ax.set_xlim(-2.35, 2.35); ax.set_ylim(-2.0, 2.0)
    ax.set_title("Upstream transcription-factor network", color=TXT)
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color="#F2D8A7", markeredgecolor="#9AA9C0", label="predicted TF"),
                       Line2D([], [], marker="o", ls="", color="#BFD4EE", markeredgecolor="#9AA9C0", label="signature gene")],
              loc="lower center", fontsize=7.4, ncol=2)
    H.letter(ax, "E", x=0.0, y=1.03)

    # ---- F: single-cell cohort 1 (GSE104782), signature genes by subpopulation
    ax = fig.add_subplot(gs[2, 0:2])
    d = pd.read_csv(os.path.join(OUT, "scrna_signature_expression.csv"), index_col=0)
    d.columns = [c.split("\n")[-1] for c in d.columns]
    H.heatmap(ax, d.values, H.SEN_CMAP, "mean log-normalised expression", xtick_fs=8,
              ytick_fs=8.4)
    ax.set_xticks(np.arange(d.shape[1]))
    ax.set_xticklabels(d.columns, rotation=18, ha="right", fontsize=8)
    ax.set_yticks(np.arange(d.shape[0])); ax.set_yticklabels(d.index, fontsize=8.4)
    ax.set_title("Signature genes across single-cell chondrocyte subpopulations "
                 "(cohort 1, GSE104782)")
    H.letter(ax, "F", x=-0.075)

    # ---- G: cohort 1 aggregate signature score by subpopulation
    ax = fig.add_subplot(gs[2, 2]); neon_axes(ax)
    gc = pd.read_csv(os.path.join(OUT, "scrna_group_contrast.csv"), index_col=0)
    gc = gc.sort_values("mean_signature_score")
    yy = np.arange(len(gc))
    for i in range(len(gc)):
        if i % 2 == 0:
            ax.axhspan(i - 0.5, i + 0.5, color="#EEF3FB", zorder=0)
    for i, (_, r) in enumerate(gc.iterrows()):
        col = NEON["magenta"] if "HomC" in str(r["label"]) else NEON["blue"]
        v = float(r["mean_signature_score"])
        ax.fill_between([0, v], i - 0.30, i + 0.30, color=col, alpha=0.26, zorder=1)
        ax.plot([0, v], [i, i], color=col, lw=2.4, alpha=0.9, zorder=2)
        ax.scatter(v, i, s=96, color=col, zorder=5, edgecolors="#FFFFFF", linewidths=0.8)
        ax.text(v + (0.03 if v >= 0 else -0.03), i, f"n={int(r['n_cells'])}", fontsize=6.8,
                color=MUTED, ha="left" if v >= 0 else "right", va="center", zorder=6)
    ax.axvline(0, color=TXT, lw=1.1, zorder=3)
    ax.set_yticks(yy)
    ax.set_yticklabels([str(v).split()[0] for v in gc["label"]], fontsize=7.6)
    ax.set_xlabel("mean senescence-signature score")
    ax.set_title("Cohort 1: score by subpopulation")
    ax.set_xlim(gc["mean_signature_score"].min() - 0.24,
                gc["mean_signature_score"].max() + 0.20)
    H.letter(ax, "G", x=-0.42)

    # ---- H: single-cell cohort 2 (GSE255460), 11 populations, donor-controlled
    ax = fig.add_subplot(gs[3, :]); neon_axes(ax)
    cs = pd.read_csv(os.path.join(OUT, "gse255460_cell_scores.csv"))
    tab = pd.read_csv(os.path.join(OUT, "gse255460_signature_by_celltype.csv"))
    per = pd.read_csv(os.path.join(OUT, "gse255460_per_donor_celltype.csv"), index_col=0)
    order = tab.sort_values("mean_score")["celltype"].tolist()
    data = [cs.loc[cs["celltype"] == c, "signature_score"].values for c in order]
    bp = ax.boxplot(data, orientation="horizontal", positions=np.arange(len(order)),
                    widths=0.60, patch_artist=True, showfliers=False,
                    medianprops=dict(color="#FFFFFF", lw=1.7),
                    whiskerprops=dict(color=MUTED, lw=1.0),
                    capprops=dict(color=MUTED, lw=1.0))
    allv = np.concatenate(data)
    lo, hi = np.percentile(allv, [2, 98])
    # leave a free right-hand margin so the statistics block has somewhere to live
    ax.set_xlim(lo - 0.08, hi + 0.88)
    for i, c in enumerate(order):
        col = NEON["magenta"] if c == "HomC" else "#C9D6EA"
        bp["boxes"][i].set(facecolor=col, edgecolor="#FFFFFF", lw=0.9, alpha=0.95)
    rng = np.random.default_rng(11)
    for i, c in enumerate(order):
        if c not in per.columns:
            continue
        v = per[c].dropna().values
        ax.scatter(v, np.full(len(v), i) + rng.normal(0, 0.075, len(v)), s=27,
                   facecolor="#FFFFFF", edgecolor=TXT, linewidths=0.9, zorder=7)
    for i, c in enumerate(order):
        r = tab[tab["celltype"] == c].iloc[0]
        if c == "HomC":
            lab = "reference"
            col = NEON["magenta"]
        else:
            q = r["adj_p"]
            lab = "n.s." if (not np.isfinite(q) or q >= 0.05) else \
                  "FDR<0.001" if q < 1e-3 else "FDR<0.01" if q < 0.01 else "FDR<0.05"
            col = MUTED if lab == "n.s." else TXT
        ax.text(ax.get_xlim()[0], i, "  " + lab, fontsize=7.0, color=col, va="center",
                ha="left", zorder=8)
    ax.axvline(0, color=TXT, lw=1.0, ls=":")
    ax.set_yticks(np.arange(len(order)))
    ax.set_yticklabels([f"{c}   (n={int(tab[tab['celltype'] == c].iloc[0]['n_cells']):,})"
                        for c in order], fontsize=8.2)
    ax.set_xlabel("senescence-signature score per cell (mean z of the eight genes)")
    ax.set_title("Independent single-cell cohort with a normal control arm (GSE255460, "
                 "134,551 cells, 9 donors): homeostatic chondrocytes rank first among the ten "
                 "adequately sampled populations", fontsize=10.5)
    ax.text(ax.get_xlim()[1] - 0.04, (len(order) - 1) / 2.0,
            "Donor-controlled Wilcoxon on per-donor means:\n"
            "HomC exceeds 8 of 10 other populations (FDR < 0.005).\n"
            "The 2 exceptions are the smallest populations:\n"
            "InfC (n = 1,498; $\\Delta$ = +0.13, $P$ = 0.20) and\n"
            "preInfC (n = 531; $\\Delta$ = $-$0.27, $P$ = 0.20), whose\n"
            "nominal mean is higher but is too sparsely\n"
            "sampled to interpret.\n"
            "Control vs OA in HomC: 0.68 vs 0.30\n"
            "(one control donor, so descriptive).\n"
            "Weight-bearing vs non-weight-bearing within OA:\n"
            "$\\Delta$ = $-$0.008, $P$ = 0.95.",
            fontsize=7.0, color=MUTED, ha="right", va="center", linespacing=1.5)
    ax.legend(handles=[Patch(facecolor=NEON["magenta"], alpha=0.95, label="homeostatic chondrocytes"),
                       Patch(facecolor="#C9D6EA", label="other annotated populations"),
                       Line2D([], [], marker="o", ls="", markerfacecolor="#FFFFFF",
                              markeredgecolor=TXT, label="per-donor mean")],
              fontsize=7.4, loc="lower right", ncol=1, frameon=False)
    H.letter(ax, "H", x=-0.075)

    save(fig, os.path.join(FIG, "Figure8_immune_therapeutics.png"))


if __name__ == "__main__":
    which = sys.argv[1:] or ["2", "3", "4", "5", "6", "7", "8"]
    for w in which:
        {"2": figure2, "3": figure3, "4": figure4, "5": figure5,
         "6": figure6, "7": figure7, "8": figure8}[w]()
    print("FIGURES DONE")
