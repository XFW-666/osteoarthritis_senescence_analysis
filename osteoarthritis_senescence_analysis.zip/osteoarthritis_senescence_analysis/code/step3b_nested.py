"""
step3b_nested.py — honest, fully nested estimate of signature discrimination:
feature selection (LASSO) is re-run inside every training fold, so the reported AUC
carries no selection bias.  Also reports the direction-consistency of the signature
genes across independent cohorts.
"""
import os, json, warnings
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); OUT = os.path.join(BASE, "results")


def boot_ci(y, p, n=2000, seed=1):
    rng = np.random.default_rng(seed); a = []
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if len(set(np.asarray(y)[i])) < 2:
            continue
        a.append(roc_auc_score(np.asarray(y)[i], np.asarray(p)[i]))
    return np.percentile(a, [2.5, 97.5])


def main():
    expr = pd.read_csv(os.path.join(WORK, "expr_GSE114007.csv"), index_col=0)
    labels = pd.read_csv(os.path.join(WORK, "labels_GSE114007.csv"), index_col=0).iloc[:, 0]
    y = (labels == "OA").astype(int).values
    srd_loose = pd.read_csv(os.path.join(OUT, "SRDEGs_FDRonly.csv"), index_col=0)
    hub = pd.read_csv(os.path.join(OUT, "ppi_hub_ranking.csv"))
    feats = [g for g in sorted(set(srd_loose.index) | set(hub.head(15)["gene"])) if g in expr.index]
    X = expr.loc[feats].T.values.astype(float)
    print("candidate pool:", len(feats))

    # ---- fully nested CV: LASSO selection inside each training fold
    n_splits, n_repeats = 5, 10
    acc = np.zeros(len(y)); chosen = {}
    for r in range(n_repeats):
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=100 + r)
        for tr, te in skf.split(X, y):
            Xs = StandardScaler().fit_transform(X[tr])
            las = LogisticRegression(penalty="l1", solver="liblinear", C=0.1, max_iter=5000).fit(Xs, y[tr])
            keep = np.abs(las.coef_[0]) > 1e-8
            if keep.sum() == 0:
                keep = np.zeros_like(keep, dtype=bool)
                keep[np.argsort(-np.abs(las.coef_[0]))[:5]] = True
            pipe = Pipeline([("s", StandardScaler()), ("m", LogisticRegression(max_iter=5000, C=1.0))])
            pipe.fit(X[np.ix_(tr, keep)], y[tr])
            acc[te] += pipe.predict_proba(X[np.ix_(te, keep)])[:, 1]
            for g in np.array(feats)[keep]:
                chosen[g] = chosen.get(g, 0) + 1
    p = acc / n_repeats
    auc = roc_auc_score(y, p); lo, hi = boot_ci(y, p)
    print(f"FULLY NESTED CV (selection inside folds, {n_splits}x{n_repeats}): AUC = {auc:.3f} [{lo:.3f}, {hi:.3f}]")
    top = sorted(chosen.items(), key=lambda kv: -kv[1])[:15]
    print("features most often retained inside folds:", top)
    json.dump({"auc": float(auc), "ci": [float(lo), float(hi)], "n_splits": n_splits,
               "n_repeats": n_repeats, "top_features": top},
              open(os.path.join(OUT, "nested_selection_cv.json"), "w"), indent=1)
    pd.DataFrame({"sample": expr.columns, "y": y, "cv_prob": p}).to_csv(
        os.path.join(OUT, "nested_cv_predictions.csv"), index=False)

    # ---- direction consistency of signature genes in independent cohorts
    sig = json.load(open(os.path.join(OUT, "signature.json")))
    rows = []
    for acc_name in ["GSE283079", "GSE55235", "GSE55457", "GSE169077"]:
        fp = os.path.join(WORK, f"expr_{acc_name}.csv")
        if not os.path.exists(fp):
            continue
        e2 = pd.read_csv(fp, index_col=0)
        l2 = pd.read_csv(os.path.join(WORK, f"labels_{acc_name}.csv"), index_col=0).iloc[:, 0]
        n_ok = 0; n_present = 0
        for g in sig:
            if g not in e2.index:
                continue
            n_present += 1
            d1 = expr.loc[g, labels == "OA"].mean() - expr.loc[g, labels == "Normal"].mean()
            d2 = e2.loc[g, l2 == "OA"].mean() - e2.loc[g, l2 == "Normal"].mean()
            if np.sign(d1) == np.sign(d2):
                n_ok += 1
        rows.append({"cohort": acc_name, "genes_present": n_present,
                     "direction_consistent": n_ok,
                     "pct_consistent": 100 * n_ok / max(n_present, 1)})
        print(f"{acc_name}: {n_ok}/{n_present} signature genes with consistent direction")
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "direction_consistency.csv"), index=False)
    print("STEP3B DONE")


if __name__ == "__main__":
    main()
