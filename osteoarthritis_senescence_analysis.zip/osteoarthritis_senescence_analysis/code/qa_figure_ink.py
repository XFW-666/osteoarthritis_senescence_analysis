"""Ink-density gate over every matplotlib figure, including Figure 9."""
import os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

import step5_figures as S
import step13_figures_causal as C9
from viz_style import _walk_axes

captured = {}
import viz_style
_orig = viz_style.save


def cap(fig, path, *a, **k):
    captured[path] = fig


viz_style.save = cap
S.save = cap
C9.save = cap

for fn in (S.figure2, S.figure3, S.figure4, S.figure5, S.figure6, S.figure7, S.figure8, C9.figure9):
    fn()

viz_style.save = _orig
S.save = _orig
C9.save = _orig

bad = []
print(f"{'figure':38s} {'panel':36s} {'ink%':>6s}  verdict")
for path, fig in captured.items():
    name = os.path.basename(path)
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    buf = np.asarray(fig.canvas.buffer_rgba())[:, :, :3].astype(int)
    H, W, _ = buf.shape
    rows = []
    for a, par in _walk_axes(fig):
        if not a.get_visible():
            continue
        bb = a.get_window_extent(renderer=r)
        x0 = max(0, int(bb.x0)); x1 = min(W, int(bb.x1))
        y0 = max(0, H - int(bb.y1)); y1 = min(H, H - int(bb.y0))
        if x1 - x0 < 20 or y1 - y0 < 20:
            continue
        sub = buf[y0:y1, x0:x1]
        ink = float((np.abs(sub - 255).sum(2) > 30).mean())
        lbl = (a.get_title() or a.get_ylabel() or "(untitled)")[:35]
        rows.append((ink, lbl, "inset" if par is not None else "panel"))
    for ink, lbl, kind in sorted(rows):
        verdict = "BLANK" if ink < 0.03 else "sparse" if ink < 0.08 else "ok"
        if verdict != "ok":
            bad.append((name, lbl, ink, verdict))
        print(f"{name:38s} {lbl:36s} {ink*100:5.1f}%  {kind:5s} {verdict}")

print(f"\npanels below 8% ink: {len(bad)}")
for b in bad:
    print("  ", b)
