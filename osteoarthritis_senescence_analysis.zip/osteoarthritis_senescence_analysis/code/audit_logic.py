"""
audit_logic.py — internal consistency of the manuscript:
  * which panel letters each figure actually draws (parsed from the figure scripts)
  * whether every "Figure 8H"-style reference in the prose points at a panel that exists
  * whether figures and tables are first cited in numeric order
  * whether every figure has an even number of panels (the stated design rule)
  * whether every reference is cited and every citation resolves
"""
import os, re, sys
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import manuscript_text as T1
import manuscript_text2 as T2

# ---- panels each figure actually draws, from the source that builds it
SRC = {"2": "step5_figures.py", "3": "step5_figures.py", "4": "step5_figures.py",
       "5": "step5_figures.py", "6": "step5_figures.py", "7": "step5_figures.py",
       "8": "step5_figures.py", "9": "step13_figures_causal.py",
       "10": "step23_figure10.py"}
FUNCS = {n: f"figure{n}" for n in SRC}

panels = {}
for n, fname in SRC.items():
    s = open(fname, encoding='utf-8').read()
    start = s.index(f"def {FUNCS[n]}(")
    nxt = [m.start() for m in re.finditer(r"\ndef figure\d+", s[start + 10:])]
    end = start + 10 + (nxt[0] if nxt else len(s) - start - 10)
    body = s if n == "10" else s[start:end]
    letters = re.findall(r'H\.letter\(ax,\s*"([A-Z])"', body)
    panels[n] = letters
print("panels drawn per figure:")
for n in sorted(panels, key=int):
    ev = "even" if len(panels[n]) % 2 == 0 else "ODD"
    print(f"  Figure {n:>2}: {len(panels[n])} panels {panels[n]}  [{ev}]")
panels["1"] = ["A", "B", "C", "D"]      # raster composite, four panels
print(f"  Figure  1: 4 panels A-D  [even]  (raster composite)")

# ---- full prose
texts = list(T1.ABSTRACT.values()) + list(T1.KEY_POINTS) + list(T1.INTRODUCTION)
for name, blk in T1.METHODS:
    texts += [name] + list(blk)
for name, blk in T2.RESULTS:
    texts += [name] + list(blk)
for name, blk in T2.DISCUSSION:
    texts += [name] + list(blk)
texts += list(T2.CONCLUSION) + [b for pair in T2.FIGURE_LEGENDS for b in pair]
BODY = "\n".join(t for t in texts if isinstance(t, str))

problems = []

# ---- figure panel references
print("\nfigure panel references in the prose:")
seen_order = []
for m in re.finditer(r"Figure\s+(\d+)([A-Z])?(?:-([A-Z]))?\b", BODY):
    num, a, b = m.group(1), m.group(2), m.group(3)
    if num not in seen_order:
        seen_order.append(num)
    avail = panels.get(num)
    if avail is None:
        problems.append(f"Figure {num} referenced but no such figure")
        continue
    if a:
        rng = [a]
        if b:
            rng = avail[avail.index(a):avail.index(b) + 1] if (a in avail and b in avail) else [a, b]
        for L in rng:
            if L not in avail:
                problems.append(f"'Figure {num}{L}' referenced but Figure {num} has panels {avail}")
print("  first-appearance order:", seen_order)
if seen_order != sorted(seen_order, key=int):
    problems.append(f"figures first cited out of order: {seen_order}")

# ---- table references
seen_t = []
for m in re.finditer(r"(?<!S)\bTable\s+(\d+)\b", BODY):
    k = int(m.group(1))
    if k not in seen_t:
        seen_t.append(k)
print("  table first-appearance order:", seen_t)
if seen_t != sorted(seen_t):
    problems.append(f"tables first cited out of order: {seen_t}")
for k in set(int(m.group(1)) for m in re.finditer(r"(?<!S)\bTable\s+(\d+)\b", BODY)):
    if k not in range(1, 7):
        problems.append(f"Table {k} referenced but only Tables 1-6 exist")

# ---- supplementary references resolve to real sheets
from openpyxl import load_workbook
sheets = set(load_workbook("Supplementary_Tables.xlsx", read_only=True).sheetnames)
sheet_nums = {re.match(r"Table(S\d+[a-z]?)", x).group(1) for x in sheets if re.match(r"Table(S\d+[a-z]?)", x)}
refs = set(re.findall(r"Table\s+(S\d+[a-z]?)\b", BODY))
print(f"\nsupplementary tables referenced: {sorted(refs)}")
for srt in sorted(refs):
    if srt not in sheet_nums:
        problems.append(f"Table {srt} cited in the text but no such sheet (have {sorted(sheet_nums)})")
unused = sorted(sheet_nums - refs)
if unused:
    print(f"  sheets never cited in prose: {unused}")

# ---- citations
import json
refs_list = json.load(open("results/references.json"))
n_ref = len(refs_list)
cited = set()
for m in re.finditer(r"\[([0-9,\-\s]+)\]", BODY):
    for part in m.group(1).split(","):
        part = part.strip()
        if "-" in part:
            x, y = part.split("-")
            cited.update(range(int(x), int(y) + 1))
        elif part.isdigit():
            cited.add(int(part))
bad = [c for c in cited if c < 1 or c > n_ref]
print(f"\nreferences: {n_ref} in list, {len(cited)} distinct cited, out-of-range: {bad}")
if bad:
    problems.append(f"citations out of range: {bad}")
uncited = [i for i in range(1, n_ref + 1) if i not in cited]
if uncited:
    problems.append(f"references never cited: {uncited}")

# ---- numeric claims that must be self-consistent
checks = [
    ("signature size stated as eight", "eight-gene signature" in BODY and len(T1.KEYWORDS) > 0),
    ("figures stated = 10", len(panels) == 10),
]
for label, ok in checks:
    print(f"  {'ok ' if ok else 'FAIL'} {label}")
    if not ok:
        problems.append(label)

print("\n" + "=" * 90)
print(f"LOGIC PROBLEMS: {len(problems)}")
for p in problems:
    print("  *", p)
