"""Report the effective scale at which each figure is placed in the PDF, and the resulting
on-page text size.  Figure scripts draw their labels at a known point size on a known canvas;
what matters for the reader is the point size after the image is scaled to its printed width."""
import fitz, os
from PIL import Image

# canvas width (inches) and the label point sizes used inside each figure script
CANVAS = {
    "Figure1": 7.2, "Figure2": 16.6, "Figure3": 16.8, "Figure4": 15.8, "Figure5": 16.6,
    "Figure6": 16.8, "Figure7": 16.8, "Figure8": 16.8, "Figure9": 17.0, "Figure10": 16.8,
}
LABEL_PT = 8.0   # typical smallest label size used in the figure scripts

d = fitz.open("Osteoarthritis_senescence_manuscript.pdf")
print(f"{'page':>5} {'figure':10} {'placed (pt)':>16} {'px':>12} {'scale':>7} "
      f"{'8pt label -> on page':>22}")
seen = set()
for pno, page in enumerate(d, 1):
    for blk in page.get_text("blocks"):
        if blk[6] != 1:
            continue
        r = fitz.Rect(blk[:4])
        w_pt = r.width
        # match the image to its source file by aspect ratio
        best = None
        for f in sorted(os.listdir("figures")):
            if not f.lower().endswith(".png"):
                continue
            im = Image.open(os.path.join("figures", f))
            ar = im.height / im.width
            if abs(ar - r.height / r.width) < 0.02:
                best = (f, im.width, im.height)
                break
        if not best:
            continue
        f, px_w, px_h = best
        key = f
        if key in seen:
            continue
        seen.add(key)
        canvas_in = CANVAS.get(f.split("_")[0], 16.8)
        scale = (w_pt / 72.0) / canvas_in
        print(f"{pno:>5} {f.split('_')[0]:10} {w_pt:>7.1f} x {r.height:<6.1f} {px_w:>12,} "
              f"{scale:>7.3f} {LABEL_PT*scale:>20.2f} pt")
