"""
step3_ml.py — feature selection (LASSO / SVM-RFE / random forest), nested cross-validated
model benchmarking, SHAP interpretation, nomogram + calibration + decision-curve analysis,
and external validation across independent GEO cohorts (gene panel and senescence score).
"""
import os, json, warnings
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import StratifiedKFold, RepeatedStratifiedKFold, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (roc_auc_score, roc_curve, accuracy_score, confusion_matrix,
                             f1_score, matthews_corrcoef, brier_score_loss, average_precision_score)
from sklearn.calibration import calibration_curve
import xgboost as xgb
import lightgbm as lgb

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); OUT = os.path.join(BASE, "results")
os.makedirs(OUT, exist_ok=True)


def load_cohort(acc):
    e = pd.read_csv(os.path.join(WORK, f"expr_{acc}.csv"), index_col=0)
    l = pd.read_csv(os.path.join(WORK, f"labels_{acc}.csv"), index_col=0).iloc[:, 0]
    return e, l


def y_of(l):
    return (l == "OA").astype(int).values


def boot_ci(y, p, n=2000, seed=1):
    rng = np.random.default_rng(seed)
    aucs = []
    for _ in range(n):
        idx = rng.integers(0, len(y), len(y))
        if len(set(np.asarray(y)[idx])) < 2:
            continue
        aucs.append(roc_auc_score(np.asarray(y)[idx], np.asarray(p)[idx]))
    if not aucs:
        return np.array([np.nan, np.nan])
    return np.percentile(aucs, [2.5, 97.5])


def ssgsea_score(expr, gene_set, alpha=0.25):
    """ssGSEA enrichment score of one gene set, per sample (Barbie et al. 2009)."""
    genes = np.array(expr.index)
    gs = [g for g in set(gene_set) if g in expr.index]
    X = expr.values.astype(float)
    N = X.shape[0]
    order = np.argsort(-X, axis=0)
    ranks = np.empty_like(order)
    for j in range(X.shape[1]):
        ranks[order[:, j], j] = np.arange(1, N + 1)
    idx = np.where(np.isin(genes, gs))[0]
    mask = np.zeros(N, dtype=bool); mask[idx] = True
    w = np.abs(ranks) ** alpha
    wg = w * mask[:, None]
    wng = w * (~mask)[:, None]
    Pg = np.cumsum(wg, axis=0) / np.maximum(wg.sum(0), 1e-12)
    Png = np.cumsum(wng, axis=0) / np.maximum(wng.sum(0), 1e-12)
    return pd.Series((Pg - Png).sum(0), index=expr.columns)


# ------------------------------------------------------------------ feature selection
def lasso_select(X, y, n_rep=200, seed=0):
    freq = np.zeros(X.shape[1])
    for i in range(n_rep):
        rng = np.random.default_rng(seed + i)
        idx = rng.choice(len(y), len(y), replace=True)
        if len(set(y[idx])) < 2:
            continue
        Xs = StandardScaler().fit_transform(X[idx])
        m = LogisticRegression(penalty="l1", solver="liblinear", C=0.1, max_iter=5000)
        m.fit(Xs, y[idx])
        freq += (np.abs(m.coef_[0]) > 1e-6)
    return freq / n_rep


def svm_rfe_select(X, y, n_features_to_select=10, seed=0):
    from sklearn.feature_selection import RFE
    Xs = StandardScaler().fit_transform(X)
    est = LinearSVC(C=0.5, dual="auto", max_iter=20000, random_state=seed)
    rfe = RFE(est, n_features_to_select=min(n_features_to_select, X.shape[1]), step=1)
    rfe.fit(Xs, y)
    return rfe.support_.astype(float), rfe.ranking_


def rf_select(X, y, n_rep=200, seed=0, top_k=15):
    imp = np.zeros(X.shape[1])
    for i in range(n_rep):
        rng = np.random.default_rng(seed + i)
        idx = rng.choice(len(y), len(y), replace=True)
        if len(set(y[idx])) < 2:
            continue
        m = RandomForestClassifier(n_estimators=300, random_state=seed + i, n_jobs=-1)
        m.fit(X[idx], y[idx])
        imp += m.feature_importances_
    imp = imp / n_rep
    order = np.argsort(-imp)
    sel = np.zeros(X.shape[1]); sel[order[:top_k]] = 1
    return imp, sel


# ------------------------------------------------------------------ models
def model_zoo():
    return {
        "Logistic (L2)": (Pipeline([("s", StandardScaler()), ("m", LogisticRegression(max_iter=5000))]),
                          {"m__C": [0.01, 0.1, 1, 10]}),
        "LASSO logistic": (Pipeline([("s", StandardScaler()), ("m", LogisticRegression(penalty="l1", solver="liblinear", max_iter=5000))]),
                           {"m__C": [0.01, 0.05, 0.1, 0.5, 1]}),
        "Ridge logistic": (Pipeline([("s", StandardScaler()), ("m", LogisticRegression(penalty="l2", solver="liblinear", max_iter=5000))]),
                           {"m__C": [0.01, 0.1, 1, 10]}),
        "Elastic-net logistic": (Pipeline([("s", StandardScaler()), ("m", LogisticRegression(penalty="elasticnet", solver="saga", l1_ratio=0.5, max_iter=8000))]),
                                 {"m__C": [0.05, 0.1, 0.5, 1]}),
        "SVM (linear)": (Pipeline([("s", StandardScaler()), ("m", SVC(kernel="linear", probability=True))]),
                         {"m__C": [0.1, 1, 10]}),
        "SVM (RBF)": (Pipeline([("s", StandardScaler()), ("m", SVC(kernel="rbf", probability=True))]),
                      {"m__C": [0.5, 1, 5, 10], "m__gamma": ["scale", 0.05]}),
        "Random forest": (RandomForestClassifier(random_state=0, n_jobs=-1),
                          {"n_estimators": [300], "max_depth": [None, 3, 5], "min_samples_leaf": [1, 2]}),
        "Extra trees": (ExtraTreesClassifier(random_state=0, n_jobs=-1),
                        {"n_estimators": [300], "max_depth": [None, 3, 5], "min_samples_leaf": [1, 2]}),
        "Gradient boosting": (GradientBoostingClassifier(random_state=0),
                              {"n_estimators": [100, 300], "learning_rate": [0.05, 0.1], "max_depth": [2, 3]}),
        "XGBoost": (xgb.XGBClassifier(random_state=0, n_jobs=-1, eval_metric="logloss", verbosity=0),
                    {"n_estimators": [150, 300], "max_depth": [2, 3], "learning_rate": [0.05, 0.1]}),
        "LightGBM": (lgb.LGBMClassifier(random_state=0, n_jobs=-1, verbose=-1),
                     {"n_estimators": [150, 300], "num_leaves": [4, 8], "learning_rate": [0.05, 0.1]}),
        "K-nearest neighbours": (Pipeline([("s", StandardScaler()), ("m", KNeighborsClassifier())]),
                                 {"m__n_neighbors": [3, 5, 7, 9], "m__weights": ["uniform", "distance"]}),
        "Gaussian naive Bayes": (Pipeline([("s", StandardScaler()), ("m", GaussianNB())]), {"m__var_smoothing": [1e-9, 1e-6]}),
        "Neural network (MLP)": (Pipeline([("s", StandardScaler()), ("m", MLPClassifier(max_iter=3000, random_state=0))]),
                                 {"m__hidden_layer_sizes": [(8,), (16,)], "m__alpha": [1e-4, 1e-2]}),
    }


def nested_cv_benchmark(X, y, n_splits=5, n_repeats=5, seed=0):
    """Nested CV with per-sample out-of-fold probability accumulation (mean over repeats)."""
    rows, oof = [], {}
    for name, (est, grid) in model_zoo().items():
        acc = np.zeros(len(y))
        for r in range(n_repeats):
            skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed + r)
            for tr, te in skf.split(X, y):
                gs = GridSearchCV(est, grid, cv=StratifiedKFold(5, shuffle=True, random_state=seed),
                                  scoring="roc_auc", n_jobs=-1)
                gs.fit(X[tr], y[tr])
                acc[te] += gs.predict_proba(X[te])[:, 1]
        p = acc / n_repeats
        oof[name] = p.tolist()
        fpr, tpr, thr = roc_curve(y, p)
        j = np.argmax(tpr - fpr)
        cut = thr[j]
        pred = (p >= cut).astype(int)
        tn, fp, fn, tp = confusion_matrix(y, pred).ravel()
        lo, hi = boot_ci(y, p)
        rows.append({
            "model": name, "AUC": roc_auc_score(y, p), "AUC_ci_lo": lo, "AUC_ci_hi": hi,
            "PR_AUC": average_precision_score(y, p), "accuracy": accuracy_score(y, pred),
            "sensitivity": tp / (tp + fn) if (tp + fn) else np.nan,
            "specificity": tn / (tn + fp) if (tn + fp) else np.nan,
            "PPV": tp / (tp + fp) if (tp + fp) else np.nan,
            "NPV": tn / (tn + fn) if (tn + fn) else np.nan,
            "F1": f1_score(y, pred), "MCC": matthews_corrcoef(y, pred),
            "Brier": brier_score_loss(y, p), "threshold": float(cut),
        })
    return pd.DataFrame(rows).sort_values("AUC", ascending=False), oof


def cv_curve(X, y, est, grid, n_splits=5, n_repeats=10, seed=0):
    acc = np.zeros(len(y))
    for r in range(n_repeats):
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed + r)
        for tr, te in skf.split(X, y):
            gs = GridSearchCV(est, grid, cv=StratifiedKFold(5, shuffle=True, random_state=seed),
                              scoring="roc_auc", n_jobs=-1)
            gs.fit(X[tr], y[tr])
            acc[te] += gs.predict_proba(X[te])[:, 1]
    return acc / n_repeats


def dca(y, p, thresholds=None):
    if thresholds is None:
        thresholds = np.arange(0.01, 0.99, 0.01)
    n = len(y); prev = y.mean(); out = []
    for t in thresholds:
        pred = (p >= t).astype(int)
        tp = ((pred == 1) & (y == 1)).sum(); fp = ((pred == 1) & (y == 0)).sum()
        out.append({"threshold": t, "model": tp / n - fp / n * (t / (1 - t)),
                    "treat_all": prev - (1 - prev) * (t / (1 - t)), "treat_none": 0.0})
    return pd.DataFrame(out)


def hosmer_lemeshow(y, p, g=5):
    df = pd.DataFrame({"y": y, "p": p}).sort_values("p")
    df["bin"] = pd.qcut(df["p"], g, duplicates="drop")
    obs = df.groupby("bin", observed=True)["y"].sum()
    exp = df.groupby("bin", observed=True)["p"].sum()
    n = df.groupby("bin", observed=True)["y"].count()
    hl = (((obs - exp) ** 2) / (exp * (1 - exp / n))).sum()
    dof = max(len(n) - 2, 1)
    return float(hl), float(stats.chi2.sf(hl, dof)), int(dof)


def nomogram_points(beta, X):
    contrib = X * beta
    rng = contrib.max(0) - contrib.min(0)
    rng[rng == 0] = 1
    return (contrib - contrib.min(0)) / rng * 100.0


if __name__ == "__main__":
    expr, labels = load_cohort("GSE114007")
    y = y_of(labels)
    srd_loose = pd.read_csv(os.path.join(OUT, "SRDEGs_FDRonly.csv"), index_col=0)
    hub = pd.read_csv(os.path.join(OUT, "ppi_hub_ranking.csv"))
    top_hub = hub.head(15)["gene"].tolist()
    feats = [g for g in sorted(set(srd_loose.index) | set(top_hub)) if g in expr.index]
    print("candidate pool:", len(feats), "| PPI hub top15:", top_hub)

    X = expr.loc[feats].T.values.astype(float)
    names = np.array(feats)

    freq = lasso_select(X, y, n_rep=200)
    svm_sel, svm_rank = svm_rfe_select(X, y, n_features_to_select=min(12, X.shape[1]))
    rf_imp, rf_sel = rf_select(X, y, n_rep=200, top_k=12)

    sel = pd.DataFrame({"gene": names, "lasso_freq": freq, "svm_rfe": svm_sel.astype(int),
                        "rf_importance": rf_imp, "rf_selected": rf_sel.astype(int)})
    sel["votes"] = (sel["lasso_freq"] >= 0.5).astype(int) + sel["svm_rfe"] + sel["rf_selected"]
    sel["score"] = sel["votes"] + sel["lasso_freq"] + sel["rf_importance"] / max(sel["rf_importance"].max(), 1e-9)
    sel = sel.sort_values(["score", "lasso_freq"], ascending=False)
    sel.to_csv(os.path.join(OUT, "feature_selection.csv"), index=False)
    print(sel.head(20).to_string(index=False))

    # signature: consensus of >=2 of the 3 algorithms, capped at 8 genes
    cons = sel[sel["votes"] >= 2]
    signature = cons.head(8)["gene"].tolist()
    if len(signature) < 5:
        signature = sel.head(6)["gene"].tolist()
    print("\nFINAL SIGNATURE:", signature)
    json.dump(signature, open(os.path.join(OUT, "signature.json"), "w"), indent=1)

    Xs = expr.loc[signature].T.values.astype(float)

    bench, oof = nested_cv_benchmark(Xs, y, n_splits=5, n_repeats=5)
    bench.to_csv(os.path.join(OUT, "model_benchmark.csv"), index=False)
    json.dump(oof, open(os.path.join(OUT, "oof_predictions.json"), "w"))
    print("\nMODEL BENCHMARK (nested 5x5 CV):")
    print(bench[["model", "AUC", "AUC_ci_lo", "AUC_ci_hi", "sensitivity", "specificity", "F1", "MCC", "Brier"]].round(3).to_string(index=False))

    # frozen interpretable model
    lr = Pipeline([("s", StandardScaler()), ("m", LogisticRegression(max_iter=5000, C=1.0))])
    lr_cv = cv_curve(Xs, y, Pipeline([("s", StandardScaler()), ("m", LogisticRegression(max_iter=5000))]),
                     {"m__C": [0.01, 0.1, 1, 10]}, n_splits=5, n_repeats=10)
    lr.fit(Xs, y)
    beta = lr.named_steps["m"].coef_[0]
    scaler = lr.named_steps["s"]
    coefs = pd.DataFrame({"gene": signature, "coef": beta,
                          "logFC": [float(pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0).loc[g, "logFC"]) for g in signature]}
                         ).sort_values("coef", key=np.abs, ascending=False)
    coefs.to_csv(os.path.join(OUT, "signature_coefficients.csv"), index=False)
    print("\nSIGNATURE COEFFICIENTS:\n", coefs.round(3).to_string(index=False))

    pd.DataFrame({"sample": expr.columns, "y": y, "cv_prob": lr_cv}).to_csv(
        os.path.join(OUT, "discovery_cv_predictions.csv"), index=False)
    dca(y, lr_cv).to_csv(os.path.join(OUT, "dca_discovery.csv"), index=False)
    auc_cv = roc_auc_score(y, lr_cv); lo, hi = boot_ci(y, lr_cv)
    print(f"\nFrozen logistic model, 5x10 CV: AUC = {auc_cv:.3f} [{lo:.3f}, {hi:.3f}]")
    hl = hosmer_lemeshow(y, lr_cv)
    print("Hosmer-Lemeshow chi2=%.3f p=%.3f df=%d" % hl)
    json.dump({"chi2": hl[0], "p": hl[1], "df": hl[2]}, open(os.path.join(OUT, "hosmer_lemeshow.json"), "w"), indent=1)
    try:
        frac, mp = calibration_curve(y, lr_cv, n_bins=5, strategy="quantile")
        json.dump({"frac": frac.tolist(), "mean_pred": mp.tolist()}, open(os.path.join(OUT, "calibration.json"), "w"))
    except Exception as e:
        print("calibration skipped:", e)

    # ---------------- external validation (gene panel + senescence score)
    srg = json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))
    ext_rows, ext_preds, ext_score = [], {}, {}
    for acc in ["GSE169077", "GSE283079", "GSE55235", "GSE55457"]:
        p = os.path.join(WORK, f"expr_{acc}.csv")
        if not os.path.exists(p):
            continue
        e2, l2 = load_cohort(acc)
        y2 = y_of(l2)
        present = [g for g in signature if g in e2.index]
        if len(present) < 3:
            print("skip", acc, "(too few signature genes)"); continue
        z = lambda D: (D - D.mean()) / D.std().replace(0, np.nan)
        Xd = z(expr.loc[present].T).fillna(0.0)
        m = LogisticRegression(max_iter=5000, C=1.0).fit(Xd.values, y)
        pr = m.predict_proba(z(e2.loc[present].T).fillna(0.0).values)[:, 1]
        auc = roc_auc_score(y2, pr); lo2, hi2 = boot_ci(y2, pr)
        # senescence score transfer
        sc2 = ssgsea_score(e2, srg).values
        auc_s = roc_auc_score(y2, sc2); los, his = boot_ci(y2, sc2)
        # single-gene direction consistency
        for g in present:
            v = e2.loc[g].values
            a = roc_auc_score(y2, v)
            ext_rows.append({"cohort": acc, "gene": g, "auc_single": a, "auc_abs": max(a, 1 - a),
                             "direction_consistent": bool(np.sign(expr.loc[g, labels == "OA"].mean() - expr.loc[g, labels == "Normal"].mean())
                                                          == np.sign(e2.loc[g, l2 == "OA"].mean() - e2.loc[g, l2 == "Normal"].mean()))})
        ext_rows.append({"cohort": acc, "gene": "MULTI-GENE SIGNATURE", "auc_single": auc, "auc_abs": auc,
                         "ci_lo": lo2, "ci_hi": hi2, "n": int(len(y2)), "n_oa": int(y2.sum())})
        ext_rows.append({"cohort": acc, "gene": "SENESCENCE SCORE (ssGSEA)", "auc_single": auc_s, "auc_abs": auc_s,
                         "ci_lo": los, "ci_hi": his, "n": int(len(y2)), "n_oa": int(y2.sum())})
        ext_preds[acc] = {"y": y2.tolist(), "p": pr.tolist(), "auc": float(auc),
                          "ci": [float(lo2), float(hi2)], "genes_present": present,
                          "auc_score": float(auc_s), "ci_score": [float(los), float(his)]}
        print(f"VALIDATION {acc}: n={len(y2)} (OA={int(y2.sum())})  panel AUC={auc:.3f} [{lo2:.3f},{hi2:.3f}]  "
              f"senescence-score AUC={auc_s:.3f} [{los:.3f},{his:.3f}]  genes={len(present)}/{len(signature)}")
    pd.DataFrame(ext_rows).to_csv(os.path.join(OUT, "external_validation.csv"), index=False)
    json.dump(ext_preds, open(os.path.join(OUT, "external_predictions.json"), "w"), indent=1)

    # ---------------- SHAP
    import shap
    Xdf = pd.DataFrame(Xs, columns=signature)
    xgbm = xgb.XGBClassifier(n_estimators=300, max_depth=3, learning_rate=0.05, subsample=0.9,
                             random_state=0, eval_metric="logloss", verbosity=0).fit(Xs, y)
    sv = shap.TreeExplainer(xgbm).shap_values(Xs)
    if isinstance(sv, list):
        sv = sv[1]
    np.save(os.path.join(OUT, "shap_values.npy"), sv)
    Xdf.to_csv(os.path.join(OUT, "shap_X.csv"), index=False)

    # ---------------- nomogram
    Z = pd.DataFrame(StandardScaler().fit_transform(Xs), columns=signature)
    pts = nomogram_points(beta, Z)
    lin = beta @ Z.values.T + lr.named_steps["m"].intercept_[0]
    prob = 1 / (1 + np.exp(-lin))
    json.dump({"genes": signature, "beta": beta.tolist(),
               "ranges": {g: [float(Z[g].min()), float(Z[g].max())] for g in signature},
               "total_points": pts.sum(1).tolist(), "prob": prob.tolist()},
              open(os.path.join(OUT, "nomogram.json"), "w"), indent=1)
    print("STEP3 DONE")
