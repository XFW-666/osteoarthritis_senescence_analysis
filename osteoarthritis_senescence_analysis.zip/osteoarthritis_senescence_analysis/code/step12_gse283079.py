"""
step12_gse283079.py — why did the signature not validate in GSE283079?

Rather than reporting only "AUC 0.461", this quantifies what that cohort could actually have
detected, tests the observed AUC against the null by permutation, and inspects the cohort for the
technical and compositional features that distinguish it from the three cohorts that did validate.
"""
import os, sys, json, math, re
import numpy as np
import pandas as pd
import urllib.request, ssl
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve

BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); OUT = os.path.join(BASE, "results")
DATA = os.path.join(BASE, "data")
CTX = ssl.create_default_context(); UA = {"User-Agent": "Mozilla/5.0"}


def load(acc):
    e = pd.read_csv(os.path.join(WORK, f"expr_{acc}.csv"), index_col=0)
    l = pd.read_csv(os.path.join(WORK, f"labels_{acc}.csv"), index_col=0).iloc[:, 0]
    return e, l


def auc_se(auc, n1, n2):
    """Hanley-McNeil standard error of an AUC."""
    q1 = auc / (2 - auc)
    q2 = 2 * auc ** 2 / (1 + auc)
    return math.sqrt((auc * (1 - auc) + (n1 - 1) * (q1 - auc ** 2) +
                      (n2 - 1) * (q2 - auc ** 2)) / (n1 * n2))


def main():
    print("=" * 96)
    print("WHY DID THE SIGNATURE NOT VALIDATE IN GSE283079?")
    print("=" * 96)
    e2, l2 = load("GSE283079")
    y = (l2 == "OA").astype(int).values
    n1, n2 = int(y.sum()), int((1 - y).sum())
    print(f"cohort: {e2.shape[1]} samples, {e2.shape[0]} genes | {n1} OA vs {n2} non-OA")

    expr, labels = load("GSE114007")
    sig = json.load(open(os.path.join(OUT, "signature.json")))
    present = [g for g in sig if g in e2.index]
    z = lambda D: ((D - D.mean()) / D.std().replace(0, np.nan)).fillna(0.0)
    m = LogisticRegression(max_iter=5000, C=1.0).fit(z(expr.loc[present].T).values,
                                                    (labels == "OA").astype(int).values)
    p = m.predict_proba(z(e2.loc[present].T).values)[:, 1]
    auc = roc_auc_score(y, p)
    se = auc_se(auc, n1, n2)
    print(f"\n1. observed discrimination: AUC = {auc:.3f} (Hanley-McNeil SE {se:.3f}, "
          f"95% CI {auc-1.96*se:.3f}-{auc+1.96*se:.3f})")

    # ---- permutation test of the AUC against the null
    rng = np.random.default_rng(42)
    null = []
    for _ in range(20000):
        yy = rng.permutation(y)
        null.append(roc_auc_score(yy, p))
    null = np.array(null)
    p_perm = float(np.mean(np.abs(null - 0.5) >= abs(auc - 0.5)))
    np.save(os.path.join(OUT, "gse283079_permutation_null.npy"), null)
    pd.DataFrame({"prob": p, "group": l2.values}).to_csv(
        os.path.join(OUT, "gse283079_predictions.csv"), index=False)
    print(f"2. permutation test ({len(null):,} label shuffles): P = {p_perm:.3f} "
          f"-> the observed AUC is {'not distinguishable from' if p_perm > 0.05 else 'different from'} chance")

    # ---- what could this cohort detect?
    print(f"3. detectable effect at 80% power (two-sided 5%):")
    for power_z in (2.802,):     # z_{0.025} + z_{0.20}
        det = 0.5 + power_z * se
        print(f"      smallest AUC the cohort could detect = {det:.3f} "
              f"(i.e. it is powered only for near-perfect discrimination)")

    # ---- provenance: does the GEO record support the case/control split?
    print(f"\n4. provenance of the {n2} non-OA samples")
    url = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE283079&targ=gsm&form=text&view=brief"
    conflict = None
    try:
        txt = urllib.request.urlopen(urllib.request.Request(url, headers=UA),
                                     timeout=90, context=CTX).read().decode("utf8", "ignore")
        blocks = txt.split("^SAMPLE = ")[1:]
        rows = []
        for b in blocks:
            rows.append({
                "gsm": b.split("\n")[0].strip(),
                "title": "; ".join(re.findall(r"!Sample_title = (.*)", b)).strip(),
                "source": "; ".join(re.findall(r"!Sample_source_name_ch1 = (.*)", b)).strip(),
                "chars": "; ".join(re.findall(r"!Sample_characteristics_ch1 = (.*)", b)).strip(),
            })
        meta = pd.DataFrame(rows)
        meta["chars"] = meta["chars"].str.replace("\r", "", regex=False)
        meta["title"] = meta["title"].str.replace("\r", "", regex=False)
        # the counts file orders columns OA_syn_1..36 then non-OA_syn_1..5
        cols = list(pd.read_csv(os.path.join(DATA, "GSE283079_gene_count_RNAseq.txt.gz"),
                                sep="\t", nrows=0).columns)[1:]
        non_cols = [c for c in cols if c.startswith("non-OA")]
        print(f"      counts-file columns: {len(cols)}  (OA-named {len(cols)-len(non_cols)}, "
              f"non-OA-named {len(non_cols)})")
        print(f"      non-OA-named columns: {non_cols}")
        if len(meta) == len(cols):
            mapped = meta.iloc[[cols.index(c) for c in non_cols]]
            print("      GEO records for those columns:")
            for _, r in mapped.iterrows():
                print(f"         {r['gsm']}  title={r['title'][:30]!r}  chars={r['chars'][:58]!r}")
            # NB: the submitter writes "non-osteoarthritis (OA)", which contains the substring
            # "osteoarthritis"; a naive substring test would misclassify the controls.
            def _is_oa(s):
                s = s.lower()
                return ("osteoarthritis" in s or "oa" in s) and \
                       ("non-osteoarthritis" not in s and "non-oa" not in s)
            meta["oa_label"] = meta["chars"].map(_is_oa)
            n_oa_meta = int(meta["oa_label"].sum())
            n_non_meta = int((~meta["oa_label"]).sum())
            print(f"      GEO metadata: {n_oa_meta} labelled osteoarthritis, "
                  f"{n_non_meta} labelled non-osteoarthritis")
            print("      >> the case/control split IS supported by the deposited metadata.")
            print("         Note the awkward wording: the controls read")
            print("         'disease state: non-osteoarthritis (OA)'.")
            conflict = False
        meta.to_csv(os.path.join(OUT, "gse283079_sample_metadata.csv"), index=False)
    except Exception as ex:
        print("      metadata fetch failed:", type(ex).__name__, str(ex)[:70])

    # ---- technical comparison against the cohorts that validated
    print(f"\n5. technical features vs the cohorts that did validate")
    rows = []
    for acc in ["GSE283079", "GSE114007", "GSE55235", "GSE55457", "GSE169077"]:
        try:
            e, l = load(acc)
        except Exception:
            continue
        yy = (l == "OA").astype(int).values
        n_a, n_b = int(yy.sum()), int((1 - yy).sum())
        med = e.median(0)
        det = (e > e.median().median() * 0.0).sum(0)  # placeholder, replaced below
        rows.append({
            "cohort": acc, "n_OA": n_a, "n_nonOA": n_b,
            "ratio": round(n_a / max(n_b, 1), 1),
            "genes": int(e.shape[0]),
            "median_expression": round(float(e.values.mean()), 2),
            "frac_zero": round(float((e.values <= 0).mean()), 4),
            "sig_genes_found": sum(1 for g in sig if g in e.index),
        })
    tab = pd.DataFrame(rows)
    print(tab.to_string(index=False))
    tab.to_csv(os.path.join(OUT, "gse283079_cohort_comparison.csv"), index=False)

    # ---- gene-level direction consistency
    print(f"\n6. signature-gene direction consistency in GSE283079")
    dirrows = []
    for g in present:
        d1 = expr.loc[g, labels == "OA"].mean() - expr.loc[g, labels == "Normal"].mean()
        d2 = e2.loc[g, l2 == "OA"].mean() - e2.loc[g, l2 != "OA"].mean()
        dirrows.append({"gene": g, "logFC_discovery": round(float(d1), 3),
                        "logFC_GSE283079": round(float(d2), 3),
                        "consistent": bool(np.sign(d1) == np.sign(d2))})
    dtab = pd.DataFrame(dirrows)
    print(dtab.to_string(index=False))
    dtab.to_csv(os.path.join(OUT, "gse283079_direction.csv"), index=False)

    summary = {"n_OA": n1, "n_nonOA": n2, "auc": float(auc), "auc_se": float(se),
               "auc_ci": [float(auc - 1.96 * se), float(auc + 1.96 * se)],
               "permutation_p": p_perm, "detectable_auc_80pct": float(0.5 + 2.802 * se),
               "genes_present": len(present), "n_signature": len(sig),
               "direction_consistent": int(dtab["consistent"].sum())}
    json.dump(summary, open(os.path.join(OUT, "gse283079_diagnostics.json"), "w"), indent=1)
    print(f"\nwrote gse283079_diagnostics.json: {json.dumps(summary)}")


if __name__ == "__main__":
    main()
