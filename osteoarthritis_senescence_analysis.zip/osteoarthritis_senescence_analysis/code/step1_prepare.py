"""
step1_prepare.py — real-data ingestion + normalization for the OA senescence study.
All expression data are downloaded from NCBI GEO; gene sets from Enrichr.
Outputs go to ./work/
"""
import os, gzip, re, json, io
import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
WORK = os.path.join(BASE, "work"); os.makedirs(WORK, exist_ok=True)


# ----------------------------------------------------------------------------- utils
def _open(path):
    return gzip.open(path, "rt", encoding="utf8", errors="ignore") if path.endswith(".gz") else open(path, "rt", encoding="utf8", errors="ignore")


def parse_series_matrix(path):
    """Return (expr_df [probe x sample], meta_df [sample x field]).

    GEO series-matrix header lines are TAB separated (!Sample_title\\t"a"\\t"b"),
    so both '\\t' and '=' separators are accepted here.
    """
    meta_lines, table_lines, in_table = [], [], False
    with _open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith("!series_matrix_table_begin"):
                in_table = True; continue
            if line.startswith("!series_matrix_table_end"):
                in_table = False; continue
            if in_table:
                table_lines.append(line)
            elif line.startswith("!"):
                meta_lines.append(line)

    fields = {}
    for line in meta_lines:
        m = re.match(r'^!([A-Za-z0-9_]+)[\s=]+(.*)$', line)
        if not m:
            continue
        key, val = m.group(1), m.group(2)
        vals = re.findall(r'"([^"]*)"', val)
        if not vals:
            vals = [v for v in re.split(r"\t+", val.strip()) if v != ""]
        fields.setdefault(key, []).append(vals)

    gsm = fields.get("Sample_geo_accession", [[]])[0]
    meta = pd.DataFrame({"gsm": gsm})
    for key, valgroups in fields.items():
        if not key.startswith("Sample_") or key == "Sample_geo_accession":
            continue
        if key.startswith("Sample_characteristics"):
            # several characteristic lines, one value per sample on each line
            rows = [v for v in valgroups if len(v) == len(gsm)]
            if rows:
                meta["characteristics"] = [" | ".join(str(x) for x in tup)
                                           for tup in zip(*rows)]
            continue
        vals = valgroups[0]
        if len(vals) == len(gsm):
            meta[key.replace("Sample_", "")] = vals

    # expression table
    rows = [t.split("\t") for t in table_lines if t.strip()]
    header = [c.strip('"') for c in rows[0]]
    idx = [r[0].strip('"') for r in rows[1:]]
    arr = np.array([[np.nan if (c.strip('"') in ("", "NA", "null")) else float(c.strip('"')) for c in r[1:]] for r in rows[1:]], dtype=float)
    expr = pd.DataFrame(arr, index=idx, columns=header[1:])
    return expr, meta


def parse_platform_soft(path):
    """Parse a GEO platform SOFT file (form=text&view=data) -> DataFrame with 'Gene Symbol'.

    If the download is truncated (no !platform_table_end), the trailing partial row is dropped.
    """
    rows, in_tab, closed = [], False, False
    with _open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith("!platform_table_begin"):
                in_tab = True; continue
            if line.startswith("!platform_table_end"):
                in_tab = False; closed = True; continue
            if in_tab and line.strip():
                rows.append(line.split("\t"))
    if not closed and len(rows) > 1:
        rows = rows[:-1]          # last row may be cut mid-field
    hdr = [h.strip() for h in rows[0]]
    df = pd.DataFrame(rows[1:], columns=hdr)
    if not closed:
        print(f"   NOTE: platform file {os.path.basename(path)} is truncated; parsed {len(df)} probe rows")
    return df


def collapse_to_symbols(expr, probe2sym, agg="max_mean"):
    """Collapse probe-level matrix to gene symbols (keep probe with highest mean if duplicated)."""
    s = pd.Series(probe2sym)
    common = expr.index.intersection(s.dropna().index)
    e = expr.loc[common].copy()
    e["__sym"] = [str(s[i]).split("///")[0].strip() for i in e.index]
    e = e[e["__sym"].notna() & (e["__sym"] != "") & (e["__sym"] != "nan")]
    e["__mean"] = e.drop(columns="__sym").mean(axis=1)
    e = e.sort_values("__mean", ascending=False).drop_duplicates("__sym")
    e = e.drop(columns="__mean").set_index("__sym")
    e.index.name = "gene"
    return e.astype(float)


def quantile_normalize(df):
    """Quantile-normalize columns (samples) of a log-scale expression matrix."""
    x = df.values.astype(float)
    ranks = np.argsort(np.argsort(x, axis=0), axis=0)
    sorted_means = np.sort(x, axis=0).mean(axis=1)
    out = sorted_means[ranks]
    return pd.DataFrame(out, index=df.index, columns=df.columns)


def log2_if_needed(df, thresh=60):
    """log2-transform if the matrix is on a linear intensity scale."""
    if np.nanmax(df.values) > thresh:
        return np.log2(df.clip(lower=1))
    return df


def cpm_log2(counts, prior=1.0):
    libsize = counts.sum(axis=0)
    cpm = counts.div(libsize, axis=1) * 1e6
    return np.log2(cpm + prior)


def zscore_rows(df):
    return df.sub(df.mean(axis=1), axis=0).div(df.std(axis=1).replace(0, np.nan), axis=0)


# ----------------------------------------------------------------------------- cohorts
def load_gse114007():
    """Discovery cohort: human knee articular cartilage, RNA-seq, 20 OA vs 18 normal.

    GEO supplementary files provide submitter-normalized log2 expression values
    (GSE114007_OA_normalized.counts.txt.gz / GSE114007_normal_normalized.counts.txt.gz).
    Each file ends with two summary columns ('Average <group>' and 'Max') that are dropped.
    """
    parts = []
    for fn, lab in [("GSE114007_OA_normalized.counts.txt.gz", "OA"),
                    ("GSE114007_normal_normalized.counts.txt.gz", "Normal")]:
        p = os.path.join(DATA, fn)
        df = pd.read_csv(p, sep="\t", index_col=0)
        drop = [c for c in df.columns if str(c).strip().lower().startswith("average") or str(c).strip().lower() == "max"]
        df = df.drop(columns=drop)
        df = df.loc[:, ~df.columns.duplicated()]
        assert len(df.columns) in (18, 20), (fn, df.shape)
        parts.append(df)
    expr = pd.concat(parts, axis=1)
    expr = expr[~expr.index.isna()]
    expr.index = [str(i).strip() for i in expr.index]
    expr = expr[~expr.index.duplicated(keep="first")]
    expr.index.name = "gene"
    expr = expr.astype(float)
    # values are already log2-scale normalized expression -> no further transform
    labels = pd.Series(["OA" if str(c).upper().startswith("OA") else "Normal" for c in expr.columns],
                       index=expr.columns, name="group")
    return expr, labels, expr


def load_gse283079():
    """Validation (cross-tissue, RNA-seq): knee OA synovium, 36 OA vs 5 non-OA."""
    p = os.path.join(DATA, "GSE283079_gene_count_RNAseq.txt.gz")
    df = pd.read_csv(p, sep="\t", index_col=0)
    syms = []
    for i in df.index:
        i = str(i)
        syms.append(i.split("_")[-1] if "_" in i else i)
    df["__sym"] = syms
    df["__mean"] = df.drop(columns="__sym").mean(axis=1)
    df = df.sort_values("__mean", ascending=False).drop_duplicates("__sym").drop(columns="__mean")
    df = df.set_index("__sym"); df.index.name = "gene"
    counts = df.astype(float)
    expr = cpm_log2(counts)
    labels = pd.Series(["OA" if c.startswith("OA_") else "Normal" for c in expr.columns], index=expr.columns, name="group")
    return expr, labels, counts


def load_microarray(gse, gpl_soft, label_map):
    """label_map: fn(sample_meta_row) -> 'OA'/'Normal'/None"""
    expr, meta = parse_series_matrix(os.path.join(DATA, f"{gse}_series_matrix.txt.gz"))
    plat = parse_platform_soft(os.path.join(DATA, gpl_soft))
    symcol = None
    for c in plat.columns:
        if c.strip().lower() in ("gene symbol", "genesymbol", "gene_symbol"):
            symcol = c; break
    probe2sym = dict(zip(plat.iloc[:, 0], plat[symcol])) if symcol else {}
    expr = log2_if_needed(expr)
    expr = quantile_normalize(expr)
    expr = collapse_to_symbols(expr, probe2sym)
    meta = meta.set_index("gsm")
    labels = pd.Series({c: label_map(meta.loc[c]) for c in expr.columns}, name="group")
    keep = labels[labels.notna()].index
    expr = expr[keep]; labels = labels[keep]
    return expr, labels, meta


def _chars(row):
    """Only the curated 'characteristics' field is used for labelling: other GEO fields
    (e.g. data_processing) contain words such as 'normalization' that would mislabel samples."""
    return str(row.get("characteristics", "")).lower()


def lab_gse55235(row):
    t = _chars(row)
    if "osteoarthrit" in t: return "OA"
    if "healthy" in t: return "Normal"
    return None


def lab_gse55457(row):
    t = _chars(row)
    if "osteoarthritis" in t: return "OA"
    if "normal control" in t: return "Normal"
    return None


def lab_gse169077(row):
    t = _chars(row)
    if "normal" in t: return "Normal"
    if "oa" in t: return "OA"
    return None


COHORT_META = {
    "GSE114007": ("cartilage", "RNA-seq (Illumina HiSeq 2000, GPL11154)", "Discovery / training"),
    "GSE283079": ("synovium", "RNA-seq (Illumina NovaSeq 6000, GPL24676)", "External validation (cross-tissue)"),
    "GSE55235":  ("synovium", "Affymetrix HG-U133A (GPL96)", "External validation (cross-tissue, cross-platform)"),
    "GSE55457":  ("synovium", "Affymetrix HG-U133A (GPL96)", "External validation (cross-tissue, cross-platform)"),
    "GSE169077": ("cartilage", "Affymetrix HG-U133A (GPL96)", "External validation (same tissue, cross-platform)"),
}

if __name__ == "__main__":
    import sys
    want = sys.argv[1:] or ["GSE114007", "GSE283079", "GSE55235", "GSE55457", "GSE169077"]
    store = {}
    if os.path.exists(os.path.join(WORK, "cohorts.json")):
        store = json.load(open(os.path.join(WORK, "cohorts.json")))

    def record(acc, e, l):
        t, p, role = COHORT_META[acc]
        store[acc] = {"n": int(e.shape[1]), "oa": int((l == "OA").sum()),
                      "normal": int((l == "Normal").sum()), "tissue": t, "platform": p, "role": role,
                      "genes": int(e.shape[0])}
        print(f"{acc} [{role}] {t}: {e.shape}  {dict(l.value_counts())}")

    if "GSE114007" in want:
        e, l, _ = load_gse114007()
        e.to_csv(os.path.join(WORK, "expr_GSE114007.csv")); l.to_csv(os.path.join(WORK, "labels_GSE114007.csv"))
        record("GSE114007", e, l)

    if "GSE283079" in want:
        e, l, _ = load_gse283079()
        e.to_csv(os.path.join(WORK, "expr_GSE283079.csv")); l.to_csv(os.path.join(WORK, "labels_GSE283079.csv"))
        record("GSE283079", e, l)

    for acc, fn in [("GSE55235", lab_gse55235), ("GSE55457", lab_gse55457), ("GSE169077", lab_gse169077)]:
        if acc in want:
            e, l, _ = load_microarray(acc, "GPL96_soft.txt", fn)
            e.to_csv(os.path.join(WORK, f"expr_{acc}.csv")); l.to_csv(os.path.join(WORK, f"labels_{acc}.csv"))
            record(acc, e, l)

    json.dump(store, open(os.path.join(WORK, "cohorts.json"), "w"), indent=1)
    print(json.dumps(store, indent=1))
