"""Conclusion and statement updates for the new datasets."""

def patch(path, edits):
    src = open(path, encoding="utf-8").read()
    for label, old, new in edits:
        if src.count(old) != 1:
            raise SystemExit(f"anchor problem ({src.count(old)}x) for {label}")
        src = src.replace(old, new, 1)
        print("  ok ", label)
    open(path, "w", encoding="utf-8").write(src)


patch("manuscript_text2.py", [
    ("conclusion",
     '     "platforms. Two independent single-cell atlases localised the signature to homeostatic chondrocytes, "\n'
     '     "and drug-repurposing analysis nominated luteolin, alvocidib, curcumin and quercetin as candidate "',
     '     "platforms. Two independent single-cell atlases localised the signature to homeostatic chondrocytes, "\n'
     '     "and both programme arms reproduced in an independent cartilage cohort, although there the "\n'
     '     "signature marked joint-level rather than lesion-level disease and was not osteoarthritis-specific. "\n'
     '     "Drug-repurposing analysis nominated luteolin, alvocidib, curcumin and quercetin as candidate "'),
    ("acknowledgements",
     '     "(GSE114007, GSE169077, GSE283079, GSE55235, GSE55457, GSE104782 and GSE255460) and the maintainers of "',
     '     "(GSE114007, GSE169077, GSE283079, GSE55235, GSE55457, GSE104782, GSE255460, GSE57218, GSE43269 and "\n'
     '     "GSE73626) and the maintainers of "'),
    ("data availability",
     '     "Omnibus under accession numbers GSE114007, GSE169077, GSE283079, GSE55235, GSE55457, GSE104782 and "\n'
     '     "GSE255460. Genetic instruments were taken from the public eQTLGen cis-eQTL summary statistics and "',
     '     "Omnibus under accession numbers GSE114007, GSE169077, GSE283079, GSE55235, GSE55457, GSE104782, "\n'
     '     "GSE255460, GSE57218, GSE43269 and GSE73626. Genetic instruments were taken from the public eQTLGen "\n'
     '     "cis-eQTL summary statistics and "'),
])
print("DONE")
