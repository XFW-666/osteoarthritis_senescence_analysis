"""
step16_gse255460_analysis.py — senescence-signature localisation in a second, independent
single-cell cohort that ships a normal control arm (GSE255460).

Design notes that drive the statistics:
  * Cells from one donor are not independent, so every celltype comparison is run on
    per-donor means (paired across donors) rather than on pooled cells.
  * The control arm is a single donor, so control-vs-OA contrasts are descriptive only
    and are reported with that caveat instead of a donor-level P value.
  * The within-OA contrast between weight-bearing (WB) and non-weight-bearing (NWB)
    cartilage has several donors per side and is therefore the one contrast that is both
    internal and donor-controlled.
"""
import json, os
import numpy as np
import pandas as pd
from scipy import stats

OUT = "data/gse255460"
RES = "results"

SIG = ["ETS2", "GADD45B", "JUN", "CDKN1B", "UBC", "CDKN1A", "HLA-F", "CDK2"]
CHONDRO = ["HomC", "ProC", "RegC", "preFC", "HTC", "preHTC", "preInfC", "RepC", "FC", "InfC"]
MARKERS = {
    "HomC": ["PRG4", "CHAD", "ACAN", "SOX9", "COL2A1", "CILP", "TIMP3", "PRELP"],
    "HTC": ["COL10A1", "RUNX2", "ALPL", "IBSP"],
    "FC": ["COL1A1", "COL1A2", "THY1"],
    "InfC": ["IL6", "CXCL8", "CCL2", "NFKB1"],
    "ProC": ["MKI67", "TOP2A", "UBE2C"],
    "EC": ["PECAM1", "VWF"],
}


def bh(p):
    p = np.asarray(p, float)
    n = len(p)
    o = np.argsort(p)
    q = np.empty(n)
    q[o] = np.minimum.accumulate((p[o] * n / (np.arange(n) + 1))[::-1])[::-1]
    return np.clip(q, 0, 1)


def cliffs_delta(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if len(a) == 0 or len(b) == 0:
        return np.nan
    # rank-based Cliff's delta without the O(n^2) pairwise loop
    allv = np.concatenate([a, b])
    r = stats.rankdata(allv)
    ra, rb = r[:len(a)].sum(), r[len(a):].sum()
    u = ra - len(a) * (len(a) + 1) / 2          # Mann-Whitney U for a
    return 2 * u / (len(a) * len(b)) - 1


def main():
    mat = pd.read_pickle(os.path.join(OUT, "selected_genes.pkl"))
    md = pd.read_pickle(os.path.join(OUT, "meta.pkl"))
    print(f"matrix {mat.shape}, metadata {md.shape}")

    # library-size normalisation uses the full per-cell UMI count shipped with the metadata
    lib = md["nCount_RNA"].astype(float).values
    norm = np.log1p(mat.values / lib[:, None] * 1e4)
    norm = pd.DataFrame(norm, index=mat.index, columns=mat.columns)

    zs = (norm - norm.mean(0)) / (norm.std(0) + 1e-12)
    sig_present = [g for g in SIG if g in zs.columns]
    score = zs[sig_present].mean(1)

    df = md.copy()
    df["signature_score"] = score.values
    df = df[df["celltype"].isin(CHONDRO + ["EC"])]
    print(f"cells analysed: {len(df)}")
    print("donor x group:\n", pd.crosstab(df["sample"], df["group"]).to_string())

    # ---------- 1. celltype localisation, donor-controlled ----------
    donors = sorted(df["sample"].unique())
    per = df.groupby(["sample", "celltype"])["signature_score"].mean().unstack()
    ncell = df.groupby(["sample", "celltype"])["signature_score"].size().unstack()
    print("\nper-donor mean signature score by celltype:\n", per.round(3).to_string())

    rows = []
    hom = per["HomC"]
    for ct in [c for c in CHONDRO + ["EC"] if c in per.columns]:
        v = per[ct]
        pair = pd.concat([hom, v], axis=1).dropna()
        if ct == "HomC":
            rows.append(dict(celltype=ct, n_cells=int(ncell[ct].sum()), n_donors=len(v),
                             mean_score=float(df.loc[df.celltype == ct, "signature_score"].mean()),
                             median_donor_delta=0.0, wilcoxon_p=np.nan, adj_p=np.nan,
                             cliffs_delta_vs_HomC=np.nan, direction="reference"))
            continue
        if len(pair) >= 5:
            try:
                w = stats.wilcoxon(pair["HomC"], pair[ct])
                wp = float(w.pvalue)
            except Exception:
                wp = np.nan
        else:
            wp = np.nan
        rows.append(dict(celltype=ct, n_cells=int(ncell[ct].sum()), n_donors=len(pair),
                         mean_score=float(df.loc[df.celltype == ct, "signature_score"].mean()),
                         median_donor_delta=float((pair["HomC"] - pair[ct]).median()),
                         wilcoxon_p=wp, adj_p=np.nan,
                         cliffs_delta_vs_HomC=float(cliffs_delta(
                             df.loc[df.celltype == "HomC", "signature_score"],
                             df.loc[df.celltype == ct, "signature_score"])),
                         direction="higher" if pair["HomC"].mean() > pair[ct].mean() else "lower"))
    ct_tab = pd.DataFrame(rows).sort_values("mean_score", ascending=False)
    mask = ct_tab["wilcoxon_p"].notna()
    ct_tab.loc[mask, "adj_p"] = bh(ct_tab.loc[mask, "wilcoxon_p"])
    ct_tab.to_csv(os.path.join(RES, "gse255460_signature_by_celltype.csv"), index=False)
    print("\ncelltype table:\n", ct_tab.round(4).to_string(index=False))

    # ---------- 2. within-OA weight-bearing vs non-weight-bearing ----------
    oa = df[df["group"].isin(["WB", "NWB"])]
    wb = oa[oa.group == "WB"].groupby("sample")["signature_score"].mean()
    nwb = oa[oa.group == "NWB"].groupby("sample")["signature_score"].mean()
    pair = pd.concat([wb.rename("WB"), nwb.rename("NWB")], axis=1).dropna()
    if len(pair) >= 5:
        wp = float(stats.wilcoxon(pair["WB"], pair["NWB"]).pvalue)
    else:
        wp = np.nan
    wb_nwb = dict(
        n_donors=int(len(pair)),
        mean_WB=float(wb.mean()), mean_NWB=float(nwb.mean()),
        delta=float(wb.mean() - nwb.mean()), wilcoxon_p=wp,
        cliffs_delta=float(cliffs_delta(oa.loc[oa.group == "WB", "signature_score"],
                                        oa.loc[oa.group == "NWB", "signature_score"])))
    print("\nWB vs NWB (within OA, donor-controlled):", json.dumps(wb_nwb, indent=2))
    pd.DataFrame([wb_nwb]).to_csv(os.path.join(RES, "gse255460_wb_vs_nwb.csv"), index=False)

    # ---------- 3. control vs OA, descriptive only (one control donor) ----------
    rows = []
    for ct in ["HomC", "all"]:
        sub = df if ct == "all" else df[df.celltype == ct]
        for grp in ["Control", "OA"]:
            s = sub.loc[sub.trait == grp, "signature_score"]
            rows.append(dict(stratum=ct, trait=grp, n_cells=int(len(s)),
                             n_donors=int(sub.loc[sub.trait == grp, "sample"].nunique()),
                             mean=float(s.mean()), median=float(s.median())))
    ctl = df.loc[df.trait == "Control", "signature_score"]
    oav = df.loc[df.trait == "OA", "signature_score"]
    hom_ctl = df.loc[(df.trait == "Control") & (df.celltype == "HomC"), "signature_score"]
    hom_oa = df.loc[(df.trait == "OA") & (df.celltype == "HomC"), "signature_score"]
    ctl_oa = dict(
        note="control arm is a single donor; cell-level P values are pseudoreplicated",
        HomC_control_mean=float(hom_ctl.mean()), HomC_OA_mean=float(hom_oa.mean()),
        HomC_cell_level_p=float(stats.mannwhitneyu(hom_ctl, hom_oa).pvalue),
        HomC_cliffs_delta=float(cliffs_delta(hom_ctl, hom_oa)),
        all_control_mean=float(ctl.mean()), all_OA_mean=float(oav.mean()),
        all_cell_level_p=float(stats.mannwhitneyu(ctl, oav).pvalue))
    print("\ncontrol vs OA (descriptive):", json.dumps(ctl_oa, indent=2))
    pd.DataFrame(rows).to_csv(os.path.join(RES, "gse255460_control_vs_oa.csv"), index=False)

    # ---------- 4. HomC proportion ----------
    prop = df.groupby("sample").apply(
        lambda g: pd.Series({"n_cells": len(g),
                             "homc_frac": float((g.celltype == "HomC").mean()),
                             "trait": g.trait.iloc[0], "group": g.group.iloc[0]}),
        include_groups=False)
    print("\nHomC fraction per donor:\n", prop.round(4).to_string())
    prop.to_csv(os.path.join(RES, "gse255460_homc_proportion.csv"))

    # ---------- 5. marker validation ----------
    mrows = []
    for ct, genes in MARKERS.items():
        for g in genes:
            if g not in norm.columns:
                continue
            v = norm[g]
            inside = df.celltype == ct
            mrows.append(dict(celltype=ct, gene=g,
                              mean_in=float(v[inside.values].mean()),
                              mean_out=float(v[~inside.values].mean()),
                              delta=float(v[inside.values].mean() - v[~inside.values].mean()),
                              auc=float(stats.mannwhitneyu(v[inside.values], v[~inside.values]).statistic
                                        / (inside.sum() * (~inside).sum()))))
    mk = pd.DataFrame(mrows)
    mk.to_csv(os.path.join(RES, "gse255460_marker_validation.csv"), index=False)
    print("\nmarker validation (mean AUC in vs out):\n",
          mk.groupby("celltype")["auc"].agg(["mean", "min"]).round(3).to_string())

    # ---------- 6. per-cell and per-donor tables for the figure ----------
    df[["celltype", "sample", "trait", "group", "signature_score"]].to_csv(
        os.path.join(RES, "gse255460_cell_scores.csv"), index=False)
    per.to_csv(os.path.join(RES, "gse255460_per_donor_celltype.csv"))

    def _row(ct):
        s = ct_tab[ct_tab.celltype == ct]
        return (float(s["mean_score"].iloc[0]), float(s["median_donor_delta"].iloc[0]),
                float(s["wilcoxon_p"].iloc[0])) if len(s) else (float("nan"),) * 3

    homc_mean, _, _ = _row("HomC")
    pre_d, pre_p = _row("preInfC")[1:]
    inf_d, inf_p = _row("InfC")[1:]
    summary = dict(
        dataset="GSE255460", n_cells_total=int(len(md)), n_cells_analysed=int(len(df)),
        n_donors=int(df["sample"].nunique()),
        n_control_donors=int(df.loc[df.trait == "Control", "sample"].nunique()),
        celltypes={k: int(v) for k, v in df.celltype.value_counts().items()},
        # the population with the highest mean and the reference population are not the same:
        # the sparsely sampled pre-inframmatory population is nominally highest but does not
        # differ significantly from homeostatic chondrocytes.
        top_by_mean=str(ct_tab.iloc[0]["celltype"]),
        top_by_mean_score=float(ct_tab.iloc[0]["mean_score"]),
        homc_mean=homc_mean,
        preinfc_delta=pre_d, preinfc_p=pre_p,
        infc_delta=inf_d, infc_p=inf_p,
        n_celltypes_lower_than_HomC_fdr05=int((ct_tab["adj_p"] < 0.05).sum()),
        wb_vs_nwb=wb_nwb, control_vs_oa=ctl_oa,
        signature_genes=sig_present,
        marker_auc_min=float(mk["auc"].min()), marker_auc_mean=float(mk["auc"].mean()))
    with open(os.path.join(RES, "gse255460_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print("\nSTEP16 DONE")


if __name__ == "__main__":
    main()
