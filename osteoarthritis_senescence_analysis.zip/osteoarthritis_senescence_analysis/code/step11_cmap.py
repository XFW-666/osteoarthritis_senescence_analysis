"""
step11_cmap.py — connectivity-map style analysis: which compounds reverse the osteoarthritis
transcriptional signature?

Rather than testing the signature genes for over-representation (what the Enrichr step does), this
computes a proper connectivity score for every perturbation signature in the LINCS L1000 and the
original CMap libraries:

    reversal  = z(UP_query  x DOWN_compound) + z(DOWN_query x UP_compound)
    mimicry   = z(UP_query  x UP_compound)   + z(DOWN_query x DOWN_compound)
    connectivity = mimicry - reversal        (negative = the compound reverses the disease signature)

z is the hypergeometric z-score against the background of genes measured on both sides.
Known senolytics are used as an internal positive control.
"""
import os, sys, json, math, time, gzip, io
import numpy as np
import pandas as pd
import urllib.request, urllib.parse, ssl
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
GS = os.path.join(BASE, "genesets"); os.makedirs(GS, exist_ok=True)
OUT = os.path.join(BASE, "results"); os.makedirs(OUT, exist_ok=True)
CTX = ssl.create_default_context()
UA = {"User-Agent": "Mozilla/5.0"}

LIBS = ["LINCS_L1000_Chem_Pert_up", "LINCS_L1000_Chem_Pert_down",
        "Old_CMAP_up", "Old_CMAP_down",
        "Drug_Perturbations_from_GEO_up", "Drug_Perturbations_from_GEO_down"]

SENOLYTICS = ["quercetin", "dasatinib", "navitoclax", "fisetin", "piperlongumine",
              "abt-737", "abt737", "a-1155463", "curcumin", "resveratrol",
              "metformin", "rapamycin", "nutlin-3", "nutlin", "mk-2206", "mk2206"]


def fetch_library(lib, tries=5):
    """Download an Enrichr library, resuming after truncated reads."""
    cache = os.path.join(GS, lib + ".json")
    if os.path.exists(cache) and os.path.getsize(cache) > 500:
        return json.load(open(cache, encoding="utf8"))
    url = f"https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName={lib}"
    buf = b""
    for a in range(tries):
        try:
            req = urllib.request.Request(url, headers={**UA, "Range": f"bytes={len(buf)}-"})
            with urllib.request.urlopen(req, timeout=300, context=CTX) as r:
                while True:
                    c = r.read(1 << 20)
                    if not c:
                        break
                    buf += c
            break
        except Exception as e:
            print(f"   retry {lib} ({len(buf)/1e6:.1f} MB): {type(e).__name__}")
            time.sleep(3)
    txt = buf.decode("utf8", "ignore")
    d = {}
    for line in txt.split("\n"):
        p = line.split("\t")
        if len(p) >= 3:
            genes = {g.strip().upper() for g in p[2:] if g.strip()}
            if genes:
                d[p[0].strip()] = genes
    json.dump({k: sorted(v) for k, v in d.items()}, open(cache, "w", encoding="utf8"))
    return d


def hyper_z(k, n_query, n_set, n_bg):
    """z-score of an overlap k against the hypergeometric null."""
    if n_bg <= 0 or n_query <= 0 or n_set <= 0:
        return 0.0
    exp = n_query * n_set / n_bg
    var = n_query * (n_set / n_bg) * (1 - n_set / n_bg) * ((n_bg - n_query) / max(n_bg - 1, 1))
    if var <= 0:
        return 0.0
    return (k - exp) / math.sqrt(var)


def normalise_compound(name, library):
    """Reduce a signature label to a compound name."""
    n = name.strip()
    if library == "LINCS L1000":
        # e.g. "LJP006 A375 24H-QL-XII-47-3.33" -> "QL-XII-47"
        tok = n.split()
        if len(tok) >= 3:
            last = tok[-1].split("-")
            if len(last) >= 3:
                return "-".join(last[1:-1])
        return n
    if library == "CMap (Lamb 2006)":
        return n.rsplit("-", 1)[0]
    for marker in (" human", " mouse", " rat"):
        if marker in n:
            return n.split(marker)[0]
    return n


def connectivity(query_up, query_down, lib_up, lib_down, bg, min_genes=30, max_genes=1500):
    """Connectivity score for one compound, plus its component overlaps."""
    qu, qd = query_up & bg, query_down & bg
    rows = []
    for name in set(lib_up) | set(lib_down):
        up = set(lib_up.get(name, ())) & bg
        dn = set(lib_down.get(name, ())) & bg
        if len(up) < min_genes or len(dn) < min_genes:
            continue
        if len(up) > max_genes or len(dn) > max_genes:
            continue
        z_rev = hyper_z(len(qu & dn), len(qu), len(dn), len(bg)) + \
                hyper_z(len(qd & up), len(qd), len(up), len(bg))
        z_mim = hyper_z(len(qu & up), len(qu), len(up), len(bg)) + \
                hyper_z(len(qd & dn), len(qd), len(dn), len(bg))
        rows.append({"compound_raw": name, "score": z_mim - z_rev, "z_reversal": z_rev,
                     "z_mimicry": z_mim, "n_up": len(up), "n_down": len(dn),
                     "overlap_rev": len(qu & dn) + len(qd & up),
                     "overlap_mim": len(qu & up) + len(qd & dn)})
    return pd.DataFrame(rows)


def main():
    print("=" * 96); print("1. reference perturbation libraries")
    libs = {}
    for l in LIBS:
        libs[l] = fetch_library(l)
        print(f"   {l:36s} {len(libs[l]):>6d} signatures  "
              f"({os.path.getsize(os.path.join(GS, l + '.json'))/1e6:.1f} MB)")

    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)
    deg = deg[deg["adj.P.Val"] < 0.05]
    top_up = deg.sort_values("logFC", ascending=False).head(200).index.str.upper()
    top_dn = deg.sort_values("logFC").head(200).index.str.upper()
    up, dn = set(top_up), set(top_dn)
    print(f"\n2. query signature: top {len(up)} up-regulated and {len(dn)} down-regulated genes "
          f"(FDR<0.05, ranked by |log2FC|)")

    # background = genes measured in both the query and the reference libraries
    lib_bg = set().union(*[g for d in libs.values() for g in d.values()])
    bg = (up | dn) | lib_bg
    bg = {g for g in bg if g}
    print(f"   background: {len(bg)} genes")

    all_res = []
    for up_lib, dn_lib, tag in [("LINCS_L1000_Chem_Pert_up", "LINCS_L1000_Chem_Pert_down", "LINCS L1000"),
                                ("Old_CMAP_up", "Old_CMAP_down", "CMap (Lamb 2006)"),
                                ("Drug_Perturbations_from_GEO_up", "Drug_Perturbations_from_GEO_down",
                                 "Drug perturbations from GEO")]:
        raw = connectivity(up, dn, libs[up_lib], libs[dn_lib], bg)
        print(f"\n3. {tag}: {len(raw)} signatures pass the size filter")
        raw["compound"] = [normalise_compound(c, tag) for c in raw["compound_raw"]]
        # aggregate replicates of the same compound: mean score, best (most negative) score
        agg = raw.groupby("compound").agg(
            score=("score", "mean"), score_best=("score", "min"), n_sig=("score", "size"),
            z_reversal=("z_reversal", "mean"), overlap_rev=("overlap_rev", "mean"),
            overlap_mim=("overlap_mim", "mean")).reset_index()
        agg["library"] = tag
        # empirical two-sided p from the null of all compounds in this library
        agg["p"] = stats.norm.sf(-agg["score"] / max(agg["score"].std(), 1e-9)) * 2
        agg = agg.sort_values("score")
        all_res.append(agg)
        print(f"   {len(agg)} distinct compounds after aggregation")
        print("   top reversers:")
        for _, x in agg.head(12).iterrows():
            print(f"      {x['score']:7.2f}  {x['compound'][:52]:52s} n={int(x['n_sig']):>3d} "
                  f"rev={x['overlap_rev']:5.1f} mim={x['overlap_mim']:5.1f}")
        hits = agg[agg["compound"].str.lower().str.contains("|".join(SENOLYTICS), regex=True)]
        print(f"   positive control — known senolytic/senomorphic compounds: {len(hits)}")
        for _, x in hits.head(6).iterrows():
            pct = (1 - (agg["score"] <= x["score"]).sum() / len(agg)) * 100
            print(f"      {x['compound'][:44]:44s} score={x['score']:7.2f}  "
                  f"{pct:.0f}th percentile of {len(agg)}")

    res = pd.concat(all_res, ignore_index=True)
    res.to_csv(os.path.join(OUT, "cmap_connectivity.csv"), index=False)
    json.dump({"query_up": len(up), "query_down": len(dn), "background": len(bg),
               "libraries": {l: len(libs[l]) for l in LIBS}},
              open(os.path.join(OUT, "cmap_meta.json"), "w"), indent=1)
    print(f"\nwrote cmap_connectivity.csv ({len(res)} compound scores)")


if __name__ == "__main__":
    main()
