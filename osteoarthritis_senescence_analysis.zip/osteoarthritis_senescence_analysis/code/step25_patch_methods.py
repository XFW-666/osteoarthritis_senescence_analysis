"""Patch manuscript_text.py: methods for the new analyses, and abstract/conclusion updates."""

def patch(path, edits):
    src = open(path, encoding="utf-8").read()
    for label, old, new in edits:
        if src.count(old) != 1:
            raise SystemExit(f"anchor problem ({src.count(old)}x) for {label}")
        src = src.replace(old, new, 1)
        print("  ok ", label)
    open(path, "w", encoding="utf-8").write(src)


COHORTS_OLD = '''         "non-OA joint tissue. Two single-cell RNA-sequencing atlases were used for cellular localisation: "
         "GSE104782 (10x Genomics, human knee articular cartilage from 10 patients with OA) and GSE255460 "
         "(10x Genomics, human knee cartilage from nine donors, eight with OA and one without, 135,896 "
         "cells). Genetic instruments and disease outcomes were drawn from eQTLGen and FinnGen release 11, "
         "as described below."),'''

COHORTS_NEW = '''         "non-OA joint tissue. Two single-cell RNA-sequencing atlases were used for cellular localisation: "
         "GSE104782 (10x Genomics, human knee articular cartilage from 10 patients with OA) and GSE255460 "
         "(10x Genomics, human knee cartilage from nine donors, eight with OA and one without, 135,896 "
         "cells). Independent replication used GSE57218 (Illumina HumanHT-12 V3; healthy, macroscopically "
         "osteoarthritic and macroscopically preserved cartilage from osteoarthritic joints), and the "
         "epigenetic layer used two cartilage methylation cohorts, GSE43269 (HumanMethylation27) and "
         "GSE73626 (HumanMethylation450). Genetic instruments and disease outcomes were drawn from eQTLGen "
         "and FinnGen release 11, as described below."),'''

NEW_METHODS = '''    ("Independent replication, disease specificity and orthogonal layers", [
        ("To test whether the decoupled pattern is cohort-specific, the differential expression analysis "
         "was repeated from scratch in GSE57218 (Illumina HumanHT-12 V3), an independent cartilage cohort "
         "containing healthy, macroscopically osteoarthritic and macroscopically preserved cartilage from "
         "osteoarthritic joints. Probes were mapped to gene symbols with the GPL6947 annotation, arrays "
         "were quantile-normalised, and the same empirical-Bayes moderated t-statistic was applied. "
         "Concordance of each programme arm with the discovery cohort was tested with a one-sided sign "
         "test, and the frozen signature was applied as in the other external cohorts."),
        ("Disease specificity was examined in GSE55235, which contains ten rheumatoid-arthritis samples in "
         "addition to its osteoarthritic and normal arms. The frozen signature and the senescence-programme "
         "score were evaluated for osteoarthritis versus normal tissue, osteoarthritis versus rheumatoid "
         "arthritis, and rheumatoid arthritis versus normal tissue, with bootstrap confidence intervals."),
        ("The epigenetic layer was examined in two independent human cartilage methylation cohorts, "
         "GSE43269 (Illumina HumanMethylation27) and GSE73626 (HumanMethylation450). CpGs were mapped to "
         "genes from the corresponding Illumina manifests; for the 450K array only promoter CpGs (TSS1500, "
         "TSS200, first exon or 5' untranslated region) were used, whereas the 27K array is "
         "promoter-centred by design. Each gene was summarised by the mean methylation of its CpGs, and "
         "osteoarthritic and normal samples were compared with the Mann-Whitney U test and "
         "Benjamini-Hochberg adjustment. The senescence universe was tested as a set by averaging the "
         "per-gene means."),
        ("Finally, the signature was instrumented as a single composite exposure. Because the score is a "
         "coefficient-weighted sum of the eight genes, a variant's effect on the score is the "
         "coefficient-weighted sum of its effects on whichever signature genes it instruments, and the "
         "composite effect was estimated from the harmonised instrument table by inverse-variance "
         "weighting. This pools instruments across loci and yields one test per phenotype rather than "
         "eight. Stability was assessed by dropping each gene in turn."),
    ]),
'''

ABSTRACT_METHODS_OLD = '''    "Methods": (
        "Five public human knee cohorts were analysed: discovery in cartilage RNA-sequencing (GSE114007; "
        "20 OA, 18 normal) and validation in one cartilage microarray and three synovial cohorts. "
        "Senescence genes were the union of curated Reactome, KEGG and Gene Ontology senescence and SASP "
        "sets. Differential expression, co-expression, interaction-network, enrichment, ssGSEA and "
        "three-algorithm feature selection were performed, and fourteen classifiers were benchmarked under "
        "nested cross-validation with selection repeated inside every fold. The signature was validated in "
        "every external cohort, localised in two single-cell cohorts (1,600 and 135,896 cells), tested for "
        "causal effect by Mendelian randomisation with eQTLGen cis-eQTLs against four FinnGen phenotypes "
        "including formal colocalisation, and screened for reversing compounds by connectivity mapping."),'''

ABSTRACT_METHODS_NEW = '''    "Methods": (
        "Public human knee cohorts were analysed: discovery in cartilage RNA-sequencing (GSE114007; 20 OA, "
        "18 normal), validation in one cartilage microarray and three synovial cohorts, independent "
        "re-discovery in a further cartilage cohort, and the epigenetic layer in two cartilage methylation "
        "cohorts. Senescence genes were the union of curated Reactome, KEGG and Gene Ontology senescence "
        "and SASP sets. Differential expression, co-expression, interaction-network, enrichment, ssGSEA and "
        "three-algorithm feature selection were performed, and fourteen classifiers were benchmarked under "
        "nested cross-validation with selection repeated inside every fold. The signature was validated in "
        "every external cohort, localised in two single-cell cohorts (1,600 and 135,896 cells), tested for "
        "causal effect by Mendelian randomisation with eQTLGen cis-eQTLs against four FinnGen phenotypes "
        "including formal colocalisation and a composite-exposure analysis, and screened for reversing "
        "compounds by connectivity mapping."),'''

ABSTRACT_RESULTS_OLD = '''        "reversers. Mendelian randomisation gave 32 strong-instrument estimates; one survived "
        "false-discovery correction (CDKN1A and knee-replacement surgery, odds ratio 1.17, FDR = 0.035), "
        "but no locus colocalised (maximum PP.H4 = 0.015), so a causal interpretation is not supported."),'''

ABSTRACT_RESULTS_NEW = '''        "reversers. Both programme arms reproduced in an independent cartilage cohort on a different "
        "platform, but the signature tracked joint rather than local lesion status and also separated "
        "rheumatoid arthritis from normal synovium, and its loss was not accompanied by promoter "
        "hypermethylation in two methylation cohorts. Mendelian randomisation gave 32 strong-instrument "
        "estimates; one survived false-discovery correction (CDKN1A and knee-replacement surgery, odds "
        "ratio 1.17, FDR = 0.035), but no locus colocalised (maximum PP.H4 = 0.015), and instrumenting "
        "the signature as a composite exposure gave a well-powered null (smallest detectable odds ratio "
        "about 1.04), so a causal interpretation is not supported."),'''

CONCL_OLD = '''     "platforms. Two independent single-cell atlases localised the signature to homeostatic chondrocytes, "
     "and drug-repurposing analysis nominated luteolin, alvocidib, curcumin and quercetin as candidate "'''

CONCL_NEW = '''     "platforms. Two independent single-cell atlases localised the signature to homeostatic chondrocytes, "
     "and drug-repurposing analysis nominated luteolin, alvocidib, curcumin and quercetin as candidate "'''

patch("manuscript_text.py", [
    ("cohort list", COHORTS_OLD, COHORTS_NEW),
    ("new methods subsection",
     '    ("Diagnostics of the cohort that did not validate", [',
     NEW_METHODS + '    ("Diagnostics of the cohort that did not validate", ['),
    ("abstract methods", ABSTRACT_METHODS_OLD, ABSTRACT_METHODS_NEW),
    ("abstract results", ABSTRACT_RESULTS_OLD, ABSTRACT_RESULTS_NEW),
])

# acknowledgements + data availability
src = open("manuscript_text.py", encoding="utf-8").read()
print("  (statements live in manuscript_text2.py)")
print("DONE manuscript_text.py")
