"""
manuscript_text.py — full text of the manuscript.  Citation numbers refer to
refs_build.CITATION_ORDER (all references are real PubMed records).
"""

TITLE = ("Loss of the senescence-checkpoint programme with compensatory cell-cycle re-entry "
         "in knee osteoarthritis: an integrated multi-cohort transcriptomic, machine-learning "
         "and single-cell analysis")

RUNNING_HEAD = "Senescence-checkpoint loss in knee osteoarthritis"

KEYWORDS = ["osteoarthritis", "cellular senescence", "senescence-associated secretory phenotype",
            "CDKN1A", "machine learning", "single-cell RNA sequencing", "diagnostic biomarker",
            "transcriptomics"]

AUTHORS = ("Jing Shi, MD; Haiyan Xue, MD; Hao Gu, MD; Yangjie Li, MD; "
           "Chun Zhang, MD; Fangwei Xue, MD, PhD")
AFFILIATIONS = (
    "1 Department of Joint and Sports Medicine, Yunnan Qujing Central Hospital, Qujing, China; "
    "2 Trauma Center, First Affiliated Hospital of Kunming Medical University, Kunming, China; "
    "3 Department of Orthopaedic Trauma, Yunnan Qujing Central Hospital, Qujing, China; "
    "4 Department of Foot and Ankle Surgery, Yunnan Qujing Central Hospital, Qujing, China; "
    "5 School of Clinical and Basic Medical Sciences, Shandong First Medical University, "
    "Jinan, China")

ABSTRACT = {
    "Background": (
        "Osteoarthritis is a leading cause of disability and no disease-modifying therapy exists. The "
        "architecture of the senescence programme in end-stage human osteoarthritis cartilage, and its "
        "transferability across tissues and platforms, remain undefined."),
    "Methods": (
        "Public human knee cohorts were analysed: discovery in cartilage RNA-sequencing (GSE114007; 20 OA, "
        "18 normal), validation in one cartilage microarray and three synovial cohorts, independent "
        "re-discovery in a further cartilage cohort, and two cartilage methylation cohorts. Senescence "
        "genes were the union of curated Reactome, KEGG and Gene Ontology senescence and SASP sets. "
        "Differential expression, co-expression, interaction-network, enrichment, ssGSEA and "
        "three-algorithm feature selection were performed, and fourteen classifiers were benchmarked under "
        "nested cross-validation. The signature was validated in every external cohort, localised in two "
        "single-cell cohorts, tested by Mendelian randomisation with eQTLGen cis-eQTLs against four "
        "FinnGen phenotypes including colocalisation, and screened for reversing compounds by "
        "connectivity mapping."),
    "Results": (
        "Sixty senescence genes were differentially expressed in OA cartilage and the 24 stringent ones "
        "were enriched for cellular senescence, the SASP and G1/S cell-cycle control. The p53/p21-GADD45 "
        "checkpoint and AP-1 arms were suppressed (JUN -3.06, CDKN1A -3.00) while cell-cycle re-entry "
        "(CCND1 +2.03) and IGFBP3 (+3.29) were induced, indicating a decoupled programme. The eight-gene "
        "signature (ETS2, GADD45B, JUN, CDKN1B, UBC, CDKN1A, HLA-F, CDK2) reached an area under the curve "
        "of 1.000 under nested cross-validation and retained discrimination in three of four external "
        "cohorts (0.967 to 1.000). It localised to homeostatic chondrocytes in both single-cell atlases, "
        "and both programme arms reproduced in an independent cartilage cohort, where it tracked joint "
        "rather than lesion status and showed no promoter hypermethylation. Connectivity mapping "
        "recovered known senolytics. Mendelian randomisation gave 32 strong-instrument estimates, one "
        "surviving false-discovery correction (CDKN1A and knee-replacement surgery, odds ratio 1.17, "
        "FDR = .035), but no locus colocalised and a composite-exposure analysis was a well-powered "
        "null."),
    "Conclusion": (
        "End-stage knee OA cartilage shows a decoupled senescence phenotype, with loss of checkpoint and "
        "AP-1 control alongside cell-cycle re-entry and SASP output. The eight-gene signature is a robust "
        "cartilage-derived marker of that state rather than a causal driver, and nominates cell-cycle and "
        "senotherapeutic targets."),
}


KEY_POINTS = [
    "End-stage human knee OA cartilage shows a decoupled senescence phenotype, with loss of the p53/p21-GADD45 checkpoint and AP-1 stress-response arms alongside induced cell-cycle re-entry and SASP output.",
    "A three-algorithm consensus signature (ETS2, GADD45B, JUN, CDKN1B, UBC, CDKN1A, HLA-F, CDK2) discriminated OA from normal cartilage with an AUC of 1.000 under nested cross-validation, reproduced with feature selection nested inside every fold.",
    "Discrimination was retained in three of four independent external cohorts across two tissues and two platforms (AUC 0.967-1.000), but not in the imbalanced synovial RNA-sequencing cohort.",
    "The signature localised to homeostatic chondrocytes in two independent single-cell cohorts, including a donor-controlled comparison across 11 annotated populations in 134,551 cells.",
    "Mendelian randomisation with eQTLGen cis-eQTLs and FinnGen outcomes yielded one FDR-significant estimate, but colocalisation showed that no locus shares a causal variant, so the signature is a marker rather than a cause of OA.",
]

INTRODUCTION = [
        ("Osteoarthritis (OA) is the most prevalent degenerative joint disease worldwide and a leading contributor to years lived with disability, with an estimated 595 million people affected globally and projections indicating a continued rise as populations age and obesity becomes more common.[1-5] The knee is the most frequently affected joint, and knee OA carries a substantial and growing economic burden through analgesic use, outpatient care and total joint arthroplasty.[4, 9] Established risk factors include advancing age, female sex, obesity and metabolic dysfunction, previous joint injury, and occupational mechanical loading,[6-8] yet contemporary management remains largely symptomatic: exercise, weight management, analgesia and, ultimately, arthroplasty.[10-12] No disease-modifying OA drug has been approved, in large part because the molecular heterogeneity of the disease has not been translated into tractable therapeutic or diagnostic targets.[1, 2, 13, 14]"),

    ("Ageing is the dominant risk factor for OA, and cellular senescence has emerged as a central mechanism "
     "linking joint ageing to structural degeneration.[15-18] Senescent cells accumulate in articular cartilage "
     "with age and after joint injury, withdraw irreversibly from the cell cycle through the p53-p21 and "
     "p16INK4a-RB axes, and adopt a senescence-associated secretory phenotype (SASP) that releases "
     "interleukin-6, CXCL8, matrix metalloproteinases and growth factors into the joint "
     "microenvironment.[19-22] This secretome propagates senescence to neighbouring chondrocytes, recruits "
     "immune cells, and shifts matrix turnover towards catabolism, creating a self-amplifying loop that "
     "underlies progressive cartilage loss.[17, 23-29] Consistent with this model, genetic or pharmacological "
     "removal of senescent cells reduces cartilage degeneration in experimental models, and senescence "
     "markers correlate with disease severity in human tissue.[17, 26, 27]"),

    ("OA is now recognised as an inflammatory disease of the whole joint rather than a purely mechanical "
     "problem of cartilage wear.[30-34] Synovial inflammation, macrophage infiltration and innate immune "
     "exhaustion associate with pain and radiographic progression, and fibroblast subsets remodel the local "
     "immune niche.[33, 35, 36] Matrix degradation is executed by aggrecanases and matrix "
     "metalloproteinases,[37, 38] while soluble mediators such as insulin-like growth factor binding protein 3 "
     "(IGFBP3) have been repeatedly implicated in cartilage homeostasis and OA susceptibility.[39, 40] "
     "Senescence is likewise not restricted to cartilage: it drives degeneration of the intervertebral disc "
     "and facet joints, and senolytic compounds such as the dasatinib-quercetin combination and quercetin "
     "alone attenuate degeneration across musculoskeletal tissues.[41-46] Together, these observations make "
     "the senescence programme an attractive axis for molecular stratification in orthopaedic practice."),

    ("Transcriptomic profiling has been used to define molecular subtypes of OA cartilage and to nominate "
     "candidate biomarkers, and machine-learning approaches have been applied to gene-expression data in "
     "many degenerative and inflammatory diseases.[47-54] Marker discovery by integrated bioinformatics and "
     "machine learning has become routine in degenerative and immune-mediated disease, and explainability "
     "methods such as SHAP are now expected when models are intended to inform clinical "
     "reasoning.[67-69] Nevertheless, the great majority of such studies derive and test their markers "
     "within a single cohort.[72] Three limitations therefore recur in this literature. First, most studies "
     "derive and evaluate their markers within a single cohort, so that "
     "apparent accuracy may reflect cohort-specific rather than disease-specific signal. Second, validation "
     "across joint tissues and across expression platforms is rarely reported, even though cartilage and "
     "synovium are both clinically relevant and are assayed on different platforms in routine practice. "
     "Third, the senescence literature in OA has largely been framed as a simple increase in senescence "
     "burden, without asking whether all arms of the programme move in the same direction. We therefore "
     "designed an integrated multi-cohort study with three objectives: (i) to characterise the senescence "
     "programme in end-stage human knee OA cartilage at the level of individual transcriptional arms; "
     "(ii) to derive and rigorously benchmark a senescence-based diagnostic signature, including "
     "feature selection nested inside cross-validation and testing in independent cohorts across two tissues "
     "and two platforms; and (iii) to localise the signature to specific chondrocyte subpopulations using "
     "single-cell RNA sequencing, and to nominate candidate senescence-directed therapeutics. The "
     "conceptual framework, the senescence-SASP cycle and the analysis workflow are summarised in "
     "Figure 1."),
]

METHODS = [
    ("Data sources and cohorts", [
        ("This study used only de-identified, publicly available human data and therefore required no ethics "
         "approval or informed consent. Five bulk transcriptomic cohorts of human knee joint tissue and two "
         "single-cell cohorts were obtained from the Gene Expression Omnibus (GEO). Cohort composition, tissue, "
         "platform and analytic role are summarised in Table 1."
         "The discovery cohort was GSE114007: submitter-normalised RNA-sequencing of human knee articular cartilage from 20 patients with end-stage OA (Kellgren-Lawrence grade 4) and 18 with morphologically normal cartilage (grade 1).[70] Cartilage microarray data from GSE169077 (6 OA, 5 normal pools) provided same-tissue validation, and three synovial cohorts provided cross-tissue validation: GSE283079 (RNA-sequencing; 36 OA, 5 non-OA), GSE55235 and GSE55457 (Affymetrix HG-U133A; 10 OA and 10 normal each). Samples annotated as rheumatoid arthritis or other inflammatory arthritides were excluded, so every comparison was OA versus non-OA joint tissue. Cellular localisation used two single-cell atlases (GSE104782 and GSE255460), independent replication used GSE57218, and the methylation analysis used GSE43269 and GSE73626. Genetic instruments and disease outcomes came from eQTLGen and FinnGen release 11."),
    ]),
    ("Preprocessing and quality control", [
        ("RNA-sequencing matrices were analysed on the log2 scale: GSE114007 was provided by the submitters as "
         "normalised log2 expression and was used as supplied, while GSE283079 raw counts were converted to "
         "log2 counts per million. For microarray cohorts, probe-level intensities were log2-transformed where "
         "the scale was linear, quantile-normalised across arrays, and collapsed to gene symbols by retaining "
         "the probe with the highest mean intensity for each symbol. Platform annotation for the Affymetrix "
         "HG-U133A arrays was obtained from the corresponding GEO platform record; annotation covered 21,733 "
         "of 22,283 probe sets, and unmapped probes were discarded. Genes were retained for differential "
         "expression analysis if they were detected above the background threshold in at least half of the "
         "samples, leaving 12,873 genes."),
    ]),
    ("Differential expression analysis", [
        ("Differential expression between OA and normal samples in the discovery cohort was assessed with "
         "empirical-Bayes moderated t-statistics, implemented to reproduce the limma workflow: a per-gene "
         "linear model was fitted, gene-wise residual variances were shrunk towards a common prior estimated "
         "by moment matching of a scaled F-distribution, and the resulting moderated t-statistics were "
         "converted to two-sided P values. The prior degrees of freedom estimated from the data were 3.4. "
         "P values were adjusted for multiple testing with the Benjamini-Hochberg procedure, and genes were "
         "declared differentially expressed at a false-discovery rate (FDR) below 0.05; a stringent subset "
         "additionally required |log2 fold change| > 1."),
    ]),
    ("Senescence gene sets and functional enrichment", [
        ("A senescence gene universe was assembled from curated, publicly maintained gene-set libraries "
         "accessed through Enrichr. The union comprised the Reactome terms Cellular Senescence "
         "(R-HSA-2559583), Senescence-Associated Secretory Phenotype (R-HSA-2559582), DNA Damage/Telomere "
         "Stress Induced Senescence, Oxidative Stress Induced Senescence, Oncogene Induced Senescence and "
         "Formation of Senescence-Associated Heterochromatin Foci; the KEGG pathway Cellular Senescence; and "
         "the Gene Ontology biological-process terms Stress-Induced Premature Senescence, Regulation of "
         "Cellular Senescence, Positive Regulation of Cellular Senescence and Negative Regulation of Cellular "
         "Senescence. This yielded 314 unique senescence-related genes (Table S1). Senescence-related "
         "differentially expressed genes (SRDEGs) were defined as the intersection of this universe with the "
         "differentially expressed gene set."),
        ("Over-representation analysis of the SRDEGs was performed against eight libraries (Gene Ontology "
         "biological process 2023, KEGG 2021 human, Reactome 2022, WikiPathway 2023 human, MSigDB hallmark "
         "2020, DisGeNET, Jensen DISEASES and the Human Phenotype Ontology) using the Enrichr "
         "application-programming interface; enrichment P values are reported as returned by Enrichr, with "
         "Benjamini-Hochberg adjustment within each library.[58]"),
    ]),
    ("Weighted co-expression network and module detection", [
        ("A weighted gene co-expression analysis was performed on the 4,000 most variable genes, following "
         "the WGCNA framework.[55, 56] Pairwise Pearson correlations were raised to a soft-thresholding power "
         "to build a weighted adjacency matrix; the power was chosen from the scale-free topology fit index, "
         "floored at 14, the value recommended for cohorts of approximately 40 samples, which kept the network "
         "in the sparse regime. Gene modules were identified by average-linkage hierarchical clustering of the "
         "signed co-expression dissimilarity (1 - r) with a fixed dendrogram cut height of 0.40, modules with "
         "highly correlated eigengenes (r > .80) were merged, and modules containing fewer than 30 genes were "
         "left unassigned. Each module was summarised by its eigengene, the first principal component of the "
         "module's expression matrix, which was correlated with disease status by Pearson correlation."),
    ]),
    ("Protein-protein interaction network and hub prioritisation", [
        ("Protein-protein interactions among candidate genes were retrieved from STRING version 12 with a "
         "minimum combined confidence score of 400.[57] The resulting network was analysed with NetworkX. Four "
         "topological metrics were computed: degree, betweenness centrality, closeness centrality, and maximal "
         "clique centrality (MCC), the latter following the cytoHubba definition in which the MCC of a node is "
         "the sum of the squared sizes of the maximal cliques it belongs to. Genes were ranked by the sum of "
         "their ranks across the four metrics, and the highest-ranked genes were designated hub genes."),
    ]),
    ("Single-sample gene-set enrichment and cell-type deconvolution", [
        ("Single-sample gene-set enrichment analysis (ssGSEA) was used to score pathway and cell-type "
         "programmes in each sample, following the gene-set enrichment framework of Subramanian and "
         "colleagues.[61, 82] Briefly, genes were ranked by expression within each sample and an "
         "enrichment score was computed as the difference between the weighted empirical cumulative "
         "distribution functions of the gene set and its complement, with a weighting exponent of 0.25. "
         "Cell-type scores were computed with a curated panel of 19 immune and stromal populations, using "
         "marker gene sets taken from CellMarker 2024 (tissue-agnostic human terms) and PanglaoDB. Hallmark "
         "pathway activity was scored with ten MSigDB hallmark sets together with the curated senescence "
         "universe. Group comparisons used the Mann-Whitney U test with Benjamini-Hochberg adjustment, and "
         "rank-biserial correlation was reported as the effect size."),
    ]),
    ("Feature selection and machine-learning modelling", [
        ("Three complementary feature-selection algorithms were applied to the candidate pool, defined as all "
         "senescence-universe genes with FDR < .05 together with the top 15 protein-protein interaction hubs "
         "(60 genes in total). LASSO logistic regression with L1 penalty was fitted to 200 bootstrap "
         "resamples, and the selection frequency of each gene was recorded. Linear support-vector-machine "
         "recursive feature elimination was used to retain 12 features. Random-forest Gini importance was "
         "averaged over 200 bootstrap resamples and the top 12 genes retained. A gene was admitted to the "
         "consensus signature if it was selected by at least two of the three algorithms, and the eight "
         "highest-scoring genes formed the final signature."),
        ("Fourteen classifiers were benchmarked under nested cross-validation: an inner grid search with "
         "5-fold cross-validation selected hyperparameters by area under the receiver-operating "
         "characteristic curve (AUC), and an outer 5-fold stratified split repeated five times produced "
         "out-of-fold predictions that were averaged across repeats before performance was computed. The "
         "classifiers were logistic regression with L2, L1 (LASSO), L2 (ridge) and elastic-net penalties, "
         "linear and radial-basis-function support vector machines, random forest, extremely randomised trees, "
         "gradient boosting, XGBoost, LightGBM, k-nearest neighbours, Gaussian naive Bayes and a multilayer "
         "perceptron. Reported metrics were AUC with 95% bootstrap confidence intervals (2,000 resamples), "
         "area under the precision-recall curve, accuracy, sensitivity, specificity, positive and negative "
         "predictive values, F1 score, Matthews correlation coefficient and the Brier score."
         "Because feature selection on the complete discovery cohort can inflate apparent accuracy, two "
         "additional analyses were performed. In the first, LASSO selection was repeated inside every training "
         "fold, so that the reported AUC involved no selection on the test data. In the second, the candidate "
         "pool was widened to all 274 senescence-universe genes detected in the discovery matrix, removing the "
         "full-cohort differential-expression pre-filter."),
        ("The final signature was interpreted with SHapley Additive exPlanations (SHAP) values computed for "
         "an XGBoost model fitted to the signature, providing both global feature attribution and per-sample "
         "explanations. A logistic regression model on the signature was used to construct a nomogram "
         "assigning 0-100 points to each gene in proportion to its contribution, and decision-curve analysis "
         "was used to quantify net benefit across threshold probabilities.[59]"),
    ]),
    ("External validation", [
        ("The signature was frozen after derivation and applied unchanged to each external cohort. Because "
         "cohorts differ in platform and tissue, expression values were standardised within each cohort "
         "before the frozen model was applied, and the tissue-level senescence-programme ssGSEA score was "
         "evaluated as a platform-agnostic comparator. For each cohort we report the AUC of the multi-gene "
         "panel, the AUC of the senescence-programme score, and the proportion of signature genes whose "
         "direction of change matched that observed in the discovery cohort. Single-gene AUCs were also "
         "computed to document which components transferred across tissues."),
    ]),
    ("Single-cell analysis", [
        ("Two single-cell cohorts were analysed to localise the signature. Counts were library-size normalised and log1p-transformed, and a signature score was computed per cell as the mean z-scored expression of the eight genes. In GSE104782 cells were grouped by the supplied subpopulation labels and compared with the Mann-Whitney U test. GSE255460 supplied 135,896 cells with eleven annotated populations and a normal control arm; because cells from one donor are not independent, every population comparison there was made on per-donor means paired across donors with the Wilcoxon signed-rank test and Benjamini-Hochberg adjustment, with Cliff's delta as the effect size. Its control arm contains a single donor, so control-versus-OA contrasts are reported descriptively and not as tests. The supplied labels were checked against canonical marker genes by the area under the curve of each marker within versus outside its labelled population."),
    ]),
    ("Therapeutic and regulatory inference", [
        ("Candidate compounds were nominated by over-representation analysis of the signature genes against drug-perturbation libraries, consistent with connectivity-map style repurposing.[60] Upstream transcriptional regulators were inferred from the ChEA 2022 and TRRUST libraries; both analyses are hypothesis-generating and reported as such."
         "Because over-representation tests only ask whether signature genes are enriched among a compound's targets, they cannot establish whether a compound reverses the disease programme, so we added a connectivity-map analysis proper.[80, 81] The query signature was the 200 most up-regulated and 200 most down-regulated genes in OA cartilage (FDR < .05, ranked by log2 fold change), and three reference collections were scored: LINCS L1000, the original Connectivity Map and drug perturbations from GEO. For each reference the reversal term was z(UP_query x DOWN_reference) + z(DOWN_query x UP_reference) and the mimicry term z(UP_query x UP_reference) + z(DOWN_query x DOWN_reference), where z is the hypergeometric z-score against 28,816 background genes; the connectivity score is mimicry minus reversal, so negative values indicate reversal. References were restricted to at least 30 genes in each direction, replicates were averaged per compound, and known senolytics and senomorphics served as an internal positive control."),
    ]),
    ("Mendelian randomisation and colocalisation", [
        ("To ask whether the signature genes are causally related to osteoarthritis rather than merely associated with it, we performed two-sample Mendelian randomisation using cis-expression quantitative trait loci as instruments.[76-79] Instruments were drawn from eQTLGen,[84] a meta-analysis of whole-blood cis-eQTLs in up to 31,684 individuals reporting standardised Z-scores. Z-scores were converted to per-allele effects on the standardised expression scale as b = z / sqrt(2 f (1 - f) n), so that the standard error is 1 / sqrt(2 f (1 - f) n) and the instrument F statistic is the squared Z-score. Instruments were restricted to P < 5 x 10^-8 and clumped to one variant per 250 kb."),
        ("Outcome data were the FinnGen release 11 genome-wide association summary statistics for four "
         "osteoarthritis phenotypes: arthrosis at all sites, gonarthrosis, coxarthrosis, and gonarthrosis "
         "requiring knee surgery.[74, 75] Each file is approximately 820 MB, so only the gene loci were "
         "retrieved, using the accompanying tabix index over HTTP range requests. Because eQTLGen is "
         "positioned on GRCh37 and FinnGen R11 on GRCh38, instruments and outcomes were harmonised on "
         "variant identifier rather than on genomic position, and the outcome effect was sign-flipped when "
         "the reference and alternate alleles were swapped. Causal estimates were the Wald ratio for a "
         "single instrument and the inverse-variance weighted estimate for several, with MR-Egger and "
         "weighted-median estimators and Cochran's Q as sensitivity analyses where three or more instruments "
         "were available. Estimates are reported as odds ratios per one standard deviation of genetically "
         "predicted expression, with Benjamini-Hochberg control across all gene-outcome tests, and the "
         "smallest odds ratio each design could detect at 80% power is reported alongside. In a sensitivity "
         "analysis, the same outcomes were also instrumented with GTEx version 8 single-tissue cis-eQTLs "
         "using the tissue with the strongest signal for each gene.[73]"),
        ("Because a Mendelian randomisation signal within a locus that also carries a genome-wide "
         "association signal can arise from linkage rather than from a shared causal variant, we performed "
         "formal colocalisation for every gene-phenotype pair with the approximate Bayes factor procedure of "
         "coloc.[85] Single-variant approximate Bayes factors were computed for the expression and outcome "
         "traits under the five standard hypotheses (no association; expression only; outcome only; both, "
         "distinct causal variants; both, shared causal variant), using a quantitative-trait prior variance "
         "of 0.15 squared for expression, a case-control prior variance of 0.2 squared for the outcome, and "
         "default prior probabilities of 1e-4 for association with either trait and 1e-5 for a shared "
         "variant. Posterior probabilities are reported for every hypothesis, and the probability of a "
         "shared causal variant (PP.H4) is interpreted against the conventional 0.8 threshold."
         "A tissue-matched instrument set would have been preferable to blood, but the human cartilage "
         "molecular quantitative trait locus map of Steinberg and colleagues[48] is deposited under "
         "controlled access at the European Genome-phenome Archive, and the data-access agreements required "
         "to use genotype-level data could not be completed within this study. Whole-blood cis-eQTLs were "
         "therefore used as instruments, and this substitution is a limitation of the causal analysis "
         "rather than a design choice."),
    ]),
    ("Independent replication, disease specificity and orthogonal layers", [
        ("To test whether the decoupled pattern is cohort-specific, the differential expression analysis "
         "was repeated from scratch in GSE57218 (Illumina HumanHT-12 V3), an independent cartilage cohort "
         "containing healthy, macroscopically osteoarthritic and macroscopically preserved cartilage from "
         "osteoarthritic joints. Probes were mapped to gene symbols with the GPL6947 annotation, arrays "
         "were quantile-normalised, and the same empirical-Bayes moderated t-statistic was applied. "
         "Concordance of each programme arm with the discovery cohort was tested with a one-sided sign "
         "test, and the frozen signature was applied as in the other external cohorts."),
        ("Disease specificity was examined in GSE55235, which contains ten rheumatoid-arthritis samples in "
         "addition to its osteoarthritic and normal arms. The frozen signature and the senescence-programme "
         "score were evaluated for osteoarthritis versus normal tissue, osteoarthritis versus rheumatoid "
         "arthritis, and rheumatoid arthritis versus normal tissue, with bootstrap confidence intervals."
         "The epigenetic layer was examined in two independent human cartilage methylation cohorts, "
         "GSE43269 (Illumina HumanMethylation27) and GSE73626 (HumanMethylation450). CpGs were mapped to "
         "genes from the corresponding Illumina manifests; for the 450K array only promoter CpGs (TSS1500, "
         "TSS200, first exon or 5' untranslated region) were used, whereas the 27K array is "
         "promoter-centred by design. Each gene was summarised by the mean methylation of its CpGs, and "
         "osteoarthritic and normal samples were compared with the Mann-Whitney U test and "
         "Benjamini-Hochberg adjustment. The senescence universe was tested as a set by averaging the "
         "per-gene means."
         "Finally, the signature was instrumented as a single composite exposure. Because the score is a "
         "coefficient-weighted sum of the eight genes, a variant's effect on the score is the "
         "coefficient-weighted sum of its effects on whichever signature genes it instruments, and the "
         "composite effect was estimated from the harmonised instrument table by inverse-variance "
         "weighting. This pools instruments across loci and yields one test per phenotype rather than "
         "eight. Stability was assessed by dropping each gene in turn."),
    ]),
    ("Diagnostics of the cohort that did not validate", [
        ("Because a single non-validating cohort is easily over-interpreted, we quantified what that cohort "
         "could have detected. The observed area under the curve was compared with its null distribution "
         "under 20,000 random permutations of the case-control labels, and the standard error of the area "
         "was obtained from the Hanley-McNeil expression[83] to derive the smallest area the cohort could "
         "detect at 80% power with two-sided 5% significance. The direction of change of each signature gene "
         "was compared between the discovery cohort and the validation cohort, and the deposited sample "
         "annotations were read directly from GEO to confirm that the case-control split was supported by "
         "the metadata rather than only by the column names of the supplementary file."),
    ]),
    ("Statistical analysis and reporting", [
        ("Analyses were performed in Python 3.12 with NumPy, pandas, SciPy, scikit-learn, XGBoost, LightGBM, "
         "SHAP, NetworkX and Matplotlib. Continuous variables were compared with the Mann-Whitney U test, "
         "categorical variables with the chi-square or Fisher exact test, and correlations with the Pearson "
         "coefficient. Two-sided P values below 0.05 were considered significant, with Benjamini-Hochberg "
         "adjustment for multiplicity where stated. Random seeds were fixed for all stochastic procedures. "
         "The study is reported in accordance with the STROBE recommendations for observational research, and "
         "the analysis code and derived data tables are provided as supplementary material."),
    ]),
]
