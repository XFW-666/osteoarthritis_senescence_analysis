import os, subprocess

OUT = "data/extra"
os.makedirs(OUT, exist_ok=True)
FILES = {
    "GPL8490_family.soft.gz": "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL8nnn/GPL8490/soft/GPL8490_family.soft.gz",
    "GPL13534_family.soft.gz": "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL13nnn/GPL13534/soft/GPL13534_family.soft.gz",
    "GPL6947.annot.gz": "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL6nnn/GPL6947/annot/GPL6947.annot.gz",
    "GPL20844_family.soft.gz": "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL20nnn/GPL20844/soft/GPL20844_family.soft.gz",
}


def head_size(url):
    p = subprocess.run(["curl", "-sSI", "-m", "40", url], capture_output=True, text=True)
    for line in p.stdout.splitlines():
        if line.lower().startswith("content-length:"):
            return int(line.split(":")[1].strip())
    return None


for name, url in FILES.items():
    dest = os.path.join(OUT, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 1000:
        print(f"have {name} ({os.path.getsize(dest):,})")
        continue
    sz = head_size(url)
    print(f"{name}: {sz:,} bytes" if sz else f"{name}: no HEAD")
    if sz is None or sz > 400_000_000:
        print("  skip")
        continue
    tmp = dest + ".part"
    p = subprocess.run(["curl", "-sS", "-L", "-m", "1800", "-o", tmp, url])
    if p.returncode == 0 and os.path.exists(tmp) and os.path.getsize(tmp) > 1000:
        os.replace(tmp, dest)
        print(f"  got {name} ({os.path.getsize(dest):,})")
    else:
        print(f"  FAIL {name}")
        if os.path.exists(tmp):
            os.remove(tmp)
print("PLATFORM DOWNLOADS DONE")
