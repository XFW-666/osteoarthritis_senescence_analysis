"""Exact word accounting for the manuscript, broken down the way a journal counts it."""
import json, re, sys, os
sys.path.insert(0, os.path.abspath("."))
import manuscript_text as T1
import manuscript_text2 as T2


def wc(s):
    return len(str(s).split())


body, per_block = [], []
for name, blk in T1.METHODS:
    for p in blk:
        per_block.append(("Methods: " + name, wc(p)))
    body += list(blk)
for name, blk in T2.RESULTS:
    for p in blk:
        per_block.append(("Results: " + name, wc(p)))
    body += list(blk)
for name, blk in T2.DISCUSSION:
    for p in blk:
        per_block.append(("Discussion: " + name, wc(p)))
    body += list(blk)
body += list(T2.CONCLUSION)

intro = sum(wc(p) for p in T1.INTRODUCTION)
methods = sum(wc(p) for n, blk in T1.METHODS for p in blk)
results = sum(wc(p) for n, blk in T2.RESULTS for p in blk)
disc = sum(wc(p) for n, blk in T2.DISCUSSION for p in blk)
concl = sum(wc(p) for p in T2.CONCLUSION)
abstract = sum(wc(v) for v in T1.ABSTRACT.values())
kp = sum(wc(x) for x in T1.KEY_POINTS)
legends = sum(wc(b) for pair in T2.FIGURE_LEGENDS for b in pair)
statements = sum(wc(b) for pair in T2.STATEMENTS for b in pair)

refs = json.load(open("results/references.json"))
ref_words = sum(wc(r["text"]) + 3 for r in refs)   # + "N. "

print(f"{'Introduction':28s} {intro:>6,}")
print(f"{'Methods':28s} {methods:>6,}")
print(f"{'Results':28s} {results:>6,}")
print(f"{'Discussion':28s} {disc:>6,}")
print(f"{'Conclusion':28s} {concl:>6,}")
print(f"{'-'*40}")
print(f"{'MAIN TEXT (intro..conclusion)':28s} {intro+methods+results+disc+concl:>6,}")
print(f"{'Abstract':28s} {abstract:>6,}")
print(f"{'Key points':28s} {kp:>6,}")
print(f"{'Figure legends':28s} {legends:>6,}")
print(f"{'Declarations':28s} {statements:>6,}")
print(f"{'References (88)':28s} {ref_words:>6,}")
print(f"{'='*40}")
total_be = (intro + methods + results + disc + concl + abstract + kp + legends
            + statements + ref_words)
print(f"{'TOTAL body+refs':28s} {total_be:>6,}")
total_all = total_be
print(f"\nTarget 12,000 -> cut {total_all-12000:,} words ({100*(total_all-12000)/total_all:.1f}%)")

print("\nparagraph length distribution (main text):")
lens = sorted(wc(p) for p in body)
import statistics
print(f"  n={len(lens)}  median={statistics.median(lens):.0f}  min={lens[0]}  max={lens[-1]}")
for thr in (40, 60, 80, 100):
    print(f"  paragraphs under {thr} words: {sum(1 for x in lens if x < thr)}")

print("\nlongest 12 blocks:")
for name, w in sorted(per_block, key=lambda x: -x[1])[:12]:
    print(f"  {w:>4}  {name}")
print("\nshortest 12 blocks:")
for name, w in sorted(per_block, key=lambda x: x[1])[:12]:
    print(f"  {w:>4}  {name}")
