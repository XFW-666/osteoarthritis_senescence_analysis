"""Probe candidate cartilage expression datasets for a usable OA vs normal case/control split."""
import io, subprocess, re, collections, zlib

CANDS = ["GSE12021", "GSE1919", "GSE57218", "GSE64384", "GSE117999", "GSE143514",
         "GSE98918", "GSE168859", "GSE178055", "GSE16464", "GSE80754", "GSE100647"]


def partial_gunzip(raw):
    d = zlib.decompressobj(16 + zlib.MAX_WBITS)
    return d.decompress(raw).decode("utf-8", "replace")


for g in CANDS:
    stub = g[:-3] + "nnn"
    u = (f"https://ftp.ncbi.nlm.nih.gov/geo/series/{stub}/{g}/matrix/"
         f"{g}_series_matrix.txt.gz")
    p = subprocess.run(["curl", "-sS", "-m", "90", "-r", "0-300000", u], capture_output=True)
    if p.returncode != 0 or len(p.stdout) < 200 or not p.stdout.startswith(b"\x1f\x8b"):
        print(f"{g}: unavailable (rc={p.returncode}, {len(p.stdout)} bytes, "
              f"head={p.stdout[:40]!r})")
        continue
    txt = partial_gunzip(p.stdout)
    plat = re.search(r"!Series_platform_id\t(\S+)", txt)
    title = re.search(r'!Series_title\t"(.*)"', txt)
    print("=" * 100)
    print(f"{g}  platform={plat.group(1) if plat else '?'}  {title.group(1)[:100] if title else ''}")
    for l in txt.split("\n"):
        if l.startswith("!Sample_characteristics") or l.startswith("!Sample_source_name"):
            vals = [v.strip().strip('"') for v in l.split("\t")[1:]]
            c = collections.Counter(vals)
            if len(c) <= 10:
                print(f"  {l.split(chr(9))[0][:40]:42s} n={len(vals)} {dict(c)}")
            else:
                print(f"  {l.split(chr(9))[0][:40]:42s} n={len(vals)} all distinct")
