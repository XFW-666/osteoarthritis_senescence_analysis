"""
fig_helpers.py — plotting primitives for the redesigned figure set.

Each figure gets its own chart grammar, so these helpers cover the less common forms:
radial bars, forest plots, chord/radial link maps, stacked composition, dot matrices,
ROC with inset, and shared heatmap / box helpers.
"""
import os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.path import Path
from matplotlib.patches import PathPatch, Wedge, Patch, Rectangle
from matplotlib.lines import Line2D
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from viz_style import NEON, CYCLE, BG, PANEL, GRID, TXT, MUTED, ACCENT, neon_axes, neon_text

DIV_CMAP = LinearSegmentedColormap.from_list(
    "div_light", ["#1D4ED8", "#6E9BEE", "#C9DCF9", "#FFFFFF", "#F7C6DA", "#E9709F", "#BE185D"], N=256)
SEQ_CMAP = LinearSegmentedColormap.from_list(
    "seq_light", ["#FFFFFF", "#E4EDFB", "#B7CFEF", "#7BA3DE", "#3F6FC4", "#1E3A8A"], N=256)
SEN_CMAP = LinearSegmentedColormap.from_list(
    "sen_light", ["#FFFFFF", "#DFF3E8", "#9BDCBE", "#4FB98D", "#17795A"], N=256)
LIB_COLORS = [NEON["blue"], NEON["magenta"], NEON["teal"], NEON["amber"], NEON["violet"], NEON["orange"]]


# ---------------------------------------------------------------- basic forms
def heatmap(ax, M, cmap, cbar_label=None, xticklabels=True, yticklabels=True, vmin=None,
            vmax=None, xtick_fs=7, ytick_fs=7, aspect="auto", cbar=True):
    im = ax.imshow(M, cmap=cmap, aspect=aspect, vmin=vmin, vmax=vmax, interpolation="nearest")
    if xticklabels:
        ax.set_xticks(np.arange(M.shape[1]))
        ax.set_xticklabels([str(c) for c in getattr(M, "columns", range(M.shape[1]))],
                           rotation=90, fontsize=xtick_fs)
    else:
        ax.set_xticks([])
    if yticklabels:
        ax.set_yticks(np.arange(M.shape[0]))
        ax.set_yticklabels([str(c) for c in getattr(M, "index", range(M.shape[0]))], fontsize=ytick_fs)
    else:
        ax.set_yticks([])
    for s in ax.spines.values():
        s.set_color("#9AA9C0"); s.set_visible(True)
    ax.grid(False)
    if cbar_label and cbar:
        cb = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
        cb.set_label(cbar_label, color=TXT, fontsize=8.5)
        cb.ax.tick_params(colors=MUTED, labelsize=7.5)
        cb.outline.set_edgecolor("#9AA9C0")
    return im


def box2(ax, a, b, pos, col_a, col_b, width=0.62):
    bp = ax.boxplot([a, b], positions=pos, widths=width, patch_artist=True,
                    medianprops=dict(color=TXT, lw=1.4),
                    whiskerprops=dict(color=MUTED, lw=1.0), capprops=dict(color=MUTED, lw=1.0),
                    boxprops=dict(lw=1.2),
                    flierprops=dict(marker="o", markersize=2.2, markerfacecolor=MUTED,
                                    markeredgecolor="none", alpha=0.6))
    for box, c in zip(bp["boxes"], [col_a, col_b]):
        box.set_facecolor(c); box.set_alpha(0.45); box.set_edgecolor(c)
    return bp


# ---------------------------------------------------------------- 1. unified dot matrix
def dot_matrix(ax, rows, xvals, sizes, colors, ylabels, title, xlabel, group_of_row=None,
               group_colors=None, x_ref=None, band=True):
    """One chart for many libraries: y = term, x = significance, size = overlap, colour = library."""
    y = np.arange(len(rows))[::-1]
    if band and group_of_row is not None:
        runs, start = [], 0
        for i in range(1, len(group_of_row) + 1):
            if i == len(group_of_row) or group_of_row[i] != group_of_row[start]:
                runs.append((start, i, group_of_row[start])); start = i
        for k, (a, b, g) in enumerate(runs):
            col = (group_colors or {}).get(g, "#EDF2FA") if isinstance(group_colors, dict) \
                else "#EDF2FA"
            ax.axhspan(len(rows) - b + 0.5, len(rows) - a - 0.5, color=col,
                       alpha=0.55 if k % 2 == 0 else 0.28, zorder=0)
    for yy, xv, s, col in zip(y, xvals, sizes, colors):
        ax.plot([0, xv], [yy, yy], color=col, lw=1.1, alpha=0.35, zorder=2,
                solid_capstyle="round")
        ax.scatter(xv, yy, s=s, color=col, alpha=0.95, zorder=4,
                   edgecolors="#FFFFFF", linewidths=0.8)
    ax.set_yticks(y); ax.set_yticklabels(ylabels, fontsize=7.8)
    ax.set_xlabel(xlabel); ax.set_title(title)
    if x_ref is not None:
        ax.axvline(x_ref, color=MUTED, ls=":", lw=1.0)
    ax.grid(axis="x", alpha=0.5); ax.grid(axis="y", visible=False)
    ax.set_ylim(-0.8, len(rows) - 0.2)
    neon_axes(ax)


# ---------------------------------------------------------------- 2. radial bar chart
def radial_bar(ax, labels, values, colors, title, rmax=None, label_fs=7.4, start=90, gap=0.0):
    n = len(labels)
    ang = np.deg2rad(start + np.arange(n) * (360.0 / n))
    v = np.asarray(values, float)
    vmax = rmax or v.max()
    ax.set_theta_zero_location("N"); ax.set_theta_direction(-1)
    width = np.deg2rad(360.0 / n) * (1 - gap)
    for a, val, col in zip(ang, v, colors):
        ax.bar(a, val / vmax, width=width, bottom=0.0, color=col, alpha=0.9,
               edgecolor="#FFFFFF", linewidth=0.7, zorder=4)
        ax.text(a, 1.06, labels[int(np.round((np.rad2deg(a) - start) / (360.0 / n))) % n],
                rotation=np.rad2deg(a), rotation_mode="anchor", ha="center", va="center",
                fontsize=label_fs, color=TXT, fontweight="bold")
    ax.set_ylim(0, 1.28)
    ax.set_xticks([]); ax.set_yticks([])
    ax.spines["polar"].set_visible(False)
    ax.grid(False)
    ax.set_title(title, pad=16)
    return ax


# ---------------------------------------------------------------- 3. forest plot
def forest_plot(ax, labels, values, los, his, colors, title, xlabel, ref=0.5, groups=None,
                band=True):
    y = np.arange(len(labels))[::-1]
    if band and groups is not None:
        runs, start = [], 0
        for i in range(1, len(groups) + 1):
            if i == len(groups) or groups[i] != groups[start]:
                runs.append((start, i)); start = i
        for k, (a, b) in enumerate(runs):
            ax.axhspan(len(labels) - b + 0.5, len(labels) - a - 0.5,
                       color="#EDF2FA", alpha=0.6 if k % 2 == 0 else 0.3, zorder=0)
    for i, (yy, v, lo, hi, col) in enumerate(zip(y, values, los, his, colors)):
        if groups is not None and i and groups[i] != groups[i - 1]:
            ax.axhline(len(labels) - i - 0.5, color="#C9D6EA", lw=1.0, zorder=1)
        ax.plot([lo, hi], [yy, yy], color=col, lw=2.2, alpha=0.9, solid_capstyle="round",
                zorder=3)
        ax.scatter(v, yy, s=88, color=col, zorder=5, edgecolors="#FFFFFF", linewidths=0.8)
        ax.text(hi + 0.012, yy, f"{v:.3f}", color=col, fontsize=7.8, va="center",
                fontweight="bold")
    ax.axvline(ref, color=MUTED, ls=":", lw=1.1, zorder=2)
    ax.set_yticks(y); ax.set_yticklabels(labels, fontsize=8.4)
    ax.set_ylim(-0.7, len(labels) - 0.3)
    ax.set_xlabel(xlabel); ax.set_title(title)
    neon_axes(ax)


# ---------------------------------------------------------------- 4. chord / radial link map
def chord_map(ax, outer_labels, outer_colors, inner_labels, links, title,
              outer_frac=0.32, label_fs=6.0, label_gap=0.055, title_pad=6):
    """Outer ring = compounds, inner ring = signature genes, curved links between them."""
    ax.set_aspect("equal"); ax.axis("off")
    n_o, n_i = len(outer_labels), len(inner_labels)
    r_out, r_in = 1.00, 0.60

    def span(n, frac, offset):
        step = 2 * np.pi / n
        w = step * frac
        centres = np.deg2rad(90) + offset + np.arange(n) * step
        return centres, w

    oc, ow = span(n_o, 0.72, 0.0)
    ic, iw = span(n_i, 0.70, np.pi / n_i)

    for c, lab, col in zip(oc, outer_labels, outer_colors):
        ax.add_patch(Wedge((0, 0), r_out, np.rad2deg(c - ow / 2), np.rad2deg(c + ow / 2),
                           width=0.15, facecolor=col, edgecolor="#FFFFFF", lw=0.8, zorder=4))
        ang = np.rad2deg(c) % 360
        x, y = (r_out + label_gap) * np.cos(c), (r_out + label_gap) * np.sin(c)
        rot = ang if ang <= 90 or ang >= 270 else ang + 180
        ax.text(x, y, lab, rotation=rot, rotation_mode="anchor", ha="center", va="center",
                fontsize=label_fs, color=TXT, fontweight="bold")
    for c, lab in zip(ic, inner_labels):
        ax.add_patch(Wedge((0, 0), r_in, np.rad2deg(c - iw / 2), np.rad2deg(c + iw / 2),
                           width=0.13, facecolor="#BFD4EE", edgecolor="#FFFFFF", lw=0.8,
                           zorder=5))
        x, y = (r_in - 0.16) * np.cos(c), (r_in - 0.16) * np.sin(c)
        ax.text(x, y, lab, ha="center", va="center", fontsize=label_fs + 0.5, color=TXT,
                fontweight="bold", zorder=6)

    for oi, gi, wt in links:
        a, b = oc[oi], ic[gi]
        p0 = np.array([r_out * np.cos(a), r_out * np.sin(a)])
        p1 = np.array([r_in * np.cos(b), r_in * np.sin(b)])
        ctrl = np.array([0.0, 0.0])
        path = Path([tuple(p0), tuple(ctrl), tuple(p1)],
                    [Path.MOVETO, Path.CURVE3, Path.CURVE3])
        ax.add_patch(PathPatch(path, facecolor="none", edgecolor=outer_colors[oi],
                               lw=0.9 + 3.4 * wt, alpha=0.30, zorder=2,
                               capstyle="round"))
    ax.set_xlim(-1.30, 1.30); ax.set_ylim(-1.22, 1.22)
    ax.set_title(title, pad=title_pad)


# ---------------------------------------------------------------- 5. stacked composition
def stacked_composition(ax, categories, shares_a, shares_b, colors, title, group_labels):
    """Stacked composition bars for two groups, with a delta annotation strip."""
    x = np.arange(2)
    bottom = np.zeros(2)
    for i, (cat, col) in enumerate(zip(categories, colors)):
        vals = np.array([shares_a[i], shares_b[i]]) * 100
        ax.bar(x, vals, bottom=bottom, color=col, alpha=0.92, width=0.55,
               edgecolor="#FFFFFF", linewidth=0.8, label=cat if i < 12 else None)
        for xi, (v, b) in enumerate(zip(vals, bottom)):
            if v > 6.5:
                ax.text(xi, b + v / 2, f"{v:.0f}", ha="center", va="center", fontsize=6.8,
                        color="#FFFFFF", fontweight="bold")
        bottom += vals
    ax.set_xticks(x); ax.set_xticklabels(group_labels, fontsize=9)
    ax.set_ylabel("relative enrichment share (%)")
    ax.set_title(title); ax.set_ylim(0, 100)
    neon_axes(ax)


# ---------------------------------------------------------------- 6. ROC with inset zoom
def roc_inset(ax, curves, y, title, inset_bounds=(0.61, 0.07, 0.36, 0.36), legend_below=True):
    """ROC panel with a small zoom inset.

    The legend is placed BELOW the axes by default: a legend inside the lower-right corner would
    sit underneath the inset and read as two overlapping plots.
    """
    for lab, fpr, tpr, auc, col, lw in curves:
        ax.plot(fpr, tpr, color=col, lw=lw, label=f"{lab} (AUC {auc:.3f})")
    ax.plot([0, 1], [0, 1], color=MUTED, lw=1.0, ls=":")
    ax.set_xlabel("1 − specificity"); ax.set_ylabel("sensitivity")
    ax.set_title(title)
    if legend_below:
        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.135), ncol=4, fontsize=7.4,
                  frameon=False, handlelength=1.4, columnspacing=1.2)
    else:
        ax.legend(loc="lower right", fontsize=8.2)
    neon_axes(ax)
    axi = ax.inset_axes(inset_bounds)
    for lab, fpr, tpr, auc, col, lw in curves:
        axi.plot(fpr, tpr, color=col, lw=lw * 0.9)
    axi.set_xlim(0, 0.30); axi.set_ylim(0.70, 1.005)
    axi.set_title("zoom: high specificity", fontsize=7.0, pad=3)
    axi.tick_params(labelsize=6.2)
    for s in ("top", "right"):
        axi.spines[s].set_visible(False)
    for s in axi.spines.values():
        s.set_color("#9AA9C0")
    axi.set_facecolor("#FBFDFF")
    return axi


# ---------------------------------------------------------------- 7. panel letters
def letter(ax, ch, x=-0.10, y=1.045, pts=None):
    """Panel letter.  `pts=(dx, dy)` anchors it in absolute offset points from the axes'
    top-left corner, which is robust when the axes box is resized (e.g. by a colorbar)
    and axes-fraction coordinates would drift."""
    if pts is not None:
        ax.annotate(ch, xy=(0, 1), xycoords="axes fraction", xytext=pts,
                    textcoords="offset points", fontsize=12.5, fontweight="bold",
                    color=ACCENT, va="bottom", ha="left", zorder=30)
        return
    ax.text(x, y, ch, transform=ax.transAxes, fontsize=12.5, fontweight="bold",
            color=ACCENT, va="bottom", ha="left", zorder=30)


# ---------------------------------------------------------------- 8. label declutter
def place_labels(ax, items, color="#8A1140", fontsize=8.2, glow=True, pad=0.012):
    """Greedy non-overlapping annotation: items = [(x, y, text), ...] in data coordinates."""
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    xr, yr = (x1 - x0) or 1.0, (y1 - y0) or 1.0

    def box(x, y, w, h):
        return (x - w / 2, y - h / 2, x + w / 2, y + h / 2)

    def hit(a, b):
        return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])

    cands = [(0, 0.016), (0, -0.016), (0.05, 0.016), (-0.05, 0.016),
             (0.05, -0.016), (-0.05, -0.016), (0, 0.034), (0, -0.034),
             (0.10, 0.016), (-0.10, 0.016), (0.10, 0.034), (-0.10, 0.034),
             (0, 0.052), (0, -0.052)]
    placed = []
    for px, py, t in items:
        w = xr * 0.0085 * len(t) + pad * xr
        h = yr * 0.032
        best = None
        for dx, dy in cands:
            bx, by = px + dx * xr, py + dy * yr
            bb = box(bx, by, w, h)
            if not any(hit(bb, b) for b in placed):
                best = (bx, by, bb); break
        if best is None:
            bx, by = px, py + 0.070 * yr
            best = (bx, by, box(bx, by, w, h))
        placed.append(best[2])
        kw = dict(color=color, fontsize=fontsize, ha="center", va="center", zorder=20)
        t_ = ax.text(best[0], best[1], t, **kw)
        if glow:
            t_.set_path_effects([__import__("matplotlib.patheffects", fromlist=["x"])
                                 .withStroke(linewidth=2.4, foreground="#FFFFFF")])


def place_labels_display(ax, items, fig=None, fontsize=7.6, color=None, tol=0.08):
    """Place point labels with offset points, avoiding collisions measured in DISPLAY space.

    Label boxes are computed deterministically (anchor transformed to display coords, text size
    measured once) rather than by asking matplotlib for an annotation's extent, which is not
    resolved until the next draw.
    items = [(x, y, text), ...]
    """
    import matplotlib.pyplot as plt
    from viz_style import _bbox_overlap
    fig = fig or plt.gcf()
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    offsets = [(0, 11), (0, -13), (17, 8), (-17, 8), (17, -11), (-17, -11),
               (0, 22), (0, -24), (29, 0), (-29, 0), (31, 15), (-31, 15),
               (31, -17), (-31, -17), (0, 34), (0, -36), (44, 0), (-44, 0),
               (46, 18), (-46, 18), (46, -20), (-46, -20)]
    placed = []
    for x, y, t in items:
        tmp = fig.text(0.001, 0.001, t, fontsize=fontsize)
        bb0 = tmp.get_window_extent(renderer=r)
        w, h = bb0.width, bb0.height
        tmp.remove()
        px, py = ax.transData.transform((x, y))
        chosen = None
        for dx, dy in offsets:
            box = (px + dx - w / 2, py + dy - h / 2, px + dx + w / 2, py + dy + h / 2)
            if not any(_bbox_overlap(type("B", (), {"x0": box[0], "y0": box[1],
                                                    "x1": box[2], "y1": box[3]})(), p) > tol
                       for p in placed):
                chosen = box; break
        if chosen is None:
            chosen = (px - w / 2, py + 30, px + w / 2, py + 30 + h)
        placed.append(type("B", (), {"x0": chosen[0], "y0": chosen[1],
                                     "x1": chosen[2], "y1": chosen[3]})())
        ax.annotate(t, xy=(x, y), xytext=((chosen[0] + chosen[2]) / 2 - px,
                                         (chosen[1] + chosen[3]) / 2 - py),
                    textcoords="offset points", fontsize=fontsize, color=color or TXT,
                    ha="center", va="center", zorder=25)


def save(fig, path):
    from viz_style import save as _save
    _save(fig, path)
