"""
step13_figures_causal.py — Figure 9: causal inference (MR), connectivity-map drug reversal, and
the boundary condition of the cohort that did not validate.
"""
import os, sys, json, math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from scipy import stats
from sklearn.metrics import roc_curve, roc_auc_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from viz_style import (NEON, CYCLE, BG, GRID, TXT, MUTED, ACCENT, apply_style,
                       neon_axes, neon_text, neon_bar, neon_scatter, save)
import fig_helpers as H

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "results"); FIG = os.path.join(BASE, "figures")
apply_style()

PHENO_SHORT = {"M13_ARTHROSIS": "Arthrosis (all sites)",
               "M13_ARTHROSIS_KNEE": "Knee OA",
               "M13_ARTHTROSIS_COX": "Hip OA",
               "M13_ARTHROSIS_KNEE_PRIM_KNEESURG": "Knee OA, surgery"}
PHENO_COL = {"M13_ARTHROSIS": NEON["blue"], "M13_ARTHROSIS_KNEE": NEON["magenta"],
             "M13_ARTHTROSIS_COX": NEON["teal"],
             "M13_ARTHROSIS_KNEE_PRIM_KNEESURG": NEON["amber"]}
GENE_COL = {"ETS2": "#D1495B", "GADD45B": "#2E86AB", "JUN": "#EDAE49",
              "CDKN1B": "#7B4B94", "UBC": "#3FA34D", "CDKN1A": "#C1436D",
              "HLA-F": "#4ECDC4", "CDK2": "#5C5470"}

SENOLYTICS = ["quercetin", "dasatinib", "navitoclax", "fisetin", "piperlongumine",
              "rapamycin", "resveratrol", "curcumin", "metformin", "nutlin", "mk-2206", "abt-737"]


def figure9():
    mr = pd.read_csv(os.path.join(OUT, "mr_eqtlgen_results.csv"))
    col = pd.read_csv(os.path.join(OUT, "coloc_results.csv"))
    cmap = pd.read_csv(os.path.join(OUT, "cmap_connectivity.csv"))
    diag = json.load(open(os.path.join(OUT, "gse283079_diagnostics.json")))
    null = np.load(os.path.join(OUT, "gse283079_permutation_null.npy"))
    pred = pd.read_csv(os.path.join(OUT, "gse283079_predictions.csv"))
    gdir = pd.read_csv(os.path.join(OUT, "gse283079_direction.csv"))
    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)

    fig = plt.figure(figsize=(17.0, 12.2), facecolor=BG)
    gs = fig.add_gridspec(3, 3, height_ratios=[1.18, 1, 1], hspace=0.80, wspace=0.44,
                          left=0.165, right=0.975, top=0.935, bottom=0.065)

    # ---- A: eQTLGen MR forest, genes x OA phenotypes (hero)
    ax = fig.add_subplot(gs[0:2, 0:2]); neon_axes(ax)
    genes = [g for g in ["ETS2", "GADD45B", "JUN", "CDKN1B", "UBC", "CDKN1A", "HLA-F", "CDK2"]
             if g in set(mr["gene"])]
    ypos, ylab, y, rowinfo = {}, [], 0, {}
    for g in genes:
        for ph in PHENO_SHORT:
            sub = mr[(mr["gene"] == g) & (mr["phenotype"] == ph)]
            if not len(sub):
                continue
            r = sub.iloc[0]
            sig = float(r["p_fdr"]) < 0.05
            ax.plot([r["OR_lo"], r["OR_hi"]], [y, y], color=PHENO_COL[ph], lw=2.0, alpha=0.9,
                    zorder=3, solid_capstyle="round")
            ax.scatter(r["OR"], y, s=72 if sig else 62, color=PHENO_COL[ph], zorder=5,
                       edgecolors="#FFFFFF", linewidths=0.7)
            if sig:
                ax.scatter(r["OR"], y, s=230, facecolors="none", edgecolors=NEON["magenta"],
                           linewidths=1.8, zorder=6)
            ypos[g] = ypos.get(g, [])
            ypos[g].append(y)
            ylab.append(f"{g}   {PHENO_SHORT[ph]}")
            rowinfo[y] = r
            y += 1
        y += 0.8
    ax.axvline(1.0, color=TXT, ls="--", lw=1.3, zorder=2)
    ax.set_yticks(np.arange(len(ylab)))
    ax.set_yticklabels(ylab, fontsize=7.4)
    ax.set_xlabel("OR of osteoarthritis per 1-SD genetically predicted gene expression")
    ax.set_title("Mendelian randomisation: eQTLGen instruments, FinnGen R11 outcomes", fontsize=11)
    ax.set_xlim(0.45, 1.62)
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color=PHENO_COL[p], label=PHENO_SHORT[p])
                       for p in PHENO_SHORT], fontsize=7.4, loc="lower right", ncol=2)
    for g, ys in ypos.items():
        for yy in ys:
            ax.axhline(yy, color="#EDF2FA", lw=6, zorder=0)
    # instrument strength and detectable effect, per gene
    for g, ys in ypos.items():
        f = rowinfo[ys[0]]["F_mean"]
        det = rowinfo[ys[0]]["detectable_OR_80pct"]
        ax.text(1.605, np.mean(ys), f"$F$ = {f:,.0f}\nOR$_{{80}}$ = {det:.2f}", fontsize=6.9,
                color=MUTED, va="center", ha="right")
    ax.text(0.985, 0.985,
            "1 of 32 estimates survives FDR: CDKN1A to knee-replacement surgery "
            "(OR 1.17, 95% CI 1.07-1.29, FDR $P$ = .035)",
            transform=ax.transAxes, color=NEON["magenta"], fontsize=7.6, style="italic",
            ha="right", va="top", zorder=30,
            bbox=dict(facecolor="#FFFFFF", edgecolor="#C9D6EA", boxstyle="round,pad=0.32",
                      alpha=0.97))
    H.letter(ax, "A", pts=(-124, 4))

    # ---- B: MR effect vs transcriptomic direction
    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    rowsc = []
    for g in genes:
        sub = mr[(mr["gene"] == g) & (mr["phenotype"] == "M13_ARTHROSIS")]
        if len(sub) and g in deg.index:
            rowsc.append((float(deg.loc[g, "logFC"]), float(sub.iloc[0]["beta"]),
                          float(sub.iloc[0]["se"]), g))
    lim_x = max(abs(r[0]) for r in rowsc) * 1.30
    lim_y = max(abs(r[1]) + 1.96 * r[2] for r in rowsc) * 1.30
    ax.add_patch(Rectangle((-lim_x, -lim_y), lim_x, lim_y, facecolor="#E4F1E6",
                           alpha=0.55, zorder=0))
    ax.add_patch(Rectangle((0, 0), lim_x, lim_y, facecolor="#E4F1E6", alpha=0.55, zorder=0))
    for x, b, se, g in rowsc:
        ax.plot([x, x], [b - 1.96 * se, b + 1.96 * se], color=MUTED, lw=1.0, alpha=0.6, zorder=2)
    for r in rowsc:
        ax.scatter(r[0], r[1], s=70, color=GENE_COL.get(r[3], NEON["magenta"]),
                   zorder=6, edgecolors="#FFFFFF", linewidths=0.8,
                   label=r[3])
    handles, labels_ = ax.get_legend_handles_labels()
    uniq = dict(zip(labels_, handles))
    ax.legend(uniq.values(), uniq.keys(), fontsize=6.6, ncol=2, loc="lower right",
              frameon=True, framealpha=0.94, edgecolor="#C9D6EA", handlelength=0.7,
              handletextpad=0.35, columnspacing=0.7, labelspacing=0.25)
    ax.axhline(0, color=TXT, lw=1.0); ax.axvline(0, color=MUTED, lw=1.0, ls=":")
    ax.tick_params(axis="both", pad=6)
    ax.set_xlim(-lim_x, lim_x); ax.set_ylim(-lim_y, lim_y)
    ax.set_xlabel("$\\log_2$ fold change in OA cartilage")
    ax.set_ylabel("MR causal estimate (log OR)")
    ax.set_title("Transcriptomic vs causal direction")
    n_con = sum(1 for r in rowsc if np.sign(r[0]) == np.sign(r[1]))
    ax.text(0.03, 0.03, f"concordant quadrants (shaded): {n_con}/{len(rowsc)}",
            transform=ax.transAxes, fontsize=7.4, color=MUTED)
    H.letter(ax, "B", x=-0.36)

    # ---- C: colocalisation does not support a shared causal variant
    ax = fig.add_subplot(gs[1, 2]); neon_axes(ax)
    m = col.merge(mr[["gene", "phenotype", "p"]], on=["gene", "phenotype"], how="inner")
    m["nlogp"] = -np.log10(m["p"].clip(lower=1e-300))
    for g, sub in m.groupby("gene"):
        ax.scatter(sub["nlogp"], sub["PP4"], s=34 + 26 * (sub["n_snp"] / m["n_snp"].max()),
                   color=NEON["blue"], alpha=0.85, edgecolors="#FFFFFF", linewidths=0.6, zorder=5)
    ax.axhline(0.8, color=NEON["green"], lw=1.6, ls="--", zorder=3)
    ax.text(0.985, 0.815, "conventional threshold for colocalisation (PP.H4 = 0.8)",
            transform=ax.transAxes, fontsize=7.0, color=NEON["green"], va="bottom", ha="right")
    ax.set_xlabel("$-\\log_{10}$ MR $P$ value")
    ax.set_ylabel("PP.H4 (shared causal variant)")
    ax.set_ylim(-0.02, 1.0)
    ax.set_title("Colocalisation refutes shared causality")
    top = m.nlargest(1, "nlogp").iloc[0]
    H.place_labels_display(ax, [(top["nlogp"], top["PP4"],
                                 f"{top['gene']}\nPP.H4 = {top['PP4']:.3f}")],
                           fig=fig, fontsize=7.2)
    ax.text(0.02, 0.97, f"max PP.H4 across 32 loci = {m['PP4'].max():.3f}\n"
                        f"PP.H3 dominant in {int((m['PP3'] > 0.5).sum())}/32 loci",
            transform=ax.transAxes, fontsize=7.2, color=MUTED, ha="left", va="top")
    H.letter(ax, "C", x=-0.32)

    # ---- D: connectivity null with the senolytic positive control
    ax = fig.add_subplot(gs[2, 0]); neon_axes(ax)
    cm = cmap[cmap["library"] == "CMap (Lamb 2006)"]
    ax.hist(cm["score"], bins=60, color="#C9D6EA", alpha=0.95, zorder=2)
    hits = cm[cm["compound"].str.lower().str.contains("|".join(SENOLYTICS), regex=True)]
    for _, r in hits.iterrows():
        ax.axvline(r["score"], color=NEON["green"], lw=1.1, alpha=0.55, zorder=3)
    top3 = cm.head(3)
    for _, r in top3.iterrows():
        ax.axvline(r["score"], color=NEON["magenta"], lw=1.4, alpha=0.8, zorder=4)
    ax.axvline(0, color=TXT, lw=1.0, ls=":")
    ax.set_xlabel("connectivity score  (negative = reverses the OA signature)")
    ax.set_ylabel("compounds")
    ax.set_title("Connectivity distribution")
    ax.legend(handles=[Patch(facecolor=NEON["green"], alpha=0.6,label="known senolytic\n(piperlongumine 96%, resveratrol 95%, quercetin 84%)"),
                       Patch(facecolor=NEON["magenta"], alpha=0.8, label="top reverser"),
                       Patch(facecolor="#C9D6EA", label="all compounds")],
              fontsize=7.2, loc="upper center", bbox_to_anchor=(0.5, -0.28), ncol=3,
              frameon=False)
    pct = lambda s: (1 - (cm["score"] <= s).sum() / len(cm)) * 100
    txt = "\n".join(f"{r['compound'][:16]}  {pct(r['score']):.0f}%"
                    for _, r in hits.head(3).iterrows())
    H.letter(ax, "D", x=-0.34)

    # ---- E: GSE283079 permutation null vs observed
    ax = fig.add_subplot(gs[2, 1]); neon_axes(ax)
    ax.hist(null, bins=50, color="#C9D6EA", alpha=0.95, zorder=2)
    obs = diag["auc"]; det = diag["detectable_auc_80pct"]
    ax.axvline(obs, color=NEON["magenta"], lw=2.4, zorder=5)
    ax.axvline(0.5, color=TXT, lw=1.2, ls=":", zorder=4)
    ax.axvline(det, color=NEON["amber"], lw=2.0, ls="--", zorder=5)
    top = ax.get_ylim()[1]
    ax.annotate(f"observed AUC {obs:.3f}", xy=(obs, top * 0.80),
                xytext=(0.02, 0.97), textcoords="axes fraction", color=NEON["magenta"],
                fontsize=7.0, fontweight="bold", ha="left", va="top",
                arrowprops=dict(arrowstyle="->", color=NEON["magenta"], lw=1.1,
                                connectionstyle="arc3,rad=0"),
                zorder=20,
                bbox=dict(facecolor="#FFFFFF", edgecolor="#F0C9DC", boxstyle="round,pad=0.25",
                          alpha=0.97))
    ax.annotate(f"smallest AUC detectable\nat 80% power = {det:.2f}", xy=(det, top * 0.80),
                xytext=(0.98, 0.97), textcoords="axes fraction", color="#B8860B",
                fontsize=7.0, fontweight="bold", ha="right", va="top", linespacing=1.3,
                arrowprops=dict(arrowstyle="->", color="#B8860B", lw=1.1),
                zorder=20,
                bbox=dict(facecolor="#FFFFFF", edgecolor="#F2DFB6", boxstyle="round,pad=0.25",
                          alpha=0.97))
    ax.set_xlabel("AUC under label permutation (n = 20,000)")
    ax.set_ylabel("count")
    ax.set_title(f"GSE283079 uninformative (P = {diag['permutation_p']:.2f})")
    H.letter(ax, "E", x=-0.30)

    # ---- F: direction consistency in the failing cohort
    ax = fig.add_subplot(gs[2, 2]); neon_axes(ax)
    for _, r in gdir.iterrows():
        ax.scatter(r["logFC_discovery"], r["logFC_GSE283079"], s=95,
                   color=GENE_COL.get(r["gene"], NEON["magenta"]), zorder=5,
                   edgecolors="#FFFFFF", linewidths=0.8, label=r["gene"])
    ax.axhline(0, color=MUTED, lw=1.0); ax.axvline(0, color=MUTED, lw=1.0, ls=":")
    lim = max(abs(gdir["logFC_discovery"]).max(), abs(gdir["logFC_GSE283079"]).max()) * 1.25
    ax.plot([-lim, lim], [-lim, lim], color=MUTED, lw=1.0, ls="--", zorder=1)
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
    ax.set_xlabel("$\\log_2$ FC in discovery (cartilage)")
    ax.set_ylabel("$\\log_2$ FC in GSE283079 (synovium)")
    ax.set_title(f"Direction consistency {int(gdir['consistent'].sum())}/{len(gdir)}")
    h_, l_ = ax.get_legend_handles_labels()
    u_ = dict(zip(l_, h_))
    ax.legend(u_.values(), u_.keys(), fontsize=6.6, ncol=2, loc="lower right",
              frameon=True, framealpha=0.94, edgecolor="#C9D6EA", handlelength=0.7,
              handletextpad=0.35, columnspacing=0.7, labelspacing=0.25)
    H.letter(ax, "F", x=-0.30)

    save(fig, os.path.join(FIG, "Figure9_causal_reversal_boundary.png"))


if __name__ == "__main__":
    figure9()
