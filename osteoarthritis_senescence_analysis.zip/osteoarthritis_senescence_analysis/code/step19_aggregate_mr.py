"""
step19_aggregate_mr.py — programme-level Mendelian randomisation.

The single-gene analysis in step14 tested eight genes separately, which spends the
multiple-testing budget on 32 tests and is limited to one-to-seven instruments per gene.
The signature is a weighted combination of the eight genes, so it can be instrumented as a
single composite exposure: a SNP's effect on the composite is the coefficient-weighted sum of
its effects on whichever signature genes it instruments.  That pools the instruments across
loci, giving one test per osteoarthritis phenotype instead of eight.

Everything is computed from the harmonised instrument table cached by step14, so no further
downloads are needed.
"""
import os, json
import numpy as np
import pandas as pd
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "results")

PHENO = {"M13_ARTHROSIS": "Arthrosis, all sites",
         "M13_ARTHROSIS_KNEE": "Knee osteoarthritis",
         "M13_ARTHTROSIS_COX": "Hip osteoarthritis",
         "M13_ARTHROSIS_KNEE_PRIM_KNEESURG": "Knee osteoarthritis, surgery"}


def bh(p):
    p = np.asarray(p, float)
    o = np.argsort(p)
    q = np.empty(len(p))
    q[o] = np.minimum.accumulate((p[o] * len(p) / (np.arange(len(p)) + 1))[::-1])[::-1]
    return np.clip(q, 0, 1)


def ivw(a, b_out, se_out):
    """IVW of the outcome on the composite exposure effect a (exposure SEs are small relative
    to the outcome SEs and are carried in the instrument-strength column instead)."""
    w = 1.0 / se_out ** 2
    denom = float((a ** 2 * w).sum())
    beta = float((a * b_out * w).sum() / denom)
    return beta, float(np.sqrt(1.0 / denom))


def cochran_q(a, b_out, se_out, beta):
    w = 1.0 / se_out ** 2
    return float((w * (b_out - beta * a) ** 2).sum())


def main():
    inst = pd.read_csv(os.path.join(OUT, "mr_eqtlgen_instruments.csv"))
    coefs = pd.read_csv(os.path.join(OUT, "signature_coefficients.csv"))
    w = dict(zip(coefs["gene"], coefs["coef"]))
    genes = [g for g in w if g in set(inst["gene"])]
    print("signature weights:", {g: round(w[g], 3) for g in genes})

    # a SNP instrumenting more than one gene would have to be expressed in a common allele
    # orientation before its effects could be summed; check whether that ever happens.
    shared = (inst.groupby(["phenotype", "snp"])["gene"].nunique() > 1).sum()
    print(f"SNPs instrumenting more than one signature gene: {shared}")

    rows = []
    for ph, label in PHENO.items():
        sub = inst[inst["phenotype"] == ph]
        if not len(sub):
            continue
        # composite instrument: effect on the score = sum of w_g * b_eqtl over genes the SNP instruments
        agg = sub.groupby("snp").apply(
            lambda d: pd.Series({
                "a": float((d["b_eqtl"] * d["gene"].map(w)).sum()),
                "se_a": float(np.sqrt(((d["se_eqtl"] * d["gene"].map(w)) ** 2).sum())),
                "b_out": float(d["b_oa"].mean()),
                "se_out": float(d["se_oa"].mean()),
                "n_genes": int(d["gene"].nunique()),
                "F": float(d["F"].mean())}), include_groups=False)
        beta, se = ivw(agg["a"].values, agg["b_out"].values, agg["se_out"].values)
        Q = cochran_q(agg["a"].values, agg["b_out"].values, agg["se_out"].values, beta)
        Qp = float(stats.chi2.sf(Q, max(len(agg) - 1, 1)))
        z = beta / se
        p = float(2 * stats.norm.sf(abs(z)))
        # internal consistency: the composite effect implied by the eight single-gene estimates
        single = pd.read_csv(os.path.join(OUT, "mr_eqtlgen_results.csv"))
        s = single[single["phenotype"] == ph]
        beta_exp = float((s["beta"] * s["gene"].map(w)).sum())
        rows.append({"phenotype": ph, "label": label, "n_instruments": int(len(agg)),
                     "n_genes_instrumented": int(sub["gene"].nunique()),
                     "mean_F": float(agg["F"].mean()),
                     "beta": beta, "se": se, "OR": float(np.exp(beta)),
                     "OR_lo": float(np.exp(beta - 1.96 * se)),
                     "OR_hi": float(np.exp(beta + 1.96 * se)),
                     "detectable_OR_80pct": float(np.exp(2.802 * se)),
                     "p": p, "Q": Q, "Q_p": Qp,
                     "beta_expected_from_single_gene": beta_exp})
        print(f"  {label:28s} k={len(agg):2d} instruments, {sub['gene'].nunique()} genes, "
              f"mean F={agg['F'].mean():7.1f} | OR={np.exp(beta):.3f} "
              f"({np.exp(beta-1.96*se):.3f}-{np.exp(beta+1.96*se):.3f}) P={p:.4f} "
              f"| OR80={np.exp(2.802*se):.3f} "
              f"| expected from single-gene = {beta_exp:+.4f}")

    res = pd.DataFrame(rows)
    res["p_fdr"] = bh(res["p"])
    res.to_csv(os.path.join(OUT, "mr_aggregate_results.csv"), index=False)

    # ---- leave-one-gene-out: is the composite driven by a single locus?
    loo = []
    for ph in PHENO:
        sub = inst[inst["phenotype"] == ph]
        for drop in genes:
            s2 = sub[sub["gene"] != drop]
            if s2["gene"].nunique() < 2:
                continue
            agg = s2.groupby("snp").apply(
                lambda d: pd.Series({
                    "a": float((d["b_eqtl"] * d["gene"].map(w)).sum()),
                    "b_out": float(d["b_oa"].mean()),
                    "se_out": float(d["se_oa"].mean())}), include_groups=False)
            beta, se = ivw(agg["a"].values, agg["b_out"].values, agg["se_out"].values)
            loo.append({"phenotype": ph, "dropped_gene": drop, "OR": float(np.exp(beta)),
                        "p": float(2 * stats.norm.sf(abs(beta / se))), "k": int(len(agg))})
    loo = pd.DataFrame(loo)
    loo.to_csv(os.path.join(OUT, "mr_aggregate_leave_one_out.csv"), index=False)
    print("\nleave-one-gene-out OR range per phenotype:")
    print(loo.groupby("phenotype")["OR"].agg(["min", "max"]).round(3).to_string())

    summary = {"weights": {g: float(w[g]) for g in genes},
               "n_shared_snps": int(shared),
               "results": res.to_dict("records"),
               "loo_or_min": float(loo["OR"].min()), "loo_or_max": float(loo["OR"].max()),
               "n_fdr_significant": int((res["p_fdr"] < 0.05).sum())}
    json.dump(summary, open(os.path.join(OUT, "mr_aggregate_summary.json"), "w"), indent=1)
    print("\nSTEP19 DONE")


if __name__ == "__main__":
    main()
