"""
audit_provenance.py — independent re-derivation of every dataset claim.

Nothing here imports the analysis pipeline: sample counts are re-read straight from the GEO
series matrices / metadata on disk, so a mistake in step1_prepare's labelling cannot hide.
"""
import gzip, io, json, os, re, zlib, collections
import numpy as np

DATA = "data"
EXTRA = "data/extra"
OUT = "results"


def read_gz(path, limit=None):
    raw = open(path, "rb").read()
    txt = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(raw)
    return txt.decode("utf-8", "replace")


def matrix_facts(path):
    txt = read_gz(path)
    lines = txt.split("\n")
    gsms = [g.strip().strip('"') for g in
            next(l for l in lines if l.startswith("!Sample_geo_accession")).split("\t")[1:]]
    titles = [t.strip().strip('"') for t in
              next(l for l in lines if l.startswith("!Sample_title")).split("\t")[1:]]
    # GEO emits one row per characteristic and reuses the same label, so every row has to be
    # accumulated -- keeping only the last row loses the disease-state field entirely.
    char_rows = [l for l in lines if l.startswith("!Sample_characteristics")]
    chars = [[v.strip().strip('"') for v in l.split("\t")[1:]] for l in char_rows]
    start = next(i for i, l in enumerate(lines) if l.startswith("!series_matrix_table_begin"))
    end = next(i for i, l in enumerate(lines) if l.startswith("!series_matrix_table_end"))
    rows = end - start - 2
    hdr = [v.strip().strip('"') for v in lines[start + 1].split("\t")]
    return dict(n_samples=len(gsms), gsms=gsms, titles=titles, chars=chars,
                n_rows=rows, n_cols=len(hdr) - 1, title_line=next(
                    (l.split("\t")[1][:90] for l in lines if l.startswith("!Series_title")), ""),
                platform=next((l.split("\t")[1] for l in lines if l.startswith("!Series_platform_id")), ""))


def classify(f):
    """Independent, deliberately simple keyword labelling."""
    out = []
    for i in range(f["n_samples"]):
        blob = " ".join(c[i] for c in f["chars"] if i < len(c)).lower()
        t = f["titles"][i].lower() if i < len(f["titles"]) else ""
        s = blob + " " + t
        if "rheumatoid" in s:
            out.append("RA")
        elif "preserved" in s or "intact" in s:
            out.append("Preserved")
        elif "non-osteoarthrit" in s:
            out.append("Normal")
        elif "osteoarthrit" in s or re.search(r"\boa\b", s):
            out.append("OA")
        elif "normal" in s or "healthy" in s:
            out.append("Normal")
        else:
            out.append("?")
    return collections.Counter(out)


CLAIMS = {
    "GSE169077": dict(file=f"{DATA}/GSE169077_series_matrix.txt.gz", oa=6, normal=5, n=11,
                      text="6 OA / 5 normal cartilage pools"),
    "GSE55235": dict(file=f"{DATA}/GSE55235_series_matrix.txt.gz", oa=10, normal=10, n=30,
                     text=" deposited 30 samples: 10 OA + 10 normal analysed, 10 RA held out"),
    "GSE55457": dict(file=f"{DATA}/GSE55457_series_matrix.txt.gz", oa=10, normal=10, n=33,
                     text=" deposited 33 samples: 10 OA + 10 normal analysed, RA held out"),
    "GSE57218": dict(file=f"{EXTRA}/GSE57218_series_matrix.txt.gz", oa=33, normal=7, n=73,
                     text="7 healthy / 33 OA / 33 preserved"),
    "GSE43269": dict(file=f"{EXTRA}/GSE43269_series_matrix.txt.gz", oa=23, normal=18, n=41,
                     text="23 OA / 18 normal methylation"),
    "GSE73626": dict(file=f"{EXTRA}/GSE73626_series_matrix.txt.gz", oa=11, normal=7, n=18,
                     text="11 OA / 7 normal methylation"),
}

print("=" * 100)
print("GEO SERIES MATRICES — sample counts re-derived from the raw files on disk")
print("=" * 100)
problems = []
for acc, spec in CLAIMS.items():
    p = spec["file"]
    if not os.path.exists(p):
        print(f"{acc}: FILE MISSING {p}")
        problems.append((acc, "missing file"))
        continue
    f = matrix_facts(p)
    c = classify(f)
    ok_n = f["n_samples"] == spec["n"]
    ok_shape = f["n_cols"] == f["n_samples"]
    print(f"\n{acc}  ({os.path.getsize(p):,} bytes)  platform {f['platform']}")
    print(f"   title   : {f['title_line']}")
    print(f"   samples : {f['n_samples']} (matrix columns {f['n_cols']})  rows/probes {f['n_rows']:,}")
    print(f"   groups  : {dict(c)}")
    print(f"   claim   : {spec['text']}")
    if not ok_n:
        problems.append((acc, f"n_samples {f['n_samples']} != claimed {spec['n']}"))
    if not ok_shape:
        problems.append((acc, "column count != sample count"))
    if c.get("OA", 0) != spec["oa"]:
        problems.append((acc, f"OA {c.get('OA',0)} != claimed {spec['oa']}"))
    if c.get("Normal", 0) != spec["normal"]:
        problems.append((acc, f"Normal {c.get('Normal',0)} != claimed {spec['normal']}"))

# ---- GSE114007: its series matrix holds no data table (the values come from the two
#      submitter-normalised supplementary count files), so verify those instead.
print("\n" + "-" * 100)
print("GSE114007 — verified from the supplementary count files actually used")
tot_oa = tot_no = 0
for label, f, want in [("OA", f"{DATA}/GSE114007_OA_normalized.counts.txt.gz", 20),
                       ("normal", f"{DATA}/GSE114007_normal_normalized.counts.txt.gz", 18)]:
    if not os.path.exists(f):
        print(f"   {label}: MISSING {f}")
        problems.append(("GSE114007", f"missing {f}"))
        continue
    txt = read_gz(f)
    lines = [l for l in txt.split("\n") if l.strip()]
    hdr = [h.strip().strip('"') for h in lines[0].split("\t")]
    sample_cols = [h for h in hdr[1:] if not re.match(r"(?i)\b(average|max)\b", h)]
    print(f"   {label:6s}: {len(sample_cols):3d} sample columns (claimed {want}), "
          f"{len(lines)-1:,} gene rows, file {os.path.getsize(f):,} bytes")
    if label == "OA":
        tot_oa = len(sample_cols)
    else:
        tot_no = len(sample_cols)
    if len(sample_cols) != want:
        problems.append(("GSE114007", f"{label} columns {len(sample_cols)} != {want}"))
print(f"   total analysed: {tot_oa} OA + {tot_no} normal = {tot_oa + tot_no} "
      f"(manuscript: 20 + 18 = 38)")
if tot_oa + tot_no != 38:
    problems.append(("GSE114007", f"total {tot_oa + tot_no} != 38"))

# ---- the discovery expression matrix actually used by the pipeline
wexpr = f"{OUT}/../work/expr_GSE114007.csv"
if os.path.exists(wexpr):
    import csv as _csv
    with open(wexpr, encoding="utf-8") as fh:
        rr = list(_csv.reader(fh))
    print(f"   work/expr_GSE114007.csv: {len(rr)-1:,} genes x {len(rr[0])-1} samples")

# ---- GSE283079 (counts file, not a series matrix)
p = f"{DATA}/GSE283079_gene_count_RNAseq.txt.gz"
if os.path.exists(p):
    txt = read_gz(p)
    hdr = txt.split("\n")[0].split("\t")
    print(f"\nGSE283079  ({os.path.getsize(p):,} bytes)")
    print(f"   columns: {len(hdr)-1} samples, rows: {txt.count(chr(10))} genes")
    md = f"{OUT}/gse283079_sample_metadata.csv"
    if os.path.exists(md):
        import csv as _csv
        with open(md, encoding="utf-8") as fh:
            rr = list(_csv.DictReader(fh))
        cnt = collections.Counter(r.get("group") or r.get("trait") or "?" for r in rr)
        print(f"   metadata groups: {dict(cnt)}  (manuscript: 36 OA / 5 non-OA)")

# ---- GSE255460 single cell
p = f"{DATA}/GSE255460_metadata.csv.gz"
if os.path.exists(p):
    txt = read_gz(p)
    rows = txt.strip().split("\n")
    hdr = rows[0].split(",")
    it = hdr.index("trait")
    cnt = collections.Counter(r.split(",")[it] for r in rows[1:])
    print(f"\nGSE255460 metadata: {len(rows)-1:,} cells, trait={dict(cnt)}")
    print("   manuscript claims 135,896 cells, 134,551 analysed, 9 donors, 1 control donor")

# ---- GSE104782
p = f"{DATA}/GSE104782_allcells_UMI_count.txt.gz"
if os.path.exists(p):
    txt = read_gz(p)[:2_000_000]
    hdr = txt.split("\n", 1)[0].split("\t")
    print(f"\nGSE104782 counts header: {len(hdr)-1:,} cell columns (manuscript: 1,600 cells)")

print("\n" + "=" * 100)
print("GENETIC FILES — local integrity and remote availability")
print("=" * 100)
import subprocess
f = "data/eqtlgen_cis_eqtl_fdr05.txt.gz"
if os.path.exists(f):
    sz = os.path.getsize(f)
    with open(f, "rb") as fh:
        head = fh.read(2)
    print(f"  {f}: {sz:,} bytes, magic {head!r} "
          f"{'(gzip OK)' if head == b'\x1f\x8b' else '(NOT GZIP)'}")
    # stream the header and count rows for one signature gene
    txt = read_gz(f, limit=None) if False else None
    import gzip as _g
    n_rows = 0
    n_gene = 0
    with _g.open(f, "rt", encoding="utf-8", errors="replace") as fh:
        hdr = fh.readline().rstrip("\n").split("\t")
        print(f"     header: {hdr[:6]} ... ({len(hdr)} cols)")
        for line in fh:
            n_rows += 1
            p = line.split("\t")
            if len(p) > 8 and p[8] == "ETS2":
                n_gene += 1
    print(f"     {n_rows:,} cis-eQTL rows total; ETS2 rows {n_gene:,} "
          f"(manuscript reports 761 at FDR<0.05)")
    # persist the per-gene coverage so every number in the prose is machine-traceable
    cov = {"total_cis_eqtl_rows": n_rows, "columns": hdr, "per_gene": {}}
    want = {"ETS2", "GADD45B", "JUN", "CDKN1B", "UBC", "CDKN1A", "HLA-F", "CDK2"}
    with _g.open(f, "rt", encoding="utf-8", errors="replace") as fh:
        fh.readline()
        for line in fh:
            p = line.split("\t")
            if len(p) > 8 and p[8] in want:
                cov["per_gene"].setdefault(p[8], 0)
                cov["per_gene"][p[8]] += 1
    json.dump(cov, open(f"{OUT}/eqtlgen_coverage.json", "w"), indent=1)
    print(f"     per-gene coverage written: {cov['per_gene']}")
else:
    print(f"  {f}: MISSING")
    problems.append((f, "missing"))

print("\n  FinnGen R11 summary statistics are read remotely via tabix-over-HTTP and are never "
      "downloaded whole;")
print("  verifying the four outcome files are live and that the cached .tbi indexes match:")
for ph in ["M13_ARTHROSIS", "M13_ARTHROSIS_KNEE", "M13_ARTHTROSIS_COX",
           "M13_ARTHROSIS_KNEE_PRIM_KNEESURG"]:
    url = ("https://storage.googleapis.com/finngen-public-data-r11/summary_stats/"
           f"finngen_R11_{ph}.gz")
    p = subprocess.run(["curl", "-sSI", "-m", "45", url], capture_output=True, text=True)
    cl = [l.split(":")[1].strip() for l in p.stdout.splitlines()
          if l.lower().startswith("content-length")]
    tbi = f"data/gwas/finngen_R11_{ph}.gz.tbi"
    lok = os.path.getsize(tbi) if os.path.exists(tbi) else None
    print(f"     {ph:34s} remote {int(cl[0]):,} bytes" if cl else f"     {ph}: NO HEAD")
    print(f"     {'':34s} local .tbi {lok:,} bytes" if lok else f"     {'':34s} local .tbi MISSING")
    if not cl or not lok:
        problems.append((ph, "cannot verify"))


print(f"\nPROVENANCE PROBLEMS: {len(problems)}")
for p in problems:
    print("  ", p)
