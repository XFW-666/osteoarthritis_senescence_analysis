"""
refs_build.py — curated bibliography assembled from real PubMed records harvested with
E-utilities (refs_raw.json).  Every entry is keyed by PMID and rendered in AMA style.
"""
import json, os, re

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = json.load(open(os.path.join(BASE, "refs_raw.json"), encoding="utf8"))

# pmid -> raw record (search across all query buckets)
BY_PMID = {}
for _label, items in RAW.items():
    for r in items:
        BY_PMID.setdefault(str(r["pmid"]), r)

# additional records harvested for the causal-inference, connectivity-map and diagnostics sections
_NEW_PATH = os.path.join(BASE, "refs_new.json")
if os.path.exists(_NEW_PATH):
    for _label, items in json.load(open(_NEW_PATH, encoding="utf8")).items():
        for r in items:
            BY_PMID.setdefault(str(r["pmid"]), r)


def ama(pmid):
    r = BY_PMID[str(pmid)]
    au = r.get("authors") or []
    au = [a.strip().rstrip(".") for a in au if a and a.strip()]
    if not au:
        astr = "Anonymous"
    elif len(au) >= 3 or r.get("et_al"):
        astr = ", ".join(au[:3]) + ", et al"
    else:
        astr = ", ".join(au)
    title = (r.get("title") or "").strip().rstrip(".")
    jr = (r.get("iso") or r.get("journal") or "").strip().rstrip(".")
    yr = str(r.get("year") or "").strip()
    vol = str(r.get("volume") or "").strip()
    iss = str(r.get("issue") or "").strip()
    pg = str(r.get("pages") or "").strip()
    doi = (r.get("doi") or "").strip()
    s = f"{astr}. {title}. {jr}. {yr}"
    if vol:
        s += f";{vol}"
        if iss:
            s += f"({iss})"
    if pg:
        s += f":{pg}"
    s += "."
    if doi:
        s += f" doi:{doi}"
    return s


# --------------------------------------------------------------------------- selection
# PMIDs in citation order (Introduction -> Methods -> Results -> Discussion)
CITATION_ORDER = [
    "39948092",   # 1
    "31034380",   # 2
    "32398285",   # 3
    "34023527",   # 4
    "38642570",   # 5
    "40174718",   # 6
    "42409274",   # 7
    "39112603",   # 8
    "30496082",   # 9
    "38212040",   # 10
    "33116279",   # 11
    "36414224",   # 12
    "39427749",   # 13
    "36179981",   # 14
    "27192932",   # 15
    "38049031",   # 16
    "33208917",   # 17
    "42922297",   # 18
    "35912854",   # 19
    "38654098",   # 20
    "42502879",   # 21
    "41162753",   # 22
    "36496445",   # 23
    "38789434",   # 24
    "33227437",   # 25
    "36564153",   # 26
    "32955487",   # 27
    "40887466",   # 28
    "39627227",   # 29
    "40082724",   # 30
    "37353140",   # 31
    "22960092",   # 32
    "31982565",   # 33
    "23194896",   # 34
    "39690716",   # 35
    "39919897",   # 36
    "21216815",   # 37
    "16188468",   # 38
    "42007300",   # 39
    "24928840",   # 40
    "39938633",   # 41
    "40335469",   # 42
    "34480023",   # 43
    "33242601",   # 44
    "39343238",   # 45
    "40506462",   # 46
    "39579762",   # 47
    "33637762",   # 48
    "38325908",   # 49
    "34242803",   # 50
    "41760060",   # 51
    "40646535",   # 52
    "41709967",   # 53
    "41544746",   # 54
    "19114008",   # 55
    "37399090",   # 56
    "39558183",   # 57
    "31882993",   # 58
    "33676020",   # 59
    "26423722",   # 60
    "40337924",   # 61
    "25929973",   # 62
    "38043857",   # 63
    "41381492",   # 64
    "40075068",   # 65
    "41223767",   # 66
    "40053240",   # 67
    "42815003",   # 68
    "40611294",   # 69
    "33853636",   # 70
    "37914703",   # 71
    "40539070",   # 72
    "32913098",   # 73
    "36653562",   # 74
    "30664745",   # 75
    "26050253",   # 76
    "27061298",   # 77
    "29846171",   # 78
    "34698778",   # 79
    "17008526",   # 80
    "29195078",   # 81
    "16199517",   # 82
    "7063747",   # 83
    "34475573",   # 84
    "24830394",   # 85
]


CITATION_ORDER = [p for p in CITATION_ORDER if p in BY_PMID]


def build():
    refs = []
    for i, p in enumerate(CITATION_ORDER, 1):
        r = BY_PMID[p]
        refs.append({"n": i, "pmid": p, "text": ama(p), "title": r.get("title"),
                     "journal": r.get("iso"), "year": r.get("year"), "doi": r.get("doi")})
    return refs


if __name__ == "__main__":
    refs = build()
    json.dump(refs, open(os.path.join(BASE, "results", "references.json"), "w"), indent=1)
    print(f"{len(refs)} references\n")
    for r in refs:
        print(f"{r['n']}. [{r['pmid']}] {r['text'][:165]}")
