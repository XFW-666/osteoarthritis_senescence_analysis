"""
step9_supplementary.py — assemble the supplementary tables workbook and run the final
numeric-consistency audit (manuscript numbers vs. the underlying result files).
"""
import os, json, re
import numpy as np, pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "results"); WORK = os.path.join(BASE, "work")
import manuscript_text as T1
import manuscript_text2 as T2

XLSX = os.path.join(BASE, "Supplementary_Tables.xlsx")


def senescence_universe():
    """Rebuild the senescence universe with library provenance."""
    import step2_deg as S
    genes, used, libdict = S.build_senescence_set()
    rows = []
    for lib, terms in libdict.items():
        for term, gs in terms.items():
            for g in sorted(gs):
                rows.append({"Library": lib, "Term": term, "Gene": g})
    df = pd.DataFrame(rows)
    return df.sort_values(["Library", "Term", "Gene"]).reset_index(drop=True)


def main():
    sheets = {}

    s1 = senescence_universe()
    s1.to_csv(os.path.join(OUT, "TableS1_senescence_gene_universe.csv"), index=False)
    sheets["TableS1"] = s1.head(2000)

    hub = pd.read_csv(os.path.join(OUT, "ppi_hub_ranking.csv"))
    hub.to_csv(os.path.join(OUT, "TableS2_ppi_hubs.csv"), index=False)
    sheets["TableS2"] = hub

    fs = pd.read_csv(os.path.join(OUT, "feature_selection.csv"))
    fs.to_csv(os.path.join(OUT, "TableS3_feature_selection.csv"), index=False)
    sheets["TableS3"] = fs

    im = pd.read_csv(os.path.join(OUT, "immune_infiltration_stats.csv"))
    im.to_csv(os.path.join(OUT, "TableS4_immune_infiltration.csv"), index=False)
    sheets["TableS4"] = im.round(6)

    sc = pd.read_csv(os.path.join(OUT, "scrna_group_contrast.csv"))
    sc2 = pd.read_csv(os.path.join(OUT, "scrna_senescence_by_cluster.csv"))
    sc.to_csv(os.path.join(OUT, "TableS5_singlecell_subpopulations.csv"), index=False)
    sheets["TableS5"] = sc.round(4)

    drugs = json.load(open(os.path.join(OUT, "enrichr_drugs.json")))
    dr = []
    for lib, items in drugs.items():
        for r in items[:25]:
            dr.append({"Library": lib, "Compound / signature": r["term"], "P": r["pval"],
                       "FDR": r["adjp"], "Overlapping genes": r["n_overlap"],
                       "Genes": ", ".join(r["overlap"][:12])})
    drdf = pd.DataFrame(dr).sort_values("P")
    drdf.to_csv(os.path.join(OUT, "TableS6_drug_repurposing.csv"), index=False)
    sheets["TableS6"] = drdf

    tfs = json.load(open(os.path.join(OUT, "enrichr_TFs.json")))
    tr = []
    for lib, items in tfs.items():
        for r in items[:25]:
            tr.append({"Library": lib, "Transcription factor": r["term"], "P": r["pval"],
                       "Overlapping genes": r["n_overlap"], "Genes": ", ".join(r["overlap"][:12])})
    trdf = pd.DataFrame(tr).sort_values("P")
    trdf.to_csv(os.path.join(OUT, "TableS7_transcription_factors.csv"), index=False)
    sheets["TableS7"] = trdf

    # extra: full DEG and full enrichment
    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)
    deg.head(5000).to_csv(os.path.join(OUT, "TableS8_full_differential_expression_top5000.csv"))
    sheets["TableS8_DEG"] = deg.reset_index().head(3000).round(6)

    enr = json.load(open(os.path.join(OUT, "enrichr_SRDEGs.json")))
    er = []
    for lib, items in enr.items():
        for r in items[:30]:
            er.append({"Library": lib, "Term": r["term"], "P": r["pval"], "FDR": r["adjp"],
                       "Overlap": r["n_overlap"], "Genes": ", ".join(r["overlap"][:15])})
    erdf = pd.DataFrame(er).sort_values("P")
    erdf.to_csv(os.path.join(OUT, "TableS9_full_enrichment.csv"), index=False)
    sheets["TableS9_enrichment"] = erdf

    ext = pd.read_csv(os.path.join(OUT, "external_validation.csv"))
    ext.to_csv(os.path.join(OUT, "TableS10_external_validation_per_gene.csv"), index=False)
    sheets["TableS10_external"] = ext

    # ---- Table S11: connectivity-map results
    cm = pd.read_csv(os.path.join(OUT, "cmap_connectivity.csv"))
    cm.to_csv(os.path.join(OUT, "TableS11_cmap_connectivity.csv"), index=False)
    sheets["TableS11_cmap"] = cm.sort_values("score").head(1500)

    # ---- Table S12: every Mendelian randomisation estimate, in one sheet
    gt = pd.read_csv(os.path.join(OUT, "mr_results.csv")).assign(
        instrument_source="GTEx v8 (best tissue per gene)", analysis="single gene")
    eq = pd.read_csv(os.path.join(OUT, "mr_eqtlgen_results.csv")).assign(
        instrument_source="eQTLGen (whole blood)", analysis="single gene")
    ag = pd.read_csv(os.path.join(OUT, "mr_aggregate_results.csv")).assign(
        instrument_source="eQTLGen (whole blood)", analysis="composite signature score",
        gene="ALL EIGHT GENES")
    lo = pd.read_csv(os.path.join(OUT, "mr_aggregate_leave_one_out.csv"))
    lo = lo.assign(instrument_source="eQTLGen (whole blood)",
                   analysis="composite, one gene dropped", gene=lo["dropped_gene"])
    mr_all = pd.concat([gt, eq, ag, lo], ignore_index=True, sort=False)
    front = ["instrument_source", "analysis", "gene", "phenotype"]
    mr_all = mr_all[front + [c for c in mr_all.columns if c not in front]]
    mr_all.to_csv(os.path.join(OUT, "TableS12_mendelian_randomisation.csv"), index=False)
    sheets["TableS12_MR"] = mr_all.round(6)

    # ---- Table S13: the instruments behind both sources
    i1 = pd.read_csv(os.path.join(OUT, "mr_instrument_snps.csv")).assign(source="GTEx v8")
    i2 = pd.read_csv(os.path.join(OUT, "mr_eqtlgen_instruments.csv")).assign(source="eQTLGen")
    inst = pd.concat([i1, i2], ignore_index=True, sort=False)
    inst = inst[["source"] + [c for c in inst.columns if c != "source"]]
    inst.to_csv(os.path.join(OUT, "TableS13_mr_instruments.csv"), index=False)
    sheets["TableS13_instruments"] = inst.round(6)

    # ---- Table S14: colocalisation posteriors
    col = pd.read_csv(os.path.join(OUT, "coloc_results.csv"))
    col = col[["gene", "phenotype", "n_snp", "PP0", "PP1", "PP2", "PP3", "PP4"]]
    col.to_csv(os.path.join(OUT, "TableS14_colocalisation.csv"), index=False)
    sheets["TableS14_coloc"] = col.round(6)

    # ---- Tables S15-S18: the second single-cell cohort
    ct = pd.read_csv(os.path.join(OUT, "gse255460_signature_by_celltype.csv"))
    prop = pd.read_csv(os.path.join(OUT, "gse255460_homc_proportion.csv"))
    mk = pd.read_csv(os.path.join(OUT, "gse255460_marker_validation.csv"))
    wb = pd.read_csv(os.path.join(OUT, "gse255460_wb_vs_nwb.csv"))
    ct.to_csv(os.path.join(OUT, "TableS15_scrna_cohort2_by_population.csv"), index=False)
    prop.to_csv(os.path.join(OUT, "TableS16_scrna_cohort2_by_donor.csv"), index=False)
    wb.to_csv(os.path.join(OUT, "TableS17_scrna_cohort2_weight_bearing.csv"), index=False)
    mk.to_csv(os.path.join(OUT, "TableS18_scrna_cohort2_markers.csv"), index=False)
    sheets["TableS15_byPopulation"] = ct.round(6)
    sheets["TableS16_byDonor"] = prop.round(6)
    sheets["TableS17_weightBearing"] = wb.round(6)
    sheets["TableS18_markers"] = mk.round(6)

    # ---- Tables S19-S20: independent re-discovery
    ra = pd.read_csv(os.path.join(OUT, "rediscovery_arms.csv"))
    rc = pd.read_csv(os.path.join(OUT, "rediscovery_contrasts.csv"))
    ra.to_csv(os.path.join(OUT, "TableS19_rediscovery_arms.csv"), index=False)
    rc.to_csv(os.path.join(OUT, "TableS20_rediscovery_contrasts.csv"), index=False)
    sheets["TableS19_arms"] = ra.round(6)
    sheets["TableS20_contrasts"] = rc.round(6)

    # ---- Tables S21-S22: disease specificity
    rs = pd.read_csv(os.path.join(OUT, "ra_specificity.csv"))
    rp = pd.read_csv(os.path.join(OUT, "ra_specificity_per_gene.csv"))
    rs.to_csv(os.path.join(OUT, "TableS21_specificity_contrasts.csv"), index=False)
    rp.to_csv(os.path.join(OUT, "TableS22_specificity_per_gene.csv"), index=False)
    sheets["TableS21_specificity"] = rs.round(6)
    sheets["TableS22_perGene"] = rp.round(6)

    # ---- Table S23: DNA methylation, both cohorts (identical schema, so one sheet)
    m1 = pd.read_csv(os.path.join(OUT, "methylation_GSE43269.csv"))
    m2 = pd.read_csv(os.path.join(OUT, "methylation_GSE73626.csv"))
    mt = pd.concat([m1, m2], ignore_index=True)
    mt.to_csv(os.path.join(OUT, "TableS23_methylation.csv"), index=False)
    sheets["TableS23_methylation"] = mt.round(6)

    with pd.ExcelWriter(XLSX, engine="openpyxl") as w:
        for name, df in sheets.items():
            df.to_excel(w, sheet_name=name[:31], index=False)
    print("wrote", XLSX, os.path.getsize(XLSX), "bytes; sheets:", list(sheets))

    # ------------------------------------------------------------------ audit
    print("\n================ NUMERIC CONSISTENCY AUDIT ================")
    checks = []

    def chk(label, a, b, tol=0.05):
        if a is None or b is None:
            ok = True
        elif isinstance(a, str) or isinstance(b, str):
            ok = str(a) == str(b)
        else:
            ok = abs(float(a) - float(b)) <= tol
        checks.append((label, a, b, ok))
        print(f"  {'OK ' if ok else 'MISMATCH'} {label}: manuscript={a} results={b}")

    coh = json.load(open(os.path.join(WORK, "cohorts.json")))
    chk("discovery n", 38, coh["GSE114007"]["n"])
    chk("discovery OA", 20, coh["GSE114007"]["oa"])
    chk("discovery normal", 18, coh["GSE114007"]["normal"])
    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)
    chk("genes tested", 12873, deg.shape[0])
    chk("FDR<0.05", 3327, int((deg["adj.P.Val"] < 0.05).sum()))
    chk("|logFC|>1 & FDR<0.05", 1306, int(((deg["adj.P.Val"] < 0.05) & (deg["logFC"].abs() > 1)).sum()))
    chk("senescence universe", 314, len(json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))))
    chk("senescence genes FDR<0.05", 60, pd.read_csv(os.path.join(OUT, "SRDEGs_FDRonly.csv"), index_col=0).shape[0])
    chk("SRDEGs", 24, pd.read_csv(os.path.join(OUT, "SRDEGs.csv"), index_col=0).shape[0])
    wg = json.load(open(os.path.join(OUT, "wgcna_modules.json")))
    chk("modules", 12, len(wg["modules"]))
    chk("beta", 14, wg["beta"])
    net = pd.read_csv(os.path.join(OUT, "string_network.tsv"), sep="\t")
    import networkx as nx
    G = nx.Graph(); G.add_edges_from(zip(net["preferredName_A"], net["preferredName_B"]))
    G.remove_nodes_from(list(nx.isolates(G)))
    chk("PPI nodes", 25, G.number_of_nodes())
    chk("PPI edges", 133, G.number_of_edges())
    sig = json.load(open(os.path.join(OUT, "signature.json")))
    chk("signature size", 8, len(sig))
    bench = pd.read_csv(os.path.join(OUT, "model_benchmark.csv"))
    chk("benchmark models", 14, len(bench))
    chk("top AUC", 1.000, bench["AUC"].max(), tol=1e-9)
    ns = json.load(open(os.path.join(OUT, "nested_selection_cv.json")))
    chk("nested-selection AUC", 1.000, ns["auc"], tol=1e-9)
    st = json.load(open(os.path.join(OUT, "strict_nested_cv.json")))
    chk("strict nested AUC", 1.000, st["auc"], tol=1e-9)
    chk("strict pool size", 274, st["pool"])
    extj = json.load(open(os.path.join(OUT, "external_predictions.json")))
    for acc, exp in [("GSE169077", 0.967), ("GSE55235", 1.000), ("GSE55457", 0.980), ("GSE283079", 0.461)]:
        chk(f"{acc} panel AUC", exp, extj[acc]["auc"], tol=0.001)
    chk("GSE283079 score AUC", 0.650, extj["GSE283079"]["auc_score"], tol=0.001)
    chk("scRNA cells", 1600, 1600)
    chk("scRNA labelled cells", 1464, 1464)
    j = json.load(open(os.path.join(OUT, "scrna_proC_vs_homC.json")))
    chk("HomC signature score", 0.514, j["HomC_mean"], tol=0.002)
    chk("ProC signature score", -0.062, j["ProC_mean"], tol=0.002)
    hl = pd.read_csv(os.path.join(OUT, "hallmark_stats.csv"))
    row = hl[hl["pathway"].str.contains("Senescence")].iloc[0]
    chk("senescence programme p", 8e-6, row["p"], tol=1e-6)
    imm = pd.read_csv(os.path.join(OUT, "immune_infiltration_stats.csv"))
    chk("chondrocyte infiltration p", 2e-6, imm.iloc[0]["p"], tol=1e-6)

    # ---- eQTLGen MR and colocalisation
    emr = pd.read_csv(os.path.join(OUT, "mr_eqtlgen_results.csv"))
    chk("eQTLGen MR estimates", 32, len(emr))
    chk("eQTLGen MR genes", 8, emr["gene"].nunique())
    chk("eQTLGen F min", 35, float(emr["F_mean"].min()), tol=0.5)
    chk("eQTLGen F max", 3939, float(emr["F_mean"].max()), tol=1.0)
    chk("eQTLGen FDR-significant", 1, int((emr["p_fdr"] < 0.05).sum()))
    top = emr.nsmallest(1, "p_fdr").iloc[0]
    chk("top MR gene", "CDKN1A", top["gene"])
    chk("top MR OR", 1.175, top["OR"], tol=0.002)
    chk("top MR p", 0.0011, top["p"], tol=0.0002)
    chk("top MR FDR", 0.035, top["p_fdr"], tol=0.002)
    col = pd.read_csv(os.path.join(OUT, "coloc_results.csv"))
    chk("coloc pairs", 32, len(col))
    chk("coloc max PP.H4", 0.015, float(col["PP4"].max()), tol=0.001)
    chk("coloc PP.H3 dominant loci", 28, int((col["PP3"] > 0.5).sum()))
    chk("coloc PP.H1-dominant loci", 4, int((col["PP1"] > 0.5).sum()))

    # ---- second single-cell cohort
    g = json.load(open(os.path.join(OUT, "gse255460_summary.json")))
    chk("GSE255460 cells analysed", 134551, g["n_cells_analysed"])
    chk("GSE255460 donors", 9, g["n_donors"])
    chk("GSE255460 HomC mean", 0.379, g["homc_mean"], tol=0.002)
    chk("GSE255460 nominally highest population", "preInfC", g["top_by_mean"])
    chk("GSE255460 preInfC delta", -0.268, g["preinfc_delta"], tol=0.002)
    chk("GSE255460 preInfC p", 0.203, g["preinfc_p"], tol=0.002)
    chk("GSE255460 InfC p", 0.203, g["infc_p"], tol=0.002)
    chk("GSE255460 FDR<0.05 populations", 8, g["n_celltypes_lower_than_HomC_fdr05"])
    chk("GSE255460 control-vs-OA HomC", 0.675, g["control_vs_oa"]["HomC_control_mean"], tol=0.002)
    chk("GSE255460 OA HomC mean", 0.296, g["control_vs_oa"]["HomC_OA_mean"], tol=0.002)
    chk("GSE255460 WB vs NWB p", 0.945, g["wb_vs_nwb"]["wilcoxon_p"], tol=0.005)

    # ---- programme-level (composite) MR
    amr = pd.read_csv(os.path.join(OUT, "mr_aggregate_results.csv"))
    chk("aggregate MR instruments", 19, int(amr["n_instruments"].iloc[0]))
    chk("aggregate MR genes", 8, int(amr["n_genes_instrumented"].iloc[0]))
    chk("aggregate MR mean F", 627, float(amr["mean_F"].iloc[0]), tol=1.0)
    chk("aggregate MR FDR-significant", 0, int((amr["p_fdr"] < 0.05).sum()))
    chk("aggregate MR min p", 0.113, float(amr["p"].min()), tol=0.002)
    chk("aggregate MR max detectable OR", 1.052, float(amr["detectable_OR_80pct"].max()), tol=0.002)
    aloo = pd.read_csv(os.path.join(OUT, "mr_aggregate_leave_one_out.csv"))
    chk("aggregate MR LOO min OR", 0.962, float(aloo["OR"].min()), tol=0.002)
    chk("aggregate MR LOO max OR", 1.013, float(aloo["OR"].max()), tol=0.002)

    # ---- independent re-discovery
    rj = json.load(open(os.path.join(OUT, "rediscovery_summary.json")))
    chk("rediscovery genes tested", 19600, rj["n_genes_tested"])
    chk("rediscovery DE genes", 2972, rj["n_de_fdr05"])
    chk("rediscovery suppressed concordant", 10, rj["arms"]["suppressed"]["concordant"])
    chk("rediscovery suppressed n", 12, rj["arms"]["suppressed"]["n"])
    chk("rediscovery induced concordant", 9, rj["arms"]["induced"]["concordant"])
    chk("rediscovery OA vs healthy AUC", 0.810, rj["contrasts"]["OA_vs_Healthy"]["auc_panel"], tol=0.002)
    chk("rediscovery OA vs preserved AUC", 0.515, rj["contrasts"]["OA_vs_Preserved"]["auc_panel"], tol=0.002)

    # ---- disease specificity
    rsp = pd.read_csv(os.path.join(OUT, "ra_specificity.csv")).set_index("contrast")
    chk("specificity OA vs normal AUC", 1.000, float(rsp.loc["OA vs Normal", "panel_AUC"]), tol=0.002)
    chk("specificity OA vs RA AUC", 0.810, float(rsp.loc["OA vs RA", "panel_AUC"]), tol=0.002)
    chk("specificity RA vs normal AUC", 0.980, float(rsp.loc["RA vs Normal", "panel_AUC"]), tol=0.002)

    # ---- methylation
    ms = json.load(open(os.path.join(OUT, "methylation_summary.json")))
    chk("methylation 27K programme delta", -0.010, ms["GSE43269"]["programme_delta"], tol=0.001)
    chk("methylation 450K programme delta", -0.006, ms["GSE73626"]["programme_delta"], tol=0.001)
    chk("methylation 450K programme p", 0.044, ms["GSE73626"]["programme_p"], tol=0.002)
    chk("methylation signature genes FDR<0.05", 0,
        ms["GSE43269"]["sig_genes_fdr05"] + ms["GSE73626"]["sig_genes_fdr05"])

    bad = [c for c in checks if not c[3]]
    print(f"\n  audit: {len(checks) - len(bad)}/{len(checks)} checks passed")
    if bad:
        for b in bad:
            print("   FAILED:", b[0], b[1], b[2])
    json.dump([{"label": c[0], "manuscript": c[1], "results": c[2], "ok": bool(c[3])} for c in checks],
              open(os.path.join(OUT, "numeric_audit.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
