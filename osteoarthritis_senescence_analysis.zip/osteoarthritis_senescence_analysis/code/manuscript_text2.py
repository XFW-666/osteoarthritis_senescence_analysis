"""manuscript_text2.py — Results, Discussion, Conclusion, statements, tables and figure legends."""

RESULTS = [
    ("Cohort characteristics and transcriptomic landscape", [
        ("Five bulk cohorts and two single-cell cohorts were analysed (Table 1). The discovery cohort "
         "(GSE114007) comprised 20 end-stage OA (Kellgren-Lawrence grade 4) and 18 normal (grade 1) cartilage "
         "samples profiled by RNA-sequencing; ages ranged from 18 to 82 years and both sexes were represented. "
         "External cohorts spanned two tissues (cartilage and synovium) and two platforms (RNA-sequencing and "
         "Affymetrix HG-U133A microarray), providing a deliberately heterogeneous test bed for the derived "
         "signature."
         "After expression filtering, 12,873 genes were retained in the discovery cohort. Unsupervised "
         "principal component analysis of the 2,000 most variable genes showed partial but incomplete "
         "separation of OA and normal samples (Figure 2B), indicating that disease status is a major, though "
         "not the only, source of transcriptomic variance. Differential expression analysis identified 3,327 "
         "genes at FDR < .05, of which 1,306 also showed |log2 fold change| > 1 (Figure 2A, Table 2, full "
         "list in Table S8). The "
         "moderated t-statistics were large, with absolute values up to 12.4, reflecting the advanced disease "
         "stage of the OA samples."),
    ]),
    ("The senescence programme is extensively and non-uniformly remodelled in OA cartilage", [
        ("The curated senescence universe comprised 314 genes (Table S1). Of these, 274 were detected in the "
         "discovery matrix and 60 were differentially expressed at FDR < .05; 24 additionally satisfied the "
         "stringent |log2 fold change| > 1 criterion and were designated senescence-related differentially "
         "expressed genes (SRDEGs; Figure 2F, Table 2)."
         "The SRDEGs were not uniformly up-regulated in OA. Instead, two coherent and opposite arms were "
         "evident. The first arm, comprising the p53/p21 checkpoint and activator protein-1 (AP-1) "
         "stress-response genes, was markedly suppressed in OA cartilage: JUN (log2 fold change -3.06), "
         "CDKN1A/p21 (-3.00), GADD45B (-2.93), FOS (-2.19), ETS2 (-2.14), GADD45A (-1.93), UBC (-1.62), "
         "CEBPB (-1.45), CDKN1B/p27 (-1.30), RELA (-1.30), MYC (-1.25) and FOXO3 (-1.13) were all "
         "significantly reduced. The second arm was induced: IGFBP3 (+3.29), CCND1 (+2.03), TWIST1 (+1.89), "
         "CCNA2 (+1.69), CDK6 (+1.68), CDKN2B/p15 (+1.53), EZH2 (+1.29), TFDP1 (+1.06) and FOXM1 (+0.94) were "
         "all up-regulated. Across the wider set of 60 senescence genes, the same pattern held (Figure 2F)."
         "At the level of programme activity, the tissue-level senescence score was significantly higher in OA "
         "than in normal cartilage (ssGSEA; P = 8 x 10^-6, rank-biserial effect size 0.85; Figure 2C), "
         "confirming that the senescence programme as a whole is activated in end-stage OA even though "
         "individual checkpoint components are lost."),
    ]),
    ("Co-expression modules associated with disease status", [
        ("Weighted co-expression analysis of the 4,000 most variable genes used a soft-thresholding power of "
         "14 (scale-free topology fit R2 = 0.88) and resolved 12 modules (Figure 3). Ten modules correlated "
         "significantly with disease status, with Pearson correlations between module eigengene and OA status "
         "ranging from -0.87 to +0.86 (all P < .01; Figure 3E). The module most strongly associated with OA "
         "contained 141 genes and correlated positively with disease (r = +0.86), while a 89-gene module "
         "correlated negatively (r = -0.87), consistent with coordinated up- and down-regulation of distinct "
         "biological programmes. Nineteen senescence-universe genes were located within OA-associated modules "
         "(Figure 3D), providing an independent, network-based line of evidence that converged with the "
         "differential expression results."),
    ]),
    ("Functional enrichment converges on senescence, cell-cycle control and SASP signalling", [
        ("Over-representation analysis of the 24 SRDEGs was performed across six curated libraries (Figure 4, "
         "Table 3; complete results in Table S9). The strongest signals were for cellular senescence in Reactome (P = 3.6 x 10^-26, "
         "15 of 24 genes) and KEGG (P = 5.5 x 10^-22, 13 of 24 genes), and for the SASP in Reactome "
         "(P = 1.3 x 10^-18, 10 of 24 genes). Cell-cycle control dominated the Gene Ontology results, with "
         "G1/S phase transition (P = 3.0 x 10^-11, 6 of 24) and regulation of cyclin-dependent protein kinase "
         "activity (P = 3.4 x 10^-11, 6 of 24) as the leading terms. In the MSigDB hallmark library, "
         "tumour-necrosis-factor-alpha signalling via NF-kB (P = 1.7 x 10^-16, 11 of 24), apoptosis "
         "(P = 5.9 x 10^-10) and the p53 pathway (P = 1.1 x 10^-7) were enriched. WikiPathways and Reactome "
         "independently returned cell-cycle and cellular-response-to-stress terms. Taken together, the "
         "enrichment profile places the differential signature squarely within senescence, cell-cycle "
         "re-entry and inflammatory secretome biology."),
    ]),
    ("Protein-protein interaction network and topological hubs", [
        ("STRING interactions among the 24 SRDEGs and the 19 module-embedded senescence genes yielded a "
         "network of 25 nodes and 133 edges (Figure 5A). Ranking nodes by the sum of their ranks across degree, "
         "betweenness, closeness and maximal clique centrality identified MYC (degree 19), JUN (18), CDKN1A "
         "(18), FOS (16), CCND1 (16), EZH2 (15), CCNA2 (13), CDKN1B (13) and FOXO3 (13) as the most "
         "topologically dominant genes (Figure 5B, Table S2). The network hubs therefore consisted of "
         "transcription factors and cell-cycle regulators rather than structural matrix genes, which is "
         "consistent with a regulatory rather than a purely catabolic role for the senescence programme in "
         "end-stage disease."),
    ]),
    ("A three-algorithm consensus signature", [
        ("The candidate pool for machine learning comprised the 60 senescence genes differentially expressed "
         "at FDR < .05 together with the top 15 interaction hubs (60 unique genes). LASSO stability "
         "selection, support-vector-machine recursive feature elimination and random-forest importance "
         "converged on a consensus of eight genes selected by at least two of the three algorithms: ETS2, "
         "GADD45B, JUN, CDKN1B, UBC, CDKN1A, HLA-F and CDK2 (Figure 6E-F, Table S3). Every gene in the "
         "signature was down-regulated in OA cartilage, with individual log2 fold changes between -0.79 and "
         "-3.06, and logistic regression coefficients ranging from -0.44 to -0.81 (Table 4). ETS2 and GADD45B "
         "were the most stable features, selected in 96% and 74% of LASSO resamples respectively."
         "The signature genes were strongly and inversely correlated with the tissue-level "
         "senescence-programme score (Pearson r from -0.36 to -0.70; all P < .03), confirming that they "
         "capture the suppressed checkpoint arm of the senescence programme rather than global senescence "
         "burden."),
    ]),
    ("Model benchmarking under nested cross-validation", [
        ("Fourteen classifiers were benchmarked with hyperparameters tuned in an inner 5-fold loop and performance estimated on outer folds repeated five times (Figure 6A-C, Table 5). Twelve achieved an AUC of 1.000 (95% CI 1.000-1.000); XGBoost achieved 0.946 (95% CI 0.812-1.000) and LightGBM 0.414 (95% CI 0.239-0.609), the latter reflecting degenerate probability estimates from the default leaf-size regularisation on this small, fully separable data set rather than a failure of discrimination."
         "Complete separation was expected given the very large moderated t-statistics, and two sensitivity analyses confirmed that it was not an artefact of feature selection. When LASSO selection was repeated inside every training fold the AUC remained 1.000, with ETS2 and GADD45B retained in 50 and 35 of 50 folds; when the candidate pool was widened to all 274 senescence-universe genes detected in the discovery matrix, removing the differential-expression pre-filter, the AUC was again 1.000, with ETS2, GADD45B and JUN most frequently retained. The signature is therefore highly robust within the discovery cohort."),
    ]),
    ("External validation across tissues and platforms", [
        ("The frozen signature was applied unchanged to four independent cohorts after within-cohort "
         "standardisation (Figure 7F, Table 6). Discrimination was retained in three cohorts: GSE169077 "
         "(cartilage microarray, 6 OA vs 5 normal) achieved an AUC of 0.967 (95% CI 0.800-1.000), GSE55235 "
         "(synovial microarray, 10 vs 10) an AUC of 1.000 (95% CI 1.000-1.000), and GSE55457 (synovial "
         "microarray, 10 vs 10) an AUC of 0.980 (95% CI 0.917-1.000). The tissue-level senescence-programme "
         "score performed similarly or better in these cohorts (GSE169077 AUC 1.000; GSE55235 AUC 1.000; "
         "GSE55457 AUC 0.980)."),
        ("In contrast, the signature did not discriminate in GSE283079, the synovial RNA-sequencing cohort "
         "(AUC 0.461, 95% CI 0.294-0.628), although the senescence-programme score showed partial "
         "discrimination (AUC 0.650, 95% CI 0.423-0.854). This cohort differs from the others in two "
         "important respects: it contains only five non-OA samples against 36 OA samples, so the AUC is "
         "estimated from a very small comparison group, and its case definition for non-OA synovium is "
         "broader than in the microarray cohorts. Direction consistency of individual signature genes "
         "paralleled these results: 5 of 5 genes (100%) were concordant in GSE169077 and GSE55457, 4 of 5 "
         "(80%) in GSE55235, and only 3 of 8 (37.5%) in GSE283079 (Table 6; per-gene results in Table S10)."
         "Platform coverage explains part of the difference in gene numbers: the partial HG-U133A annotation "
         "mapped five of the eight signature genes, whereas all eight were available in the RNA-sequencing "
         "cohorts. Taken together, the external results indicate that the cartilage-derived checkpoint "
         "signature transfers robustly to independent microarray cohorts from both cartilage and synovium, "
         "but that its performance is not guaranteed in small, highly imbalanced RNA-sequencing cohorts."),
    ]),
    ("Immune and stromal landscape and pathway activity", [
        ("Cell-type deconvolution of the discovery cohort with a curated panel of 19 immune and stromal "
         "populations showed lower scores for chondrocytes (P = 2 x 10^-6), macrophages (P = 2 x 10^-6), "
         "fibroblasts (P = 2 x 10^-6), neutrophils (P = 3 x 10^-6), regulatory T cells (P = 1.8 x 10^-5), "
         "T cells (P = 5.1 x 10^-5), monocytes (P = 3.1 x 10^-4) and dendritic cells (P = 4.4 x 10^-3) in OA "
         "cartilage than in normal cartilage (Figure 8A-B, Table S4). Because bulk expression conflates "
         "per-cell transcription with tissue cellularity, this global reduction is most parsimoniously "
         "interpreted as reflecting the hypocellularity of end-stage OA cartilage, in which chondrocyte loss "
         "is a well-documented feature."),
        ("Hallmark pathway scoring showed higher senescence-programme activity (P = 8 x 10^-6), apoptosis "
         "(P = 4.5 x 10^-5), E2F targets (P = 5.1 x 10^-5), G2-M checkpoint (P = 4.8 x 10^-4) and p53 pathway "
         "activity (P = 1.0 x 10^-3) in OA cartilage, and lower complement system activity (P = 1.2 x 10^-5). "
         "Interleukin-6/JAK/STAT3 signalling, the inflammatory response and interferon responses did not "
         "differ significantly between groups. This pattern reinforces the notion of a programme in which "
         "cell-cycle and apoptotic machinery is mobilised while the checkpoint and AP-1 arms are suppressed, "
         "and it argues against a simple global inflammatory activation in cartilage at this disease stage."),
    ]),
    ("Single-cell localisation of the signature is reproducible across two independent cohorts", [
        ("Two independent single-cell atlases were interrogated (Figure 8F-H). The first (GSE104782) profiled "
         "1,600 cells from 10 patients with OA, of which 1,464 carried subpopulation labels; the second "
         "(GSE255460) profiled 135,896 cells from nine donors, eight with OA and one without, of which "
         "134,551 matched the deposited cell annotations. In the first cohort the signature score was highest "
         "in homeostatic chondrocytes (mean 0.514) and lowest in hypertrophic (-0.266) and pre-hypertrophic "
         "(-0.144) chondrocytes, with proliferative chondrocytes intermediate (-0.062); the difference "
         "between homeostatic and proliferative chondrocytes was highly significant (P = 2.0 x 10^-39). "
         "Ranking subpopulations by senescence-programme activity gave the same ordering, with homeostatic "
         "chondrocytes highest (0.077) and hypertrophic chondrocytes lowest (-0.038; Table S5)."),
        ("The second cohort reproduced this ordering in an unrelated patient population and, unlike the "
         "first, contains a normal control arm. Homeostatic chondrocytes scored 0.379 (Table S15) and were "
         "significantly higher than eight of the other ten annotated populations (Wilcoxon signed-rank on "
         "per-donor means paired across the eight osteoarthritic donors, FDR = .005; Figure 8H). The two "
         "populations that did not separate from homeostatic chondrocytes were also the two smallest in the "
         "atlas: inframmatory chondrocytes (1,498 cells, homeostatic minus inframmatory = +0.13, P = .20) "
         "and pre-inframmatory chondrocytes (531 cells, delta = -0.27, P = .20). The pre-inframmatory "
         "population is the only one whose mean score was nominally higher than that of homeostatic "
         "chondrocytes, but with 531 cells across nine donors it is too sparsely sampled to interpret, and "
         "we do not treat it as evidence against the localisation."),
        ("Two further observations bear on specificity. First, the fraction of cells annotated as homeostatic "
         "chondrocytes was roughly twice as high in the control donor as in the osteoarthritic donors "
         "(28.4% versus 9.7-18.7%; Table S16), and the signature score within homeostatic chondrocytes was "
         "likewise "
         "higher in the control donor (0.68 versus 0.30; Cliff's delta 0.59). The control arm is a single "
         "donor, so this contrast is descriptive and donor-confounded rather than inferential, and we do not "
         "treat it as a test. Second, within the osteoarthritic donors the signature did not differ between "
         "weight-bearing and non-weight-bearing cartilage (delta = -0.008, P = .95; Table S17), which argues "
         "that the "
         "localisation is not a mechanical-loading artefact."),
        ("The supplied population labels were partly validated with canonical markers (Table S18). "
         "Hypertrophic chondrocytes were recovered by IBSP (AUC 0.90) and COL10A1 (0.82), fibrochondrocytes "
         "by COL1A2 (0.91) and COL1A1 (0.88), and inframmatory chondrocytes by CXCL8 and CCL2 (0.69 each). "
         "Two labels could not be validated in this matrix because their canonical markers were essentially "
         "undetected - proliferation markers in the proliferative population and endothelial markers in the "
         "effector population were absent from at least 99.7% of cells - so those two annotations remain "
         "dependent on the original authors' labelling. Across both cohorts, the signature marks the "
         "homeostatic chondrocyte state whose depletion characterises osteoarthritic cartilage, and is lost "
         "as chondrocytes adopt hypertrophic and pre-hypertrophic fates."),
    ]),
    ("Candidate senescence-directed therapeutics and upstream regulators", [
        ("Over-representation analysis of the signature genes against drug-perturbation libraries nominated "
         "luteolin (P = 4.0 x 10^-10), alvocidib (P = 4.4 x 10^-9), curcumin (P = 8.8 x 10^-9), ritonavir "
         "(P = 9.5 x 10^-9) and the cyclo-oxygenase-2 inhibitor NS-398 (P = 1.2 x 10^-8) in DSigDB, and "
         "quercetin, the canonical senolytic flavonoid, among down-regulated drug perturbations in GEO "
         "(P = 1.7 x 10^-4; Figure 8D, Table S6). Alvocidib is a cyclin-dependent kinase inhibitor, which is "
         "mechanistically consistent with the cell-cycle re-entry arm of the signature. Upstream regulator "
         "analysis implicated ATF3, the AP-1 family member that heterodimerises with JUN, together with "
         "HDAC1/HDAC3, MYC, SMAD4 and NCOR1 (Figure 8E, Table S7)."),
        ("A connectivity-map analysis asked a stricter question: which compounds reverse the osteoarthritic "
         "programme rather than merely targeting its genes (Figure 9C-D, Table S11). Across 6,519 compounds "
         "in LINCS L1000, 1,309 in the original Connectivity Map and 351 in the GEO drug-perturbation "
         "collection, the leading reversers were withaferin A, celastrol, chelerythrine and the checkpoint "
         "kinase inhibitors LY2603618 and PF-477736. The analysis recovered known senescence-directed agents "
         "as an internal positive control: piperlongumine ranked in the 96th percentile, resveratrol in the "
         "95th and quercetin in the 84th percentile of the Connectivity Map collection, and rapamycin "
         "(94th), MK-2206 (91st) and dasatinib (83rd) in LINCS L1000. Because the framework recovers drugs "
         "whose senolytic or senomorphic activity is independently established, the compounds it ranks more "
         "highly are credible candidates for testing rather than artefacts of the signature."),
    ]),
    ("Mendelian randomisation and colocalisation do not establish a causal role for the signature genes", [
        ("Cis-eQTL instruments were taken from eQTLGen, which provides whole-blood cis-eQTLs in up to 31,684 "
         "individuals, and all eight signature genes had instruments available (from 11,094 cis-eQTLs at "
         "FDR < .05 for HLA-F and 761 for ETS2 down to 19 for UBC). After restriction to P < 5 x 10^-8 and "
         "clumping at 250 kb, one to seven independent instruments remained per gene (Table S13), giving "
         "32 gene-outcome estimates against four FinnGen R11 osteoarthritis phenotypes. Mean F statistics ranged from 35 to "
         "3,939, so every instrument set was strong (Figure 9A, Table S12)."),
        ("One of the 32 estimates survived Benjamini-Hochberg control at 5%: genetically predicted CDKN1A expression was associated with knee-replacement surgery (OR 1.17 per standard deviation, 95% CI 1.07-1.29, P = .0011, FDR = .035). Four further estimates were nominally significant only, including the same gene against knee osteoarthritis (OR 1.11, P = .0033), JUN against arthrosis at all sites (OR 1.06, P = .0065), CDK2 against knee-replacement surgery in the protective direction (OR 0.70, P = .0061) and CDKN1A against arthrosis at all sites (OR 1.07, P = .024), all at FDR = .052. Where MR-Egger intercepts could be estimated they were close to zero (JUN 0.004, CDKN1A 0.003), giving no signal of directional pleiotropy, and the design could detect odds ratios of 1.02 to 1.45 depending on the gene."),
        ("Formal colocalisation then asked whether the expression and osteoarthritis signals in each locus "
         "share a causal variant. At none of the 32 gene-phenotype pairs did the posterior probability of a "
         "shared variant exceed 0.015, and at 28 of 32 the dominant hypothesis was PP.H3 - two distinct "
         "causal variants in the same region (Figure 9C, Table S14). Even the estimate that survived FDR "
         "correction behaved this way: for CDKN1A and knee-replacement surgery PP.H4 was 0.010 against a "
         "PP.H3 of 0.93. All four exceptions to the PP.H3 pattern were at the UBC locus, where the posterior "
         "favoured PP.H1, association with expression alone (0.90-0.94), but that locus carried only 12 "
         "variants. The Mendelian randomisation signal is therefore better explained by linkage than by a "
         "shared causal variant."),
        ("Because testing the eight genes separately spends the multiple-testing budget on 32 tests, we also instrumented the signature as one composite exposure: a variant's effect on the score is the coefficient-weighted sum of its effects on whichever genes it instruments, which pools variants across loci. This gave 19 composite instruments covering all eight genes with a mean F statistic of 627 and four tests instead of 32 (Figure 10E-F, Table S12). No phenotype was significant: arthrosis at all sites OR 0.98 (95% CI 0.96-1.00, P = .11), knee osteoarthritis OR 0.99 (P = .33), hip osteoarthritis OR 0.99 (P = .70) and knee-replacement surgery OR 1.00 (P = .96). The design could detect odds ratios of 1.03 to 1.05, so this is a well-powered null, stable when each gene was dropped in turn (OR range 0.96 to 1.01). Unlike five of the eight single-gene estimates, the composite is directionally concordant with the transcriptomic finding, but does not reach significance."),
        ("The genetic and transcriptomic evidence also disagree in sign. All eight signature genes are "
         "suppressed in osteoarthritic cartilage, yet the causal estimates point in the opposite direction "
         "for five of the eight genes (Figure 9B); only ETS2, UBC and CDK2 are concordant. The same "
         "conclusion followed from a sensitivity analysis in which the outcomes were instrumented with GTEx "
         "version 8 tissue-specific cis-eQTLs, where no association survived correction. Taken together, the "
         "instrument strength, the absence of colocalisation and the directional mismatch indicate that "
         "lifelong genetically predicted expression in blood does not recapitulate the cross-sectional, "
         "tissue-specific state of end-stage cartilage. The senescence-checkpoint signature is therefore "
         "better understood as a marker of the osteoarthritic state than as a set of causal drivers, which "
         "is consistent with the single-cell evidence: the signature marks loss of the homeostatic "
         "chondrocyte programme, a consequence of degeneration rather than a proximal cause of it. This "
         "distinction matters for how the signature should be used, and it argues that therapeutic "
         "strategies should target the programme rather than individual signature genes."),
    ]),
    ("The cohort that did not validate could not have tested the signature", [
        ("Because the non-validating cohort contributed a prominent negative result, we quantified what it could have detected (Figure 9E-F). Its area under the curve of 0.461 was indistinguishable from chance under 20,000 label permutations (P = .80), and its Hanley-McNeil standard error of 0.142 means the smallest area it could detect at 80% power is 0.897, so it was powered only for near-perfect discrimination and its failure carries almost no evidence against the signature. The cohort also differs from the others in two ways that were verified rather than assumed. First, the direction of change of the signature genes is systematically reversed rather than randomly scattered: the four strongest discovery signals (JUN, CDKN1A, GADD45B and ETS2, all strongly suppressed in cartilage) shift to weakly positive values in this synovial cohort, while the four weakest signals remain concordant, a systematic reversal of exactly the AP-1 and checkpoint arm that points to the tissue difference rather than to technical noise. Second, the case-control split is supported by the deposited annotations, in which the five controls carry the characteristic 'disease state: non-osteoarthritis'; the submitter's wording, 'non-osteoarthritis (OA)', is ambiguous enough that a naive text search would misclassify them. This cohort therefore defines the boundary of the signature: it is a cartilage-derived marker whose performance cannot be assessed in a cohort that is both underpowered and drawn from a different joint tissue."),
    ]),
    ("Independent replication, disease specificity and two orthogonal layers", [
        ("To test whether the decoupled pattern is specific to the discovery cohort, differential "
         "expression was repeated from scratch in GSE57218, an independent cartilage cohort profiled on a "
         "different platform (Illumina HumanHT-12 V3) that contains healthy cartilage (n = 7) alongside "
         "macroscopically osteoarthritic (n = 33) and macroscopically preserved (n = 33) cartilage from "
         "osteoarthritic joints. Of 19,600 genes, 2,972 were differentially expressed between "
         "osteoarthritic and healthy cartilage at FDR < .05. Both programme arms replicated: of the "
         "twelve suppressed genes, ten changed in the same direction as in the discovery cohort (sign "
         "test P = .019, median log2 fold change -0.33), and all nine induced genes changed in the same "
         "direction (P = .002, median +0.48; Figure 10A, Table S19). The frozen signature separated "
         "osteoarthritic from healthy cartilage in this cohort (AUC 0.810, 95% CI 0.604-0.975) and "
         "preserved from healthy cartilage almost as well (0.797, 0.565-0.981; Table S20), but did not "
         "separate "
         "osteoarthritic from preserved cartilage taken from the same joints (0.515, 0.369-0.662; Figure "
         "10B). The signature therefore reports joint-level disease status rather than local lesion "
         "severity."),
        ("The same cohort bears on specificity, because GSE55235 contains ten rheumatoid-arthritis "
         "synovial samples that the validation analysis had excluded. The signature separated "
         "osteoarthritis from normal synovium (AUC 1.000) and osteoarthritis from rheumatoid arthritis "
         "less completely (0.810, 95% CI 0.545-0.990), but it separated rheumatoid arthritis from normal "
         "synovium almost as well as it separated osteoarthritis from normal synovium (0.980, "
         "0.910-1.000; Figure 10C, Table S21). Five of the eight signature genes are represented on the "
         "HG-U133A platform (per-gene values in Table S22), and all five changed in the same direction in "
         "osteoarthritis relative to "
         "rheumatoid arthritis as they did in osteoarthritis relative to normal cartilage. The signature "
         "is therefore not osteoarthritis-specific: it marks a degenerative and inflammatory joint state "
         "that the two diseases share, so part of its apparent accuracy against healthy tissue reflects "
         "that contrast rather than disease identity."),
        ("Because stable transcriptional silencing is usually accompanied by promoter methylation, we "
         "asked whether the suppression of the checkpoint arm has an epigenetic correlate. Two "
         "independent human cartilage methylation cohorts were analysed: GSE43269 (Illumina "
         "HumanMethylation27, 23 osteoarthritic versus 18 normal articular chondrocyte samples) and "
         "GSE73626 (HumanMethylation450, 11 osteoarthritic versus 7 normal cartilage samples). All eight "
         "signature genes were covered, by one to six CpGs on the 27K array and by five to twenty-three "
         "promoter CpGs on the 450K array. No signature gene showed differential methylation at "
         "FDR < .05 in either cohort, and the direction was not consistently hypermethylated: the "
         "smallest nominal P value was 0.035 (UBC in GSE73626, FDR 0.29; Figure 10D, Table S23). At the "
         "level of the programme as a whole, the mean promoter methylation of the 230 to 259 "
         "senescence-universe genes covered was unchanged in the 27K cohort (delta = -0.010, P = .55) "
         "and slightly lower rather than higher in the 450K cohort (delta = -0.006, P = .044). The loss "
         "of checkpoint expression in osteoarthritic cartilage is therefore not locked in by promoter "
         "methylation, which is consistent with a reversible state rather than with irreversible "
         "epigenetic silencing."),
    ]),
]

DISCUSSION = [
    ("Principal findings", [
        ("In this integrated analysis of five human knee cohorts, we show that the senescence programme in "
         "end-stage OA cartilage is not simply up-regulated but decoupled. The p53/p21-GADD45 DNA-damage "
         "checkpoint and the AP-1 stress-response arm, including JUN, FOS, ETS2, CDKN1A and GADD45B, are "
         "strongly suppressed, while cell-cycle re-entry machinery (CCND1, CCNA2, CDK6, E2F targets, G2-M "
         "checkpoint) and SASP output (IGFBP3) are induced; total senescence-programme activity nonetheless "
         "increases. A three-algorithm consensus of eight genes from the suppressed arm discriminated OA from "
         "normal cartilage with complete separation under nested cross-validation, a result that survived "
         "nested feature selection and removal of the differential-expression pre-filter, and that was "
         "retained in three of four independent external cohorts spanning cartilage and synovium and two "
         "expression platforms. Single-cell RNA sequencing localised the signature to homeostatic "
         "chondrocytes and away from hypertrophic chondrocytes, and drug-repurposing analysis nominated "
         "luteolin, alvocidib, curcumin and quercetin as candidate senescence-directed agents."),
    ]),
    ("A decoupled senescence phenotype rather than a simple increase in senescence burden", [
        ("Much of the OA senescence literature has been framed around the accumulation of senescent cells and "
         "the expectation that senescence markers increase with disease severity.[16-18] Our data support the "
         "increase in overall senescence-programme activity but show that this aggregate measure conceals "
         "opposite movements within the programme. Loss of CDKN1A/p21, CDKN1B/p27, GADD45A/B and the AP-1 "
         "components JUN, FOS and ETS2 is biologically coherent: GADD45 proteins are effectors of the "
         "p53-dependent DNA-damage response, and their loss, together with loss of p21 and p27, removes "
         "checkpoint restraint and permits the cell-cycle re-entry that is reflected in the simultaneous "
         "up-regulation of CCND1, CCNA2, CDK6 and E2F targets.[19, 22, 25] The concomitant rise in IGFBP3, a "
         "well-established SASP component and a gene repeatedly associated with OA susceptibility, indicates "
         "that secretome output is maintained or enhanced even as checkpoint control is lost.[39, 40] This "
         "combination, checkpoint loss with preserved or increased secretory output and cell-cycle "
         "re-entry, is precisely the phenotype that would be expected to drive progressive matrix "
         "degradation, and it aligns with reports that senescent chondrocytes in situ are heterogeneous and "
         "that distinct senotypes coexist in ageing tissue.[22, 26, 29]"),
        ("The interpretation is also consistent with the single-cell data. The signature was most strongly "
         "expressed in homeostatic chondrocytes, the population that maintains matrix homeostasis and that "
         "is depleted in OA, and least expressed in hypertrophic and pre-hypertrophic chondrocytes, the "
         "populations that expand during degeneration and contribute to osteophyte formation and "
         "mineralisation.[49, 50, 71] This ordering was reproduced in two independent atlases that differ by "
         "two orders of magnitude in size, and in the larger of the two it survived a donor-controlled "
         "comparison across eleven annotated populations, in which homeostatic chondrocytes ranked above "
         "every adequately sampled population. Loss of the signature therefore tracks loss of the "
         "homeostatic state rather than the appearance of a single senescent population, which may explain "
         "why aggregate senescence scores and individual checkpoint markers can move in opposite directions."),
    ]),
    ("Comparison with previous transcriptomic studies", [
        ("Previous bioinformatics analyses of OA have typically derived markers and evaluated performance "
         "within a single cohort, and have reported near-perfect accuracy without external confirmation.[51-54, 70] "
         "Our study differs in three respects. First, we deliberately separated the derivation cohort from "
         "four independent validation cohorts spanning two tissues and two platforms, and we report the "
         "cohort in which the signature failed alongside those in which it succeeded. Second, we nested "
         "feature selection inside cross-validation and additionally removed the differential-expression "
         "pre-filter, so that the reported accuracy cannot be attributed to selection on the evaluation data. "
         "Third, we interpret the signature mechanistically rather than as an undifferentiated disease score, "
         "which is possible because every signature gene belongs to a defined arm of the senescence "
         "programme."
         "Our network analysis also aligns with earlier observations that transcription factors rather than "
         "matrix genes occupy the topological centre of OA co-expression networks.[70] The identification of "
         "MYC, JUN, CDKN1A, FOS, CCND1 and EZH2 as hubs is notable because EZH2 has independently been shown "
         "to restrain senescence-associated inflammation in disc degeneration and because AP-1 components "
         "coordinate the senescence transcriptional programme.[41]"),
    ]),
    ("Therapeutic implications", [
        ("The most direct implication of a decoupled phenotype is that therapeutic strategies aimed solely at "
         "clearing senescent cells may be insufficient, and that restoring checkpoint function or limiting "
         "cell-cycle re-entry may be equally relevant. Senolytic approaches have shown benefit in "
         "experimental joint and disc degeneration,[43-46] and our drug-repurposing results independently "
         "return quercetin, a component of the dasatinib-quercetin senolytic combination. The nomination of "
         "alvocidib, a cyclin-dependent kinase inhibitor, is mechanistically consistent with the cell-cycle "
         "re-entry arm, while luteolin and curcumin are natural senomorphic compounds that suppress the SASP. "
         "Because the signature is derived from cartilage and is localised to homeostatic chondrocytes, these "
         "compounds should be regarded as hypotheses for testing in cartilage-relevant models rather than as "
         "established therapies.[45, 46, 66] The upstream regulator analysis, which implicated ATF3, HDAC1, "
         "HDAC3 and MYC, suggests that epigenetic and transcriptional modulation of the AP-1 and "
         "p53-p21 axes deserves attention alongside senolysis.[24, 64]"),
    ]),
    ("Interpretation and context", [
        ("Four further analyses sharpen what the signature is. It reproduces in an independent cartilage "
         "cohort on a different platform, with both programme arms moving in the same direction, so the "
         "decoupling is not an artefact of the discovery cohort. But it does not distinguish lesioned "
         "from preserved cartilage within the same joint, and it separates rheumatoid arthritis from "
         "normal synovium almost as well as it separates osteoarthritis from normal synovium, so it "
         "reports a joint-level degenerative state rather than osteoarthritis specifically. Its loss is "
         "also not accompanied by promoter hypermethylation in either of two independent methylation "
         "cohorts, which argues against locked-in epigenetic silencing and is consistent with the "
         "reversible state implied by reprogramming experiments.[65] Finally, when the signature is "
         "instrumented as a single composite exposure rather than as eight separate genes, the null "
         "causal result becomes well powered: 19 instruments covering all eight genes give a smallest "
         "detectable odds ratio of about 1.04."),
    ]),
    ("Strengths and limitations", [
        ("The principal strengths of this study are the use of exclusively real, publicly available human "
         "data with fully reproducible analysis code; the deliberate multi-cohort, cross-tissue and "
         "cross-platform validation design; the use of nested feature selection to guard against optimistic "
         "accuracy estimates; the integration of bulk transcriptomics with single-cell localisation; and the "
         "mechanistic framing of the signature in terms of defined senescence arms."
         "Several limitations must be acknowledged. The discovery cohort is small (38 samples) and the OA samples were all end-stage (Kellgren-Lawrence grade 4) against grade 1 controls, so the signature characterises advanced disease; the complete separation within this cohort reflects a very large effect size rather than realistic accuracy, and the external cohorts give the more informative estimates.[62, 63] Bulk expression conflates per-cell transcription with cellularity, and the generalised reduction in cell-type scores in OA indicates that compositional change contributes. The single-cell replication addresses this in part, but the control arm of the larger cohort contains one donor, so its control-versus-OA contrast is descriptive and confounded; the donor-controlled comparisons here are between populations, not between disease states. One external cohort did not validate, and its imbalance (36 versus 5) limits the informativeness of its AUC. The HG-U133A annotation was available only partially, so five of eight genes could be tested in the microarray cohorts. The causal analysis used whole-blood cis-eQTLs because the tissue-matched cartilage molecular QTL map is deposited under controlled access at the European Genome-phenome Archive and the access agreements could not be completed here;[48] blood is not the disease tissue, and the instrument sets for CDK2 and UBC were underpowered for all but large effects. All analyses are computational, so the signature and the nominated compounds require experimental validation, and the drug-repurposing results are hypothesis-generating. Finally, the cohorts differ in ancestry and clinical annotation, and no longitudinal data were available to relate the signature to progression or arthroplasty."),
    ]),
]

CONCLUSION = [
    ("End-stage human knee OA cartilage exhibits a decoupled senescence phenotype in which the "
     "p53/p21-GADD45 checkpoint and AP-1 stress-response arms are suppressed while cell-cycle re-entry and "
     "SASP output are induced. An eight-gene signature derived from the suppressed arm by three-algorithm "
     "consensus discriminated OA from normal cartilage with complete separation under nested "
     "cross-validation, remained robust when feature selection was nested inside every fold, and retained "
     "discrimination in three of four independent cohorts spanning cartilage and synovium and two expression "
     "platforms. Two independent single-cell atlases localised the signature to homeostatic chondrocytes, "
     "and both programme arms reproduced in an independent cartilage cohort, although there the "
     "signature marked joint-level rather than lesion-level disease and was not osteoarthritis-specific. "
     "Drug-repurposing analysis nominated luteolin, alvocidib, curcumin and quercetin as candidate "
     "senescence-directed agents. Mendelian randomisation with strong cis-eQTL instruments produced one "
     "FDR-significant estimate, but colocalisation showed that no locus shares a causal variant, so the "
     "signature should be read as a marker of the osteoarthritic state rather than a driver of it. These "
     "findings reframe the senescence programme in OA as an uncoupling of "
     "checkpoint control from secretory output, provide a mechanistically interpretable cartilage-derived "
     "signature for further validation, and identify candidate targets for senescence-directed therapy."),
]

STATEMENTS = [
        ("Acknowledgements",
     "The authors thank the investigators who generated and deposited the public datasets analysed here (GSE114007, GSE169077, GSE283079, GSE55235, GSE55457, GSE104782, GSE255460, GSE57218, GSE43269 and GSE73626), and the maintainers of the Enrichr, STRING, eQTLGen, FinnGen and GEO resources. No individual person outside the author list contributed to this work."),
        ("Author contributions",
     "Conceptualisation: Fangwei Xue, Jing Shi. Methodology: Haiyan Xue, Jing Shi. Data curation and formal analysis: Yangjie Li, Hao Gu. Statistical analysis: Yangjie Li, Haiyan Xue. Visualisation: Yangjie Li. Writing - original draft: Jing Shi. Writing - review and editing: all authors. Supervision: Fangwei Xue. All authors read and approved the final manuscript and agree to be accountable for all aspects of the work."),
        ("Funding",
     "This research received no specific grant from any funding agency in the public, commercial or not-for-profit sectors."),
        ("Conflicts of interest",
     "The authors declare that they have no competing interests."),
        ("Ethics approval and consent to participate",
     "This study analysed only de-identified, publicly available data from the Gene Expression Omnibus, eQTLGen and FinnGen. No new human participants or animals were involved, and no ethical approval or informed consent was therefore required."),
        ("Data availability",
     "All datasets analysed in this study are publicly available: the expression cohorts from the NCBI Gene Expression Omnibus (GSE114007, GSE169077, GSE283079, GSE55235, GSE55457, GSE104782, GSE255460, GSE57218, GSE43269 and GSE73626), the genetic instruments from the eQTLGen cis-eQTL summary statistics, and the outcome data from the FinnGen release 11 summary statistics. The derived result tables, the supplementary tables and the analysis code that reproduce every number, table and figure in this article are archived at Zenodo (DOI: [to be inserted]) and at https://github.com/[account]/[repository]."),
        ("Reporting guideline",
     "The study is reported in accordance with the Strengthening the Reporting of Observational Studies in Epidemiology (STROBE) recommendations for observational research, using the customized STROBE checklist that Medicine provides; the completed checklist accompanies this submission."),
]

FIGURE_LEGENDS = [
    ("Figure 1.", "Conceptual framework. (A) Osteoarthritic joint showing cartilage layers, synovial "
     "involvement, enlarged senescent chondrocytes, the senescence-associated secretory phenotype "
     "(SASP) secretome and immune recruitment. (B) The senescence-SASP cycle linking mechanical and "
     "oxidative stress to checkpoint activation, secretome output, matrix catabolism and further "
     "senescence. (C) The decoupled programme: the p53/p21-GADD45 checkpoint and AP-1 arms are "
     "suppressed while cell-cycle re-entry and SASP output are induced. (D) Analytical workflow, from "
     "public cohorts through differential expression, co-expression, interaction networks, "
     "three-algorithm feature selection, a fourteen-model nested benchmark and repurposing."),
    ("Figure 2.", "Differential expression in the discovery cohort (GSE114007). (A) Volcano plot of all "
     "12,873 expressed genes, with senescence-universe genes highlighted and the twelve largest effect "
     "sizes labelled. (B) Principal component analysis of the 2,000 most variable genes. (C) "
     "Tissue-level senescence-programme activity (ssGSEA) by group. (D) Composition of the five cohorts. "
     "(E) Heatmap of the 26 most differentially expressed genes. (F) Log2 fold change of every "
     "senescence-universe gene detected."),
    ("Figure 3.", "Weighted co-expression analysis. (A) Dendrogram of the 4,000 most variable genes "
     "with the module colour strip, spanning the full width. (B) Scale-free topology fit and mean "
     "connectivity against the soft-thresholding power; the selected power (beta = 14) is marked. (C) "
     "Module size and senescence-universe content. (D) Convergent evidence across differential "
     "expression, co-expression and the senescence universe. (E) Module-trait correlations. (F) "
     "Correlation between module eigengenes."),
    ("Figure 4.", "Functional enrichment of the 24 senescence-related differentially expressed genes as "
     "one unified dot matrix. (A) The 36 leading terms pooled across six libraries share a single axis, "
     "so libraries can be compared directly; position is significance, bubble area is overlap count, "
     "colour is library. (B) Best P value per library with the number of significant terms."),
    ("Figure 5.", "Protein interaction network and hub prioritisation. (A) STRING network of the "
     "candidate genes, full height; node size is maximal clique centrality, colour is direction of "
     "change in OA, and labels are decluttered. (B) Polar ranking of the 14 highest hubs. (C) Expression "
     "of the six highest-ranked hubs. (D) Correlation among the 16 highest-ranked hubs."),
    ("Figure 6.", "Feature selection and model benchmarking. (A) Nested 5x5 cross-validated "
     "discrimination across classifiers. (B) Area under the curve with 95% bootstrap confidence "
     "intervals for all 14 classifiers. (C) SHAP beeswarm summarising each gene's contribution. (D) "
     "LASSO stability selection over 200 bootstrap resamples. (E) Random-forest Gini importance, with "
     "stars marking genes retained by recursive feature elimination. (F) Mean absolute SHAP value."),
    ("Figure 7.", "Diagnostic performance and clinical utility. (A) Nomogram assigning 0-100 points per "
     "signature gene in proportion to its coefficient, spanning two columns so the scales are "
     "comparable. (B) Total points translated into predicted risk. (C) Expression heatmap of the "
     "signature genes. (D) Discovery-cohort receiver operating characteristic with the Youden-optimal "
     "point. (E) Decision-curve analysis. (F) External validation as a forest plot, showing the frozen "
     "panel and the senescence-programme score with 95% bootstrap intervals."),
    ("Figure 8.", "Immune landscape, single-cell localisation and candidate therapeutics. (A) Relative "
     "enrichment composition: each population's mean positive ssGSEA score as a fraction of the summed "
     "positive scores, showing how the balance shifts. (B) Cell-type enrichment differences with "
     "significance. (C) Correlation between signature genes and cell-type programmes. (D) Chord map "
     "linking the ten leading compounds to the signature genes they perturb. (E) Inferred upstream "
     "transcription-factor network. (F) Signature genes across the subpopulations of GSE104782. (G) "
     "Aggregate score per subpopulation. (H) Replication in GSE255460 (134,551 cells, nine donors): "
     "per-cell score across eleven populations, homeostatic chondrocytes in magenta, per-donor means "
     "as open circles, donor-controlled significance at the left."),
    ("Figure 9.", "Causal inference, signature reversal and the boundary of the signature. (A) "
     "Two-sample Mendelian randomisation of each gene on four FinnGen R11 phenotypes, using eQTLGen "
     "cis-eQTL instruments (31,684 whole-blood samples); odds ratios per standard deviation with 95% "
     "intervals, the one estimate surviving correction ringed, mean instrument F and smallest "
     "detectable odds ratio at the right. (B) Causal estimate against transcriptomic fold change; "
     "shaded quadrants mark directional agreement, containing only three of eight genes. (C) "
     "Posterior probability of a shared causal variant against randomisation significance for all 32 "
     "gene-phenotype pairs. (D) Connectivity-score distribution for the "
     "original Connectivity Map, with known senolytics in green and the leading reversers in magenta. "
     "(E) Null distribution of the area under the curve for the non-validating cohort over 20,000 label "
     "permutations. (F) Direction of change in the discovery versus the non-validating cohort."),
    ("Figure 10.", "Independent replication, disease specificity and two orthogonal layers. (A) The two "
     "programme arms in an independent cartilage cohort (GSE57218): each gene positioned by its fold "
     "change in the discovery cohort and in GSE57218, with shaded quadrants marking directional "
     "agreement and sign-test P values. (B) Frozen signature applied to GSE57218 for osteoarthritic "
     "versus healthy, preserved versus healthy, and osteoarthritic versus preserved cartilage from the "
     "same joints. (C) Disease specificity in GSE55235 synovium, which contains rheumatoid arthritis. "
     "(D) Methylation difference between osteoarthritic and normal cartilage per signature gene in a "
     "27K and a 450K cohort. (E) Programme-level randomisation with the signature instrumented as one "
     "composite exposure; amber marks are the smallest detectable odds ratio at 80% power. (F) The same "
     "estimates dropping each gene in turn."),
]

