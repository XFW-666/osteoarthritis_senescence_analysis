"""
step20_methylation.py — epigenetic layer.

The manuscript's central claim (checkpoint and AP-1 arms suppressed, cell-cycle re-entry and
SASP induced) rests on mRNA.  A stable transcriptional silencing would normally leave a mark in
DNA methylation, so two independent human cartilage methylation cohorts are used to ask whether
the suppression has an epigenetic correlate:

  GSE43269  Illumina HumanMethylation27 (GPL8490), knee articular chondrocytes, 23 OA / 18 normal
  GSE73626  Illumina HumanMethylation450 (GPL13534), hip+knee cartilage,    11 OA /  7 normal

CpGs are mapped to genes from the Illumina manifests, promoter CpGs (TSS1500 / TSS200 / 1stExon /
5'UTR) are preferred for the 450K array, and each gene is summarised by the mean methylation of
its CpGs.  Group comparison is Mann-Whitney with Benjamini-Hochberg control.
"""
import gzip, csv, json, os
import numpy as np
import pandas as pd
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
EXTRA = os.path.join(BASE, "data", "extra")
OUT = os.path.join(BASE, "results")

PROMOTER = ("TSS1500", "TSS200", "1stExon", "5'UTR")


def bh(p):
    p = np.asarray(p, float)
    ok = np.isfinite(p)
    q = np.full(len(p), np.nan)
    po = p[ok]
    o = np.argsort(po)
    qq = np.empty(len(po))
    qq[o] = np.minimum.accumulate((po[o] * len(po) / (np.arange(len(po)) + 1))[::-1])[::-1]
    q[ok] = np.clip(qq, 0, 1)
    return q


def read_manifest_27k():
    f = os.path.join(EXTRA, "GPL8490_HumanMethylation27_270596_v.1.2.csv.gz")
    with gzip.open(f, "rt", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("IlmnID"):
                rdr = csv.DictReader(fh, fieldnames=next(csv.reader([line])))
                rows = [r for r in rdr if r.get("IlmnID")]
                break
    df = pd.DataFrame(rows)
    df = df[["IlmnID", "Symbol", "Chr", "MapInfo", "Distance_to_TSS"]].rename(
        columns={"IlmnID": "probe", "Symbol": "gene", "Chr": "chr", "MapInfo": "pos",
                 "Distance_to_TSS": "tss_dist"})
    df = df[df["gene"].astype(str).str.strip() != ""]
    df["region"] = "promoter"
    return df


def read_manifest_450k():
    f = os.path.join(EXTRA, "GPL13534_HumanMethylation450_15017482_v.1.1.csv.gz")
    recs = []
    with gzip.open(f, "rt", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("IlmnID"):
                rdr = csv.reader(fh)
                hdr = next(csv.reader([line]))
                i_probe = hdr.index("IlmnID")
                i_name = hdr.index("UCSC_RefGene_Name")
                i_grp = hdr.index("UCSC_RefGene_Group")
                i_chr = hdr.index("CHR")
                i_pos = hdr.index("MAPINFO")
                for r in rdr:
                    if len(r) <= max(i_name, i_grp):
                        continue
                    names = [g for g in r[i_name].split(";") if g]
                    groups = r[i_grp].split(";") if i_grp < len(r) else []
                    if not names:
                        continue
                    reg = "promoter" if any(g in PROMOTER for g in groups) else "other"
                    for g in names:
                        recs.append((r[i_probe], g, r[i_chr], r[i_pos], reg))
                break
    df = pd.DataFrame(recs, columns=["probe", "gene", "chr", "pos", "region"])
    return df.drop_duplicates(["probe", "gene"])


def load_series(path):
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as fh:
        lines = fh.read().split("\n")
    chars = [l for l in lines if l.startswith("!Sample_characteristics")]
    meta = {}
    for l in chars:
        vals = [v.strip().strip('"') for v in l.split("\t")[1:]]
        meta.setdefault("chars", []).append(vals)
    gsms = next(l for l in lines if l.startswith("!Sample_geo_accession")).split("\t")[1:]
    gsms = [g.strip().strip('"') for g in gsms]
    start = next(i for i, l in enumerate(lines) if l.startswith("!series_matrix_table_begin"))
    header = [v.strip().strip('"') for v in lines[start + 1].split("\t")]
    recs = []
    for l in lines[start + 2:]:
        if l.startswith("!series_matrix_table_end"):
            break
        if not l.strip():
            continue
        parts = l.split("\t")
        probe = parts[0].strip().strip('"')
        vals = []
        for v in parts[1:]:
            v = v.strip().strip('"')
            try:
                vals.append(float(v))
            except ValueError:
                vals.append(np.nan)
        recs.append((probe, vals))
    M = pd.DataFrame({r[0]: r[1] for r in recs}, index=header[1:]).T
    return M, gsms, meta


def label_27k(meta):
    # 'disease state: osteoarthritis' vs 'disease state: normal'
    out = {}
    for l in meta["chars"]:
        pass
    return None


def annotate(M, ann, genes, promoter_only=True):
    """Mean methylation per gene, averaged over its CpGs (promoter CpGs where annotated)."""
    a = ann[ann["gene"].isin(genes)]
    if promoter_only and (a["region"] == "promoter").any():
        a = a[a["region"] == "promoter"]
    a = a[a["probe"].isin(M.index)]
    out = {}
    n_cpg = {}
    for g, sub in a.groupby("gene"):
        probes = sub["probe"].unique()
        if len(probes) == 0:
            continue
        out[g] = M.loc[probes].mean(0)
        n_cpg[g] = len(probes)
    return pd.DataFrame(out).T, n_cpg


def analyse(name, M, groups, ann, sig, srg, promoter_only=True, mvalues=False):
    print(f"\n{'='*100}\n{name}: {M.shape[0]} CpGs x {M.shape[1]} samples  "
          f"({dict(groups.value_counts())})  "
          f"{'M-values' if mvalues else 'beta values'}")
    gene_meth, n_cpg = annotate(M, ann, set(sig) | set(srg), promoter_only)
    print(f"  genes with CpG coverage: {gene_meth.shape[0]} "
          f"(of {len(set(sig) | set(srg))} signature+senescence genes)")

    oa = groups == "OA"
    no = groups == "Normal"

    def test(v):
        a, b = v[oa.values].dropna(), v[no.values].dropna()
        if len(a) < 3 or len(b) < 3:
            return np.nan, np.nan, np.nan, np.nan
        u = stats.mannwhitneyu(a, b)
        return float(a.mean() - b.mean()), float(a.mean()), float(b.mean()), float(u.pvalue)

    rows = []
    for g in gene_meth.index:
        d, mo, mn, p = test(gene_meth.loc[g])
        rows.append({"cohort": name, "gene": g, "n_cpg": int(n_cpg.get(g, 0)),
                     "is_signature": g in set(sig),
                     "delta_OA_minus_normal": d, "mean_OA": mo, "mean_normal": mn, "p": p})
    res = pd.DataFrame(rows)
    res["fdr"] = bh(res["p"])
    res = res.sort_values("p")
    res.to_csv(os.path.join(OUT, f"methylation_{name}.csv"), index=False)

    print("  signature genes:")
    for _, r in res[res.is_signature].iterrows():
        print(f"    {r['gene']:9s} CpGs={int(r['n_cpg']):3d}  "
              f"delta={r['delta_OA_minus_normal']:+.4f}  P={r['p']:.4f}  FDR={r['fdr']:.3f}")

    # programme level: mean over all senescence-universe genes present
    prog = gene_meth.loc[[g for g in gene_meth.index if g in set(srg)]].mean(0)
    pd_ = float(prog[oa.values].mean() - prog[no.values].mean())
    pp = float(stats.mannwhitneyu(prog[oa.values], prog[no.values]).pvalue)
    print(f"  senescence-programme mean methylation: delta={pd_:+.5f}  P={pp:.4f}  "
          f"(n genes = {len([g for g in gene_meth.index if g in set(srg)])})")
    return res, {"cohort": name, "n_genes": int(gene_meth.shape[0]),
                 "programme_delta": pd_, "programme_p": pp,
                 "n_sig_genes_covered": int(res["is_signature"].sum()),
                 "sig_genes_fdr05": int(((res["fdr"] < 0.05) & res["is_signature"]).sum()),
                 "any_fdr05": int((res["fdr"] < 0.05).sum()),
                 "mvalues": mvalues}


def main():
    sig = json.load(open(os.path.join(OUT, "signature.json")))
    srg = json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))
    summary = {}

    # ---- GSE43269 (27K, M-values, articular chondrocytes)
    ann27 = read_manifest_27k()
    print(f"GPL8490 manifest: {len(ann27)} probes, {ann27['gene'].nunique()} genes")
    M, gsms, meta = load_series(os.path.join(EXTRA, "GSE43269_series_matrix.txt.gz"))
    chars = pd.Series(meta["chars"][0], index=gsms)
    groups = chars.str.lower().map(lambda s: "OA" if "osteoarthrit" in s else
                                   ("Normal" if "normal" in s else None))
    keep = groups[groups.notna()].index
    res27, sum27 = analyse("GSE43269", M.loc[:, keep], groups[keep], ann27, sig, srg,
                           promoter_only=False, mvalues=True)
    summary["GSE43269"] = sum27

    # ---- GSE73626 (450K, beta values, cartilage)
    ann450 = read_manifest_450k()
    print(f"\nGPL13534 manifest: {len(ann450)} probe-gene rows, {ann450['gene'].nunique()} genes")
    M2, gsms2, meta2 = load_series(os.path.join(EXTRA, "GSE73626_series_matrix.txt.gz"))
    ch2 = pd.Series(meta2["chars"][1], index=gsms2)
    g2 = ch2.str.lower().map(lambda s: "OA" if "osteoarthritic" in s else
                             ("Normal" if "normal" in s else None))
    keep2 = g2[g2.notna()].index
    res450, sum450 = analyse("GSE73626", M2.loc[:, keep2], g2[keep2], ann450, sig, srg,
                             promoter_only=True, mvalues=False)
    summary["GSE73626"] = sum450

    json.dump(summary, open(os.path.join(OUT, "methylation_summary.json"), "w"), indent=1)
    print("\nSTEP20 DONE")


if __name__ == "__main__":
    main()
