"""Strict nested check: candidate pool = ALL senescence-universe genes present in the matrix
(no full-data DEG pre-filter); LASSO selection inside every training fold."""
import os, json, warnings
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); OUT = os.path.join(BASE, "results")

expr = pd.read_csv(os.path.join(WORK, "expr_GSE114007.csv"), index_col=0)
labels = pd.read_csv(os.path.join(WORK, "labels_GSE114007.csv"), index_col=0).iloc[:, 0]
y = (labels == "OA").astype(int).values
srg = [g for g in json.load(open(os.path.join(OUT, "senescence_gene_universe.json"))) if g in expr.index]
X = expr.loc[srg].T.values.astype(float)
print("strict pool (all senescence genes present):", len(srg))

acc = np.zeros(len(y)); cnt = {}
for r in range(10):
    skf = StratifiedKFold(5, shuffle=True, random_state=200 + r)
    for tr, te in skf.split(X, y):
        Xs = StandardScaler().fit_transform(X[tr])
        las = LogisticRegression(penalty="l1", solver="liblinear", C=0.1, max_iter=5000).fit(Xs, y[tr])
        keep = np.abs(las.coef_[0]) > 1e-8
        if keep.sum() < 2:
            keep = np.zeros_like(keep, dtype=bool)
            keep[np.argsort(-np.abs(las.coef_[0]))[:5]] = True
        pipe = Pipeline([("s", StandardScaler()), ("m", LogisticRegression(max_iter=5000, C=1.0))])
        pipe.fit(X[np.ix_(tr, keep)], y[tr])
        acc[te] += pipe.predict_proba(X[np.ix_(te, keep)])[:, 1]
        for g in np.array(srg)[keep]:
            cnt[g] = cnt.get(g, 0) + 1
p = acc / 10
auc = roc_auc_score(y, p)
rng = np.random.default_rng(7); bs = []
for _ in range(2000):
    i = rng.integers(0, len(y), len(y))
    if len(set(y[i])) < 2: continue
    bs.append(roc_auc_score(y[i], p[i]))
lo, hi = np.percentile(bs, [2.5, 97.5])
print(f"STRICT NESTED CV AUC = {auc:.3f} [{lo:.3f}, {hi:.3f}]")
print("most frequently retained:", sorted(cnt.items(), key=lambda kv: -kv[1])[:12])
json.dump({"auc": float(auc), "ci": [float(lo), float(hi)], "pool": len(srg),
           "top_features": sorted(cnt.items(), key=lambda kv: -kv[1])[:15]},
          open(os.path.join(OUT, "strict_nested_cv.json"), "w"), indent=1)
