"""Rewrite the ABSTRACT block to stay within a conventional length after the new results."""

NEW = '''ABSTRACT = {
    "Background": (
        "Osteoarthritis is a leading cause of disability and no disease-modifying therapy exists. The "
        "architecture of the senescence programme in end-stage human osteoarthritis cartilage, and its "
        "transferability across tissues and platforms, remain undefined."),
    "Methods": (
        "Public human knee cohorts were analysed: discovery in cartilage RNA-sequencing (GSE114007; 20 OA, "
        "18 normal), validation in one cartilage microarray and three synovial cohorts, independent "
        "re-discovery in a further cartilage cohort, and two cartilage methylation cohorts. Senescence "
        "genes were the union of curated Reactome, KEGG and Gene Ontology senescence and SASP sets. "
        "Differential expression, co-expression, interaction-network, enrichment, ssGSEA and "
        "three-algorithm feature selection were performed, and fourteen classifiers were benchmarked under "
        "nested cross-validation. The signature was validated in every external cohort, localised in two "
        "single-cell cohorts, tested by Mendelian randomisation with eQTLGen cis-eQTLs against four "
        "FinnGen phenotypes including colocalisation, and screened for reversing compounds by "
        "connectivity mapping."),
    "Results": (
        "Sixty senescence genes were differentially expressed in OA cartilage and the 24 stringent ones "
        "were enriched for cellular senescence, the SASP and G1/S cell-cycle control. The p53/p21-GADD45 "
        "checkpoint and AP-1 arms were suppressed (JUN -3.06, CDKN1A -3.00) while cell-cycle re-entry "
        "(CCND1 +2.03) and IGFBP3 (+3.29) were induced, indicating a decoupled programme. The eight-gene "
        "signature (ETS2, GADD45B, JUN, CDKN1B, UBC, CDKN1A, HLA-F, CDK2) reached an area under the curve "
        "of 1.000 under nested cross-validation and retained discrimination in three of four external "
        "cohorts (0.967 to 1.000) but not in the underpowered GSE283079. It localised to homeostatic "
        "chondrocytes in both single-cell atlases, and both programme arms reproduced in an independent "
        "cartilage cohort, where the signature tracked joint rather than lesion status and showed no "
        "promoter hypermethylation. Connectivity mapping recovered known senolytics as reversers. "
        "Mendelian randomisation gave 32 strong-instrument estimates, one surviving false-discovery "
        "correction (CDKN1A and knee-replacement surgery, odds ratio 1.17, FDR = 0.035), but no locus "
        "colocalised and a composite-exposure analysis was a well-powered null."),
    "Conclusion": (
        "End-stage knee OA cartilage shows a decoupled senescence phenotype, with loss of checkpoint and "
        "AP-1 control alongside cell-cycle re-entry and SASP output. The eight-gene signature is a robust "
        "cartilage-derived marker of that state rather than a causal driver, and nominates cell-cycle and "
        "senotherapeutic targets."),
}
'''

p = "manuscript_text.py"
src = open(p, encoding="utf-8").read()
start = src.index("ABSTRACT = {")
end = src.index("KEY_POINTS = [")
src = src[:start] + NEW + "\n\n" + src[end:]
open(p, "w", encoding="utf-8").write(src)
print("abstract replaced")
