"""Insert the new analyses into manuscript_text.py / manuscript_text2.py.

Anchored insertions, so the edit fails loudly if an anchor is missing rather than
silently doing nothing.
"""
import io, sys

def patch(path, edits):
    src = open(path, encoding="utf-8").read()
    for label, old, new in edits:
        if old not in src:
            raise SystemExit(f"ANCHOR MISSING in {path}: {label}")
        if src.count(old) != 1:
            raise SystemExit(f"ANCHOR NOT UNIQUE ({src.count(old)}x) in {path}: {label}")
        src = src.replace(old, new)
        print(f"  ok  {label}")
    open(path, "w", encoding="utf-8").write(src)


# ---------------------------------------------------------------- manuscript_text2.py
AGG_MR = '''        ("Because testing the eight genes separately spends the multiple-testing budget on 32 tests, "
         "we also instrumented the signature as a single composite exposure: a variant's effect on the "
         "score is the coefficient-weighted sum of its effects on whichever signature genes it "
         "instruments, which pools the variants across loci. This gave 19 composite instruments covering "
         "all eight genes with a mean F statistic of 627, and four tests instead of 32 (Figure 10E-F, "
         "Table S16). No phenotype was significant: arthrosis at all sites OR 0.98 (95% CI 0.96-1.00, "
         "P = 0.11), knee osteoarthritis OR 0.99 (P = 0.33), hip osteoarthritis OR 0.99 (P = 0.70) and "
         "knee-replacement surgery OR 1.00 (P = 0.96). The design could detect odds ratios of 1.03 to "
         "1.05 per standard deviation, so this is a well-powered null rather than an uninformative one, "
         "and it was stable when each gene was dropped in turn (OR range 0.96 to 1.01). Unlike five of "
         "the eight single-gene estimates, the composite points in the direction concordant with the "
         "transcriptomic finding, but it does not reach significance."),
'''

NEW_SECTION = '''    ("Independent replication, disease specificity and two orthogonal layers", [
        ("To test whether the decoupled pattern is specific to the discovery cohort, differential "
         "expression was repeated from scratch in GSE57218, an independent cartilage cohort profiled on a "
         "different platform (Illumina HumanHT-12 V3) that contains healthy cartilage (n = 7) alongside "
         "macroscopically osteoarthritic (n = 33) and macroscopically preserved (n = 33) cartilage from "
         "osteoarthritic joints. Of 19,600 genes, 2,972 were differentially expressed between "
         "osteoarthritic and healthy cartilage at FDR < 0.05. Both programme arms replicated: of the "
         "twelve suppressed genes, ten changed in the same direction as in the discovery cohort (sign "
         "test P = 0.019, median log2 fold change -0.33), and all nine induced genes changed in the same "
         "direction (P = 0.002, median +0.48; Figure 10A, Table S17). The frozen signature separated "
         "osteoarthritic from healthy cartilage in this cohort (AUC 0.810, 95% CI 0.604-0.975) and "
         "preserved from healthy cartilage almost as well (0.797, 0.565-0.981), but did not separate "
         "osteoarthritic from preserved cartilage taken from the same joints (0.515, 0.369-0.662; Figure "
         "10B). The signature therefore reports joint-level disease status rather than local lesion "
         "severity."),
        ("The same cohort bears on specificity, because GSE55235 contains ten rheumatoid-arthritis "
         "synovial samples that the validation analysis had excluded. The signature separated "
         "osteoarthritis from normal synovium (AUC 1.000) and osteoarthritis from rheumatoid arthritis "
         "less completely (0.810, 95% CI 0.545-0.990), but it separated rheumatoid arthritis from normal "
         "synovium almost as well as it separated osteoarthritis from normal synovium (0.980, "
         "0.910-1.000; Figure 10C, Table S18). Five of the eight signature genes are represented on the "
         "HG-U133A platform, and all five changed in the same direction in osteoarthritis relative to "
         "rheumatoid arthritis as they did in osteoarthritis relative to normal cartilage. The signature "
         "is therefore not osteoarthritis-specific: it marks a degenerative and inflammatory joint state "
         "that the two diseases share, so part of its apparent accuracy against healthy tissue reflects "
         "that contrast rather than disease identity."),
        ("Because stable transcriptional silencing is usually accompanied by promoter methylation, we "
         "asked whether the suppression of the checkpoint arm has an epigenetic correlate. Two "
         "independent human cartilage methylation cohorts were analysed: GSE43269 (Illumina "
         "HumanMethylation27, 23 osteoarthritic versus 18 normal articular chondrocyte samples) and "
         "GSE73626 (HumanMethylation450, 11 osteoarthritic versus 7 normal cartilage samples). All eight "
         "signature genes were covered, by one to six CpGs on the 27K array and by five to twenty-three "
         "promoter CpGs on the 450K array. No signature gene showed differential methylation at "
         "FDR < 0.05 in either cohort, and the direction was not consistently hypermethylated: the "
         "smallest nominal P value was 0.035 (UBC in GSE73626, FDR 0.29; Figure 10D, Table S19). At the "
         "level of the programme as a whole, the mean promoter methylation of the 230 to 259 "
         "senescence-universe genes covered was unchanged in the 27K cohort (delta = -0.010, P = 0.55) "
         "and slightly lower rather than higher in the 450K cohort (delta = -0.006, P = 0.044). The loss "
         "of checkpoint expression in osteoarthritic cartilage is therefore not locked in by promoter "
         "methylation, which is consistent with a reversible state rather than with irreversible "
         "epigenetic silencing."),
    ]),
'''

DISCUSSION_PARA = '''        ("Four further analyses sharpen what the signature is. It reproduces in an independent cartilage "
         "cohort on a different platform, with both programme arms moving in the same direction, so the "
         "decoupling is not an artefact of the discovery cohort. But it does not distinguish lesioned "
         "from preserved cartilage within the same joint, and it separates rheumatoid arthritis from "
         "normal synovium almost as well as it separates osteoarthritis from normal synovium, so it "
         "reports a joint-level degenerative state rather than osteoarthritis specifically. Its loss is "
         "also not accompanied by promoter hypermethylation in either of two independent methylation "
         "cohorts, which argues against locked-in epigenetic silencing and is consistent with the "
         "reversible state implied by reprogramming experiments.[65] Finally, when the signature is "
         "instrumented as a single composite exposure rather than as eight separate genes, the null "
         "causal result becomes well powered: 19 instruments covering all eight genes give a smallest "
         "detectable odds ratio of about 1.04."),
'''

LEGEND10 = '''    ("Figure 10.", "Independent replication, disease specificity and two orthogonal layers. (A) The two "
     "arms of the decoupled programme in an independent cartilage cohort (GSE57218, Illumina HT-12 V3): "
     "each point is a programme gene, positioned by its log2 fold change in the discovery cohort and in "
     "GSE57218, with shaded quadrants marking directional agreement and sign-test P values for each arm. "
     "(B) The frozen signature applied to GSE57218: area under the curve for osteoarthritic versus "
     "healthy cartilage, macroscopically preserved versus healthy cartilage, and osteoarthritic versus "
     "preserved cartilage from the same joints, so that the signature can be seen to track joint status "
     "rather than lesion severity. (C) Disease specificity in GSE55235 synovium, which contains "
     "rheumatoid-arthritis as well as osteoarthritic and normal samples; the signature also separates "
     "rheumatoid arthritis from normal tissue. (D) Difference in mean methylation between osteoarthritic "
     "and normal cartilage for each signature gene, in a 27K cohort (GSE43269) and a 450K cohort "
     "(GSE73626); no gene reaches significance and the programme-level change is, if anything, "
     "hypomethylation. (E) Programme-level Mendelian randomisation in which the signature is instrumented "
     "as a single composite exposure, giving odds ratios per one standard deviation of the composite "
     "score across four FinnGen R11 phenotypes; the amber marks show the smallest odds ratio detectable "
     "at 80% power. (F) The same estimates after dropping each signature gene in turn, showing that the "
     "null is not driven by any single locus."),
'''

patch("manuscript_text2.py", [
    ("aggregate MR results paragraph",
     '        ("The genetic and transcriptomic evidence also disagree in sign. All eight signature genes are "',
     AGG_MR + '        ("The genetic and transcriptomic evidence also disagree in sign. All eight signature genes are "'),
    ("new results section",
     '    ]),\n]\n\nDISCUSSION = [',
     '    ]),\n' + NEW_SECTION + ']\n\nDISCUSSION = ['),
    ("discussion paragraph",
     '    ("Strengths and limitations", [',
     DISCUSSION_PARA + '    ]),\n    ("Strengths and limitations", ['),
])

# the legend edit above is a no-op guard; do it properly against the legends list end
src = open("manuscript_text2.py", encoding="utf-8").read()
anchor = '''     "concordant."),
]
'''
if anchor not in src:
    raise SystemExit("legend anchor missing")
src = src.replace(anchor, '''     "concordant."),
''' + LEGEND10 + ''']
''', 1)
open("manuscript_text2.py", "w", encoding="utf-8").write(src)
print("  ok  figure 10 legend appended")
print("DONE manuscript_text2.py")
