"""
step6_scrna.py — single-cell localisation of the senescence signature.
Dataset: GSE104782 (human knee articular cartilage, 10x Chromium; Ji et al. Ann Rheum Dis 2019),
1600 cells with published chondrocyte-subpopulation cluster labels.
"""
import os, gzip, json, re
import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data"); OUT = os.path.join(BASE, "results")
os.makedirs(OUT, exist_ok=True)

CLUSTER_LABEL = {
    "HomC": "Homeostatic chondrocyte",
    "ProC": "Proliferative chondrocyte",
    "preHTC": "Pre-hypertrophic chondrocyte",
    "HTC": "Hypertrophic chondrocyte",
    "RegC": "Regulatory chondrocyte",
    "FC": "Fibrocartilage chondrocyte",
    "EC": "Effector chondrocyte",
}


def main():
    counts = pd.read_csv(os.path.join(DATA, "GSE104782_allcells_UMI_count.txt.gz"),
                         sep="\t", index_col=0)
    counts = counts[~counts.index.isna()]
    counts.index = [str(i).strip() for i in counts.index]
    counts = counts[~counts.index.duplicated()]
    print("UMI matrix (genes x cells):", counts.shape)

    info = pd.read_excel(os.path.join(DATA, "GSE104782_cell_info.xlsx"))
    info = info.set_index("Cell")
    common = [c for c in counts.columns if c in info.index]
    counts = counts[common]
    info = info.loc[common]
    print("cells with cluster labels:", len(common))
    print("cluster counts:", info["Cluster"].value_counts().to_dict())

    sample = pd.Series([re.split(r"[_.]", c)[0] for c in counts.columns], index=counts.columns)
    print("sample prefixes:", sample.value_counts().to_dict())
    grp = pd.Series(["OA" if s.upper().startswith("OA") else "Normal" for s in sample], index=counts.columns)
    print("group counts:", grp.value_counts().to_dict())

    # library-size normalisation + log1p (per-cell)
    lib = counts.sum(0).replace(0, np.nan)
    norm = np.log1p(counts.div(lib, axis=1) * 1e4)

    sig = json.load(open(os.path.join(OUT, "signature.json")))
    srg = [g for g in json.load(open(os.path.join(OUT, "senescence_gene_universe.json"))) if g in norm.index]
    sig_present = [g for g in sig if g in norm.index]
    print("signature genes in scRNA:", sig_present, "| senescence universe present:", len(srg))

    # per-cell scores
    def zscore_rows(D):
        return D.sub(D.mean(1), axis=0).div(D.std(1).replace(0, np.nan), axis=0)

    zs = zscore_rows(norm)
    sen_score = zs.loc[srg].mean(0)
    sig_score = zs.loc[sig_present].mean(0)

    cells = pd.DataFrame({"cluster": info["Cluster"], "group": grp,
                          "senescence_score": sen_score, "signature_score": sig_score})
    cells.to_csv(os.path.join(OUT, "scrna_cell_scores.csv"))

    n_unlabelled = int(cells["cluster"].isna().sum())
    cells = cells[cells["cluster"].notna()].copy()
    cells["cluster"] = cells["cluster"].astype(str)
    print("cells with a cluster label:", len(cells), "| unlabelled:", n_unlabelled)

    # signature-gene mean expression per cluster
    M = pd.DataFrame({cl: norm.loc[sig_present, (cells["cluster"] == cl).reindex(norm.columns, fill_value=False)].mean(1)
                      for cl in sorted(set(cells["cluster"]))})
    M.index = sig_present
    M.columns = [f"{c}\n{CLUSTER_LABEL.get(c, c)}" for c in M.columns]
    M.to_csv(os.path.join(OUT, "scrna_signature_expression.csv"))

    # senescence score per cluster (mean over cells) + per cluster x group
    tab = cells.groupby("cluster")["senescence_score"].agg(["mean", "median", "count"])
    tab.index = [f"{c} ({CLUSTER_LABEL.get(c,c)})" for c in tab.index]
    tab.to_csv(os.path.join(OUT, "scrna_senescence_by_cluster.csv"))
    print("\nsenescence score by cluster:\n", tab.round(3).to_string())

    cross = cells.pivot_table(index="cluster", columns="group", values="senescence_score", aggfunc="mean")
    cross.to_csv(os.path.join(OUT, "scrna_senescence_cluster_group.csv"))
    print("\nsenescence score cluster x group:\n", cross.round(3).to_string())

    comp = pd.crosstab(cells["cluster"], cells["group"])
    comp.to_csv(os.path.join(OUT, "scrna_cluster_composition.csv"))
    print("\ncluster composition:\n", comp.to_string())

    # proliferative vs homeostatic contrast (biological validation of the signature)
    from scipy import stats
    a = cells.loc[cells["cluster"] == "ProC", "signature_score"]
    b = cells.loc[cells["cluster"] == "HomC", "signature_score"]
    u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
    print(f"\nProC vs HomC signature score: ProC={a.mean():.3f}, HomC={b.mean():.3f}, P={p:.3e}")
    json.dump({"ProC_mean": float(a.mean()), "HomC_mean": float(b.mean()), "P": float(p),
               "n_ProC": int(len(a)), "n_HomC": int(len(b)),
               "n_cells": int(len(cells)), "n_unlabelled": n_unlabelled,
               "n_patients": int(sample.nunique())},
              open(os.path.join(OUT, "scrna_proC_vs_homC.json"), "w"), indent=1)

    # senescence score ranked across the seven chondrocyte subpopulations
    rows = []
    for cl in sorted(set(cells["cluster"])):
        sub = cells[cells["cluster"] == cl]
        rows.append({"cluster": cl, "label": CLUSTER_LABEL.get(cl, cl), "n_cells": int(len(sub)),
                     "mean_senescence_score": float(sub["senescence_score"].mean()),
                     "mean_signature_score": float(sub["signature_score"].mean())})
    tab2 = pd.DataFrame(rows).sort_values("mean_senescence_score", ascending=False)
    tab2.to_csv(os.path.join(OUT, "scrna_group_contrast.csv"), index=False)
    print("\nsubpopulation ranking by senescence score:\n", tab2.round(4).to_string(index=False))
    print("STEP6 DONE")


if __name__ == "__main__":
    main()
