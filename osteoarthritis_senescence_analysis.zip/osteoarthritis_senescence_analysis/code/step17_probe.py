import gzip, json, os, re, subprocess, sys

print("=== 1. network probe (curl, python TLS was broken earlier) ===")
for url in ["https://eutils.ncbi.nlm.nih.gov/entrez/eutils/einfo.fcgi",
            "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE55nnn/GSE55235/matrix/",
            "https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXTID:34475573&format=json"]:
    p = subprocess.run(["curl", "-sS", "-m", "25", "-o", "NUL", "-w", "%{http_code}", url],
                       capture_output=True, text=True)
    print(f"  rc={p.returncode} code={p.stdout.strip()!r} {url}")

print("\n=== 2. cohorts.json ===")
c = json.load(open("work/cohorts.json"))
for k, v in c.items():
    print(" ", k, {kk: vv for kk, vv in v.items() if kk in ("n", "oa", "normal", "tissue", "platform")})

print("\n=== 3. GSE55235 sample groups (does it contain RA?) ===")
p = "data/GSE55235_series_matrix.txt.gz"
if os.path.exists(p):
    txt = gzip.open(p, "rt", encoding="utf-8", errors="replace").read()
    chars = [l for l in txt.split("\n") if l.startswith("!Sample_characteristics")]
    for l in chars:
        vals = l.split("\t")[1:]
        from collections import Counter
        print(f"  {l.split(chr(9))[0][:46]:48s} {dict(Counter(v.strip() for v in vals))}")
    ttl = [l for l in txt.split("\n") if l.startswith("!Sample_title")]
    if ttl:
        print("  titles:", ttl[0].split("\t")[1:11])
else:
    print("  GSE55235 series matrix not on disk")
