"""
step4_immune_drug.py — ssGSEA cell-type/immune infiltration, senescence activity scoring,
upstream transcription-factor analysis and candidate senotherapeutic drug prediction
(Enrichr DSigDB / LINCS / HDSigDB).  All gene sets are real curated libraries.
"""
import os, json, re, time
import numpy as np
import pandas as pd
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); GS = os.path.join(BASE, "genesets"); OUT = os.path.join(BASE, "results")
RNG = np.random.default_rng(20240517)


# ---------------------------------------------------------------- ssGSEA
def ssgsea_scores(expr, gene_sets, alpha=0.25, min_size=5, max_size=500):
    """Single-sample GSEA (Barbie et al. 2009) enrichment scores."""
    genes = np.array(expr.index)
    X = expr.values.astype(float)
    N = X.shape[0]
    # rank genes within each sample (1 = highest expression)
    order = np.argsort(-X, axis=0)
    ranks = np.empty_like(order)
    for j in range(X.shape[1]):
        ranks[order[:, j], j] = np.arange(1, N + 1)
    out = {}
    for name, gs in gene_sets.items():
        gs = [g for g in set(gs) if g in expr.index]
        if len(gs) < min_size or len(gs) > max_size:
            continue
        idx = np.where(np.isin(genes, gs))[0]
        mask = np.zeros(N, dtype=bool); mask[idx] = True
        n_g, n_ng = mask.sum(), N - mask.sum()
        if n_ng <= 0:
            continue
        w = np.abs(ranks) ** alpha
        w_g = w * mask[:, None]
        denom = w_g.sum(0); denom[denom == 0] = 1
        Pg = np.cumsum(w_g, axis=0) / denom
        w_ng = w * (~mask)[:, None]
        denom2 = w_ng.sum(0); denom2[denom2 == 0] = 1
        Png = np.cumsum(w_ng, axis=0) / denom2
        es = (Pg - Png).sum(0)
        out[name] = es
    return pd.DataFrame(out, index=expr.columns)


IMMUNE_TERM_PATTERNS = [
    r"\bT cell", r"\bT-cell", r"CD4", r"CD8", r"regulatory T", r"Th17", r"Th1", r"Th2",
    r"\bB cell", r"\bB-cell", r"plasma cell", r"macrophage", r"monocyte", r"dendritic",
    r"natural killer", r"\bNK cell", r"neutrophil", r"mast cell", r"eosinophil",
    r"basophil", r"myeloid", r"lymphocyte", r"leukocyte", r"microglia",
]


def immune_signatures(libs=("CellMarker_2024", "Descartes_Cell_Types_and_Tissue_2021",
                            "PanglaoDB_Augmented_2021"), max_per_lib=40, size_range=(8, 400)):
    """Collect immune-cell marker gene sets from real curated libraries."""
    sets = {}
    for lib in libs:
        p = os.path.join(GS, lib + ".json")
        if not os.path.exists(p):
            continue
        d = json.load(open(p, encoding="utf8"))
        picked = 0
        for term, genes in d.items():
            if not any(re.search(pat, term, re.I) for pat in IMMUNE_TERM_PATTERNS):
                continue
            if not (size_range[0] <= len(genes) <= size_range[1]):
                continue
            key = f"{term}"
            if key in sets:
                continue
            sets[key] = genes
            picked += 1
            if picked >= max_per_lib:
                break
    return sets


def hallmark_sets():
    p = os.path.join(GS, "MSigDB_Hallmark_2020.json")
    d = json.load(open(p, encoding="utf8")) if os.path.exists(p) else {}
    keep = ["Inflammatory Response", "IL-6/JAK/STAT3 Signaling", "TNFA Signaling Via NFKB",
            "Interferon Gamma Response", "Interferon Alpha Response", "Complement",
            "Oxidative Phosphorylation", "Glycolysis", "Apoptosis", "Cellular Senescence"]
    out = {}
    for k in keep:
        for kk in d:
            if kk.lower().replace("-", "").replace("/", "").replace(" ", "") == k.lower().replace("-", "").replace("/", "").replace(" ", ""):
                out[kk] = d[kk]
    # add senescence universe as an explicit activity score
    sen = json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))
    out["Senescence programme (curated union)"] = sen
    return out


if __name__ == "__main__":
    from step2_deg import enrichr

    expr = pd.read_csv(os.path.join(WORK, "expr_GSE114007.csv"), index_col=0)
    labels = pd.read_csv(os.path.join(WORK, "labels_GSE114007.csv"), index_col=0).iloc[:, 0]
    y = (labels == "OA").astype(int)
    signature = json.load(open(os.path.join(OUT, "signature.json")))
    srd = pd.read_csv(os.path.join(OUT, "SRDEGs.csv"), index_col=0)
    print("signature:", signature)

    # ---------------- ssGSEA: immune / cell-type infiltration
    isets = immune_signatures()
    print("immune/cell-type signature sets:", len(isets))
    infil = ssgsea_scores(expr, isets)
    infil.to_csv(os.path.join(OUT, "ssgsea_immune.csv"))
    rows = []
    for c in infil.columns:
        a = infil.loc[y == 1, c].values; b = infil.loc[y == 0, c].values
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        # rank-biserial effect size
        eff = 2 * u / (len(a) * len(b)) - 1
        rows.append({"cell_type": c, "mean_OA": a.mean(), "mean_Normal": b.mean(),
                     "delta": a.mean() - b.mean(), "p": p, "effect": eff})
    inf_tab = pd.DataFrame(rows)
    inf_tab["adjp"] = np.minimum(1, inf_tab["p"] * len(inf_tab) / inf_tab["p"].rank())
    inf_tab = inf_tab.sort_values("p")
    inf_tab.to_csv(os.path.join(OUT, "immune_infiltration_stats.csv"), index=False)
    print(inf_tab.head(20).to_string(index=False))

    # ---------------- hallmark / pathway activity
    hsets = hallmark_sets()
    print("hallmark sets:", list(hsets.keys()))
    hsc = ssgsea_scores(expr, hsets)
    hsc.to_csv(os.path.join(OUT, "ssgsea_hallmark.csv"))
    hrows = []
    for c in hsc.columns:
        a = hsc.loc[y == 1, c].values; b = hsc.loc[y == 0, c].values
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        hrows.append({"pathway": c, "mean_OA": a.mean(), "mean_Normal": b.mean(), "delta": a.mean() - b.mean(), "p": p})
    pd.DataFrame(hrows).sort_values("p").to_csv(os.path.join(OUT, "hallmark_stats.csv"), index=False)

    # ---------------- correlation: signature genes vs senescence score & immune cells
    sen_score = hsc["Senescence programme (curated union)"]
    corr_rows = []
    for g in signature:
        v = expr.loc[g]
        r, p = stats.pearsonr(v, sen_score)
        corr_rows.append({"gene": g, "r_senescence_score": r, "p": p})
    pd.DataFrame(corr_rows).to_csv(os.path.join(OUT, "signature_vs_senescence_score.csv"), index=False)

    top_cells = inf_tab.head(12)["cell_type"].tolist()
    cm = pd.DataFrame(index=signature, columns=top_cells, dtype=float)
    for g in signature:
        for c in top_cells:
            cm.loc[g, c] = stats.pearsonr(expr.loc[g], infil[c])[0]
    cm.to_csv(os.path.join(OUT, "signature_vs_immune_corr.csv"))

    # ---------------- drug prediction (real Enrichr libraries)
    DRUG_LIBS = ["DSigDB", "HDSigDB_Human_2021", "LINCS_L1000_Chem_Pert_Consensus_Sigs",
                 "Drug_Perturbations_from_GEO_up", "Drug_Perturbations_from_GEO_down"]
    drug_enr = enrichr(signature, DRUG_LIBS, "OA_senescence_signature_drugs")
    json.dump(drug_enr, open(os.path.join(OUT, "enrichr_drugs.json"), "w"), indent=1)
    for lib in DRUG_LIBS:
        print("--", lib)
        for r in drug_enr.get(lib, [])[:10]:
            print(f"     {r['term'][:65]:65s} p={r['pval']:.3g} adjp={r['adjp']:.3g} n={r['n_overlap']}")

    # ---------------- upstream TF analysis
    TF_LIBS = ["ChEA_2022", "TRRUST_Transcription_Factors_2019"]
    tf_enr = enrichr(signature, TF_LIBS, "OA_senescence_signature_TFs")
    json.dump(tf_enr, open(os.path.join(OUT, "enrichr_TFs.json"), "w"), indent=1)
    for lib in TF_LIBS:
        print("--", lib)
        for r in tf_enr.get(lib, [])[:10]:
            print(f"     {r['term'][:65]:65s} p={r['pval']:.3g} n={r['n_overlap']}")

    # ---------------- disease association enrichment
    DIS_LIBS = ["DisGeNET", "Jensen_DISEASES", "Human_Phenotype_Ontology", "GWAS_Catalog_2023"]
    dis_enr = enrichr(signature, DIS_LIBS, "OA_senescence_signature_diseases")
    json.dump(dis_enr, open(os.path.join(OUT, "enrichr_diseases.json"), "w"), indent=1)
    for lib in DIS_LIBS:
        print("--", lib)
        for r in dis_enr.get(lib, [])[:8]:
            print(f"     {r['term'][:65]:65s} p={r['pval']:.3g} n={r['n_overlap']}")

    print("STEP4 DONE")
