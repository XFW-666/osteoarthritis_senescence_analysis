"""
audit_numbers.py — trace every number in the manuscript text back to a result file.

The existing numeric audit checks ~76 hand-picked values.  This one goes the other way: it
extracts *every* number that appears anywhere in the manuscript prose and figure legends, and
flags the ones that cannot be found in any result file.  A flag does not mean the number is
wrong -- it means it is not directly traceable and needs a human to say why it is there.
"""
import csv, glob, io, json, os, re, sys
import numpy as np

import manuscript_text as T1
import manuscript_text2 as T2

OUT = "results"

# ---------------------------------------------------------------- collect manuscript text
def blocks(seq):
    out = []
    for item in seq:
        if isinstance(item, str):
            out.append(item)
        elif isinstance(item, tuple):
            for x in item:
                out.extend(blocks(x if isinstance(x, (list, tuple)) else [x]))
        elif isinstance(item, (list, tuple)):
            out.extend(blocks(item))
    return out


texts = []
texts += list(T1.ABSTRACT.values()) + list(T1.KEY_POINTS) + list(T1.INTRODUCTION)
for name, blk in T1.METHODS:
    texts += [name] + list(blk)
for name, blk in T2.RESULTS:
    texts += [name] + list(blk)
for name, blk in T2.DISCUSSION:
    texts += [name] + list(blk)
texts += list(T2.CONCLUSION) + [b for pair in T2.FIGURE_LEGENDS for b in pair]
for name, body in T2.STATEMENTS:
    texts += [name, body]
texts += [T1.TITLE]
BODY = "\n".join(t for t in texts if isinstance(t, str))

# ---------------------------------------------------------------- build the value corpus
nums = set()
ints = set()


def feed(v):
    try:
        x = float(v)
    except Exception:
        return
    if not np.isfinite(x):
        return
    for nd in (0, 1, 2, 3, 4, 5, 6):
        nums.add(round(x, nd))
        nums.add(round(abs(x), nd))
    ints.add(int(round(x)))
    m = re.match(r"^(\d\.\d+)e([+-]\d+)$", f"{x:.1e}")
    if m:
        nums.add(float(m.group(1)))


for f in glob.glob(os.path.join(OUT, "*.csv")):
    try:
        with open(f, encoding="utf-8", errors="replace") as fh:
            rd = csv.reader(fh)
            for row in rd:
                for cell in row:
                    cell = cell.strip().strip('"')
                    if re.fullmatch(r"-?\d+(\.\d+)?([eE][+-]?\d+)?", cell):
                        feed(cell)
    except Exception as e:
        print("  (could not read %s: %s)" % (f, e))

for f in glob.glob(os.path.join(OUT, "*.json")):
    def walk(o):
        if isinstance(o, dict):
            for v in o.values():
                walk(v)
        elif isinstance(o, (list, tuple)):
            for v in o:
                walk(v)
        elif isinstance(o, (int, float)) and not isinstance(o, bool):
            feed(o)
        elif isinstance(o, str):
            m = re.fullmatch(r"-?\d+(\.\d+)?([eE][+-]?\d+)?", o.strip())
            if m:
                feed(o)
    try:
        walk(json.load(open(f, encoding="utf-8")))
    except Exception:
        pass

# counts that are properties of the design rather than of a data file
DESIGN = set()
for f in glob.glob(os.path.join(OUT, "*.csv")) + glob.glob(os.path.join(OUT, "*.json")):
    pass

print(f"corpus: {len(nums)} distinct rounded values, {len(ints)} integers")

# ---------------------------------------------------------------- extract text numbers
# scientific notation written as "3.6 x 10^-26"
sci = re.compile(r"(\d+(?:\.\d+)?)\s*[x×]\s*10\^(-?\d+)")
plain = re.compile(r"(?<![\w.])(\d+(?:[.,]\d+)?)(?![\w.])")

unmatched = []
seen_ctx = set()
for m in sci.finditer(BODY):
    mant = float(m.group(1))
    if round(mant, 6) not in nums and round(mant, 4) not in nums:
        unmatched.append((m.group(0), BODY[max(0, m.start() - 60):m.end() + 25].replace("\n", " ")))

for m in plain.finditer(BODY):
    raw = m.group(1)
    s = raw.replace(",", ".")
    try:
        v = float(s)
    except ValueError:
        continue
    iv = int(round(v))
    if v in nums or iv in ints:
        continue
    ctx = BODY[max(0, m.start() - 70):m.end() + 40].replace("\n", " ")
    key = (raw, ctx[:60])
    if key in seen_ctx:
        continue
    seen_ctx.add(key)
    unmatched.append((raw, ctx))

print(f"\nuntraceable numbers: {len(unmatched)}\n")
for val, ctx in unmatched:
    print(f"  [{val:>10s}]  ...{ctx}...")
