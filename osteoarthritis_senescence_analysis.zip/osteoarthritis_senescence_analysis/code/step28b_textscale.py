"""Report the effective scale at which each figure is placed in the PDF."""
import fitz, os
from PIL import Image

CANVAS = {"Figure1": 7.2, "Figure2": 16.6, "Figure3": 16.8, "Figure4": 15.8, "Figure5": 16.6,
          "Figure6": 16.8, "Figure7": 16.8, "Figure8": 16.8, "Figure9": 17.0, "Figure10": 16.8}
LABEL_PT = 8.0

d = fitz.open("Osteoarthritis_senescence_manuscript.pdf")
print(f"{'page':>5} {'figure':10} {'placed (pt)':>18} {'scale':>7} {'8pt -> on page':>15}")
seen = set()
for pno, page in enumerate(d, 1):
    for info in page.get_image_info():
        r = fitz.Rect(info["bbox"])
        if r.width < 20:
            continue
        best = None
        for f in sorted(os.listdir("figures")):
            if not f.lower().endswith(".png"):
                continue
            im = Image.open(os.path.join("figures", f))
            if abs(im.height / im.width - r.height / r.width) < 0.03:
                best = f
                break
        if not best or best in seen:
            continue
        seen.add(best)
        canvas_in = CANVAS.get(best.split("_")[0], 16.8)
        scale = (r.width / 72.0) / canvas_in
        print(f"{pno:>5} {best.split('_')[0]:10} {r.width:>8.1f} x {r.height:<7.1f} "
              f"{scale:>7.3f} {LABEL_PT * scale:>13.2f} pt")
print("\nplaced widths are in PDF points (72 pt = 1 inch)")
