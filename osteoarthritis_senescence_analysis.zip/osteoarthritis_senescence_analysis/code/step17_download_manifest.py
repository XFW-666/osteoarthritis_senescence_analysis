import os, subprocess

OUT = "data/extra"
os.makedirs(OUT, exist_ok=True)
FILES = {
    "GPL8490_HumanMethylation27_270596_v.1.2.csv.gz":
        "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL8nnn/GPL8490/suppl/GPL8490_HumanMethylation27_270596_v.1.2.csv.gz",
    "GPL13534_HumanMethylation450_15017482_v.1.1.csv.gz":
        "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL13nnn/GPL13534/suppl/GPL13534_HumanMethylation450_15017482_v.1.1.csv.gz",
    "GPL20844_072363_D_GEO_20150612.txt.gz":
        "https://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL20nnn/GPL20844/suppl/GPL20844_072363_D_GEO_20150612.txt.gz",
}
for name, url in FILES.items():
    dest = os.path.join(OUT, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 1000:
        print(f"have {name} ({os.path.getsize(dest):,})")
        continue
    tmp = dest + ".part"
    p = subprocess.run(["curl", "-sS", "-L", "-m", "1800", "-o", tmp, url])
    if p.returncode == 0 and os.path.exists(tmp) and os.path.getsize(tmp) > 1000:
        os.replace(tmp, dest)
        print(f"got {name} ({os.path.getsize(dest):,})")
    else:
        print(f"FAIL {name}")
        if os.path.exists(tmp):
            os.remove(tmp)
print("MANIFEST DOWNLOADS DONE")
