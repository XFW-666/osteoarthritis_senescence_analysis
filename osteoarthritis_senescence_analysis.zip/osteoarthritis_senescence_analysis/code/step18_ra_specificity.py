"""
step18_ra_specificity.py — is the senescence signature specific to osteoarthritis, or does it
merely mark an inflamed joint?

GSE55235 (which the validation pipeline used only for its OA and healthy arms) also contains ten
rheumatoid-arthritis synovial samples.  That gives a free disease-specificity control: if the
signature separates OA from healthy tissue but not OA from rheumatoid arthritis, it is reporting
joint inflammation rather than osteoarthritis.
"""
import os, json, warnings
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

import step1_prepare as P
from step3d_external import ssgsea_score   # same statistic the validation pipeline reports

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data"); OUT = os.path.join(BASE, "results")
WORK = os.path.join(BASE, "work")


def boot_ci(y, p, n=2000, seed=1):
    rng = np.random.default_rng(seed); a = []
    y = np.asarray(y); p = np.asarray(p)
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if len(set(y[i])) < 2:
            continue
        a.append(roc_auc_score(y[i], p[i]))
    return np.percentile(a, [2.5, 97.5]) if a else np.array([np.nan, np.nan])


def lab3(row):
    t = P._chars(row)
    if "rheumatoid" in t:
        return "RA"
    if "osteoarthrit" in t:
        return "OA"
    if "healthy" in t:
        return "Normal"
    return None


def main():
    sig = json.load(open(os.path.join(OUT, "signature.json")))
    srg = json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))
    coefs = pd.read_csv(os.path.join(OUT, "signature_coefficients.csv"))
    print("signature:", sig)

    # --- discovery cohort, to refit the frozen model exactly as the validation pipeline does
    disc = pd.read_csv(os.path.join(WORK, "expr_GSE114007.csv"), index_col=0)
    dl = pd.read_csv(os.path.join(WORK, "labels_GSE114007.csv"), index_col=0).iloc[:, 0]
    dy = (dl == "OA").astype(int).values

    # --- GSE55235 with all three arms retained
    expr, meta = P.parse_series_matrix(os.path.join(DATA, "GSE55235_series_matrix.txt.gz"))
    plat = P.parse_platform_soft(os.path.join(DATA, "GPL96_soft.txt"))
    symcol = next(c for c in plat.columns
                  if c.strip().lower() in ("gene symbol", "genesymbol", "gene_symbol"))
    probe2sym = dict(zip(plat.iloc[:, 0], plat[symcol]))
    expr = P.collapse_to_symbols(P.quantile_normalize(P.log2_if_needed(expr)), probe2sym)
    # guard against duplicated sample columns, which would desynchronise the frame from the labels
    expr = expr.loc[:, ~expr.columns.duplicated()]
    meta = meta.set_index("gsm")
    grp = pd.Series({c: lab3(meta.loc[c]) for c in expr.columns}, name="group")
    keep = grp[grp.notna()].index
    expr, grp = expr.loc[:, keep], grp.loc[keep]
    assert list(expr.columns) == list(grp.index), "sample columns and labels are out of step"
    print("GSE55235 three-arm composition:", dict(grp.value_counts()))

    z = lambda D: ((D - D.mean()) / D.std().replace(0, np.nan)).fillna(0.0)
    present = [g for g in sig if g in expr.index]
    print(f"signature genes present on GPL96: {len(present)}/{len(sig)} -> {present}")
    model = LogisticRegression(max_iter=5000, C=1.0).fit(z(disc.loc[present].T).values, dy)
    pr = pd.Series(model.predict_proba(z(expr.loc[present].T).values)[:, 1], index=expr.columns)

    # --- contrasts
    CONTRASTS = [("OA", "Normal"), ("OA", "RA"), ("RA", "Normal")]
    rows = []
    for a, b in CONTRASTS:
        sel = grp.isin([a, b])
        y = (grp[sel] == a).astype(int).values
        p = pr[sel].values
        auc = roc_auc_score(y, p); lo, hi = boot_ci(y, p)
        # ssGSEA needs the whole cohort's ranking, so score the full frame then subset
        sen_all = ssgsea_score(expr, srg)
        sen = sen_all.loc[grp[sel].index].values
        auc_s = roc_auc_score(y, sen); los, his = boot_ci(y, sen)
        n_dir = sum(1 for g in present
                    if np.sign(expr.loc[g, grp == a].mean() - expr.loc[g, grp == b].mean())
                    == np.sign(disc.loc[g, dl == "OA"].mean() - disc.loc[g, dl == "Normal"].mean()))
        rows.append({"contrast": f"{a} vs {b}", "n_a": int((grp[sel] == a).sum()),
                     "n_b": int((grp[sel] == b).sum()),
                     "panel_AUC": auc, "ci_lo": lo, "ci_hi": hi,
                     "senescence_score_AUC": auc_s, "score_ci_lo": los, "score_ci_hi": his,
                     "direction_consistent_vs_discovery": n_dir, "n_genes": len(present)})
        print(f"  {a} vs {b:6s}  n={int(sel.sum()):2d}  panel AUC={auc:.3f} [{lo:.3f},{hi:.3f}]  "
              f"score AUC={auc_s:.3f} [{los:.3f},{his:.3f}]  direction {n_dir}/{len(present)}")
    res = pd.DataFrame(rows)
    res.to_csv(os.path.join(OUT, "ra_specificity.csv"), index=False)

    # --- per-gene group means, for the figure
    per_gene = []
    for g in present:
        row = {"gene": g, "logFC_discovery_OA_vs_normal": float(
            disc.loc[g, dl == "OA"].mean() - disc.loc[g, dl == "Normal"].mean())}
        for a in ("Normal", "OA", "RA"):
            row[f"mean_{a}"] = float(expr.loc[g, grp == a].mean())
        row["delta_OA_vs_normal"] = row["mean_OA"] - row["mean_Normal"]
        row["delta_OA_vs_RA"] = row["mean_OA"] - row["mean_RA"]
        per_gene.append(row)
    pg = pd.DataFrame(per_gene)
    pg.to_csv(os.path.join(OUT, "ra_specificity_per_gene.csv"), index=False)
    print("\nper-gene group means:\n", pg.round(3).to_string(index=False))

    oa_ra = res[res.contrast == "OA vs RA"].iloc[0]
    oa_no = res[res.contrast == "OA vs Normal"].iloc[0]
    ra_no = res[res.contrast == "RA vs Normal"].iloc[0]
    summary = {"n_RA": int((grp == "RA").sum()), "n_OA": int((grp == "OA").sum()),
               "n_Normal": int((grp == "Normal").sum()),
               "auc_OA_vs_Normal": float(oa_no.panel_AUC),
               "auc_OA_vs_RA": float(oa_ra.panel_AUC),
               "auc_RA_vs_Normal": float(ra_no.panel_AUC),
               "genes_present": present,
               "direction_consistent_OA_vs_RA": int(oa_ra.direction_consistent_vs_discovery)}
    json.dump(summary, open(os.path.join(OUT, "ra_specificity.json"), "w"), indent=1)
    print("\nSTEP18 DONE")


if __name__ == "__main__":
    main()
