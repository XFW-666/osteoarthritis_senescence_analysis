"""
step3d_external.py — external validation of the frozen signature across every available
independent cohort: multi-gene panel AUC, senescence-programme ssGSEA AUC, and the
direction consistency of each signature gene.  Also reports platform annotation coverage.
"""
import os, json, warnings
import numpy as np, pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); OUT = os.path.join(BASE, "results")


def boot_ci(y, p, n=2000, seed=1):
    rng = np.random.default_rng(seed); a = []
    y = np.asarray(y); p = np.asarray(p)
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if len(set(y[i])) < 2:
            continue
        a.append(roc_auc_score(y[i], p[i]))
    return (np.percentile(a, [2.5, 97.5]) if a else np.array([np.nan, np.nan]))


def ssgsea_score(expr, gene_set, alpha=0.25):
    genes = np.array(expr.index)
    gs = [g for g in set(gene_set) if g in expr.index]
    X = expr.values.astype(float); N = X.shape[0]
    order = np.argsort(-X, axis=0)
    ranks = np.empty_like(order)
    for j in range(X.shape[1]):
        ranks[order[:, j], j] = np.arange(1, N + 1)
    mask = np.zeros(N, dtype=bool); mask[np.isin(genes, gs)] = True
    w = np.abs(ranks) ** alpha
    wg = w * mask[:, None]; wng = w * (~mask)[:, None]
    Pg = np.cumsum(wg, axis=0) / np.maximum(wg.sum(0), 1e-12)
    Png = np.cumsum(wng, axis=0) / np.maximum(wng.sum(0), 1e-12)
    return pd.Series((Pg - Png).sum(0), index=expr.columns)


def load(acc):
    e = pd.read_csv(os.path.join(WORK, f"expr_{acc}.csv"), index_col=0)
    l = pd.read_csv(os.path.join(WORK, f"labels_{acc}.csv"), index_col=0).iloc[:, 0]
    return e, l


def main():
    expr, labels = load("GSE114007")
    y = (labels == "OA").astype(int).values
    sig = json.load(open(os.path.join(OUT, "signature.json")))
    srg = json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))
    print("signature:", sig)

    rows, preds = [], {}
    for acc in ["GSE169077", "GSE283079", "GSE55235", "GSE55457"]:
        p = os.path.join(WORK, f"expr_{acc}.csv")
        if not os.path.exists(p):
            print("missing cohort", acc); continue
        e2, l2 = load(acc)
        y2 = (l2 == "OA").astype(int).values
        present = [g for g in sig if g in e2.index]
        if len(present) < 3:
            print(f"{acc}: only {len(present)} signature genes present -> skipped"); continue
        z = lambda D: ((D - D.mean()) / D.std().replace(0, np.nan)).fillna(0.0)
        m = LogisticRegression(max_iter=5000, C=1.0).fit(z(expr.loc[present].T).values, y)
        pr = m.predict_proba(z(e2.loc[present].T).values)[:, 1]
        auc = roc_auc_score(y2, pr); lo, hi = boot_ci(y2, pr)
        sc = ssgsea_score(e2, srg).values
        auc_s = roc_auc_score(y2, sc); los, his = boot_ci(y2, sc)
        n_ok = 0
        for g in present:
            d1 = expr.loc[g, labels == "OA"].mean() - expr.loc[g, labels == "Normal"].mean()
            d2 = e2.loc[g, l2 == "OA"].mean() - e2.loc[g, l2 == "Normal"].mean()
            ok = np.sign(d1) == np.sign(d2)
            n_ok += int(ok)
            a1 = roc_auc_score(y2, e2.loc[g].values)
            rows.append({"cohort": acc, "gene": g, "auc_single": a1, "auc_abs": max(a1, 1 - a1),
                         "direction_consistent": bool(ok)})
        rows.append({"cohort": acc, "gene": "MULTI-GENE SIGNATURE", "auc_single": auc, "auc_abs": auc,
                     "ci_lo": lo, "ci_hi": hi, "n": int(len(y2)), "n_oa": int(y2.sum()),
                     "genes_present": len(present), "n_signature": len(sig)})
        rows.append({"cohort": acc, "gene": "SENESCENCE SCORE (ssGSEA)", "auc_single": auc_s, "auc_abs": auc_s,
                     "ci_lo": los, "ci_hi": his, "n": int(len(y2)), "n_oa": int(y2.sum())})
        preds[acc] = {"y": y2.tolist(), "p": pr.tolist(), "auc": float(auc), "ci": [float(lo), float(hi)],
                      "genes_present": present, "auc_score": float(auc_s), "ci_score": [float(los), float(his)],
                      "n": int(len(y2)), "n_oa": int(y2.sum()),
                      "direction_consistent": int(n_ok), "n_present": len(present)}
        print(f"{acc}: n={len(y2)} (OA={int(y2.sum())}) panel AUC={auc:.3f} [{lo:.3f},{hi:.3f}] "
              f"(genes {len(present)}/{len(sig)}) | senescence-score AUC={auc_s:.3f} [{los:.3f},{his:.3f}] "
              f"| direction-consistent {n_ok}/{len(present)}")
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "external_validation.csv"), index=False)
    json.dump(preds, open(os.path.join(OUT, "external_predictions.json"), "w"), indent=1)

    dc = []
    for acc, d in preds.items():
        dc.append({"cohort": acc, "genes_present": d["n_present"],
                   "direction_consistent": d["direction_consistent"],
                   "pct_consistent": 100 * d["direction_consistent"] / max(d["n_present"], 1)})
    pd.DataFrame(dc).to_csv(os.path.join(OUT, "direction_consistency.csv"), index=False)
    print("STEP3D DONE")


if __name__ == "__main__":
    main()
