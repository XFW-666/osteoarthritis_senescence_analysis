"""
step14_eqtlgen_mr_coloc.py — two upgrades over the GTEx-based analysis:

1. Mendelian randomisation using eQTLGen blood cis-eQTLs (n = 31,684), which supply multiple
   independent instruments per gene instead of one, so the causal estimate is informative rather
   than merely underpowered.  eQTLGen reports a Z score per SNP; the per-allele effect on
   standardised expression is recovered as beta = Z / sqrt(2 f (1-f) N) with f the allele
   frequency, and se = 1 / sqrt(2 f (1-f) N).

2. Colocalisation (coloc.abf, Giambartolomei et al.) between each gene's cis-eQTL signal and the
   osteoarthritis signal, i.e. whether the two share a single causal variant.  Implemented from the
   published approximate Bayes factor formulation.
"""
import os, sys, json, math, gzip, time
import numpy as np
import pandas as pd
import urllib.request, ssl
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
from tabix_http import TabixHTTP, download, _http_range, bgzf_decompress

DATA = os.path.join(BASE, "data"); OUT = os.path.join(BASE, "results")
GWAS = os.path.join(DATA, "gwas")
CTX = ssl.create_default_context(); UA = {"User-Agent": "Mozilla/5.0"}
EQTLGEN = os.path.join(DATA, "eqtlgen_cis_eqtl_fdr05.txt.gz")

GENES = ["ETS2", "GADD45B", "JUN", "CDKN1B", "UBC", "CDKN1A", "HLA-F", "CDK2"]
FINNGEN = {"M13_ARTHROSIS": "Arthrosis, all sites",
           "M13_ARTHROSIS_KNEE": "Gonarthrosis (knee OA)",
           "M13_ARTHTROSIS_COX": "Coxarthrosis (hip OA)",
           "M13_ARTHROSIS_KNEE_PRIM_KNEESURG": "Knee OA requiring surgery"}
CLUMP_WINDOW = 250_000
MAX_INSTRUMENTS = 12
MAX_COLOC_SNPS = 4000


# ------------------------------------------------------------------ eQTLGen
def load_eqtlgen(genes=GENES):
    rows = {g: [] for g in genes}
    with gzip.open(EQTLGEN, "rt", encoding="utf8", errors="ignore") as f:
        f.readline()
        for line in f:
            p = line.rstrip("\n").split("\t")
            if len(p) < 15 or p[8] not in rows:
                continue
            try:
                rows[p[8]].append((p[1], p[2], int(p[3]), p[4].upper(), p[5].upper(),
                                   float(p[6]), float(p[0]), int(p[12])))
            except Exception:
                continue
    out = {}
    for g, v in rows.items():
        if not v:
            continue
        df = pd.DataFrame(v, columns=["snp", "chrom", "pos", "assessed", "other",
                                      "z", "p", "n"])
        df = df.drop_duplicates("snp")
        out[g] = df
    return out


def clump(df, window=CLUMP_WINDOW):
    df = df.sort_values("p")
    keep = []
    for _, r in df.iterrows():
        if all(abs(int(r["pos"]) - int(k["pos"])) > window for k in keep):
            keep.append(r)
    return pd.DataFrame(keep)


# ------------------------------------------------------------------ coloc.abf
def _logsum(v):
    v = np.asarray(v, float)
    m = np.nanmax(v)
    if not np.isfinite(m):
        return -np.inf
    return m + np.log(np.nansum(np.exp(v - m)))


def _logdiff(a, b):
    """log(exp(a) - exp(b)) for a >= b."""
    if b >= a:
        return -np.inf
    return a + math.log1p(-math.exp(b - a))


def coloc_abf(beta1, varbeta1, maf1, beta2, varbeta2, s2, type1="quant", type2="cc",
              p1=1e-4, p2=1e-4, p12=1e-5, sd_prior1=0.15, sd_prior2=0.2):
    """Posterior probabilities PP0-PP4 for five colocalisation hypotheses."""
    ok = (np.isfinite(beta1) & np.isfinite(varbeta1) & (varbeta1 > 0) &
          np.isfinite(beta2) & np.isfinite(varbeta2) & (varbeta2 > 0) &
          np.isfinite(maf1) & (maf1 > 0.01) & (maf1 < 0.99))
    if ok.sum() < 10:
        return None
    b1, v1, f1 = beta1[ok], varbeta1[ok], maf1[ok]
    b2, v2 = beta2[ok], varbeta2[ok]
    W1, W2 = sd_prior1 ** 2, sd_prior2 ** 2
    z1 = b1 / np.sqrt(v1)
    z2 = b2 / np.sqrt(v2)
    lABF1 = 0.5 * np.log(v1 / (v1 + W1)) + 0.5 * z1 ** 2 * W1 / (v1 + W1)
    lABF2 = 0.5 * np.log(v2 / (v2 + W2)) + 0.5 * z2 ** 2 * W2 / (v2 + W2)
    l1, l2 = _logsum(lABF1), _logsum(lABF2)
    lH4 = _logsum(lABF1 + lABF2)
    lH3 = l1 + l2 + _logdiff(0.0, lH4 - l1 - l2)
    lH0 = 0.0
    lH1 = l1 + math.log(p1)
    lH2 = l2 + math.log(p2)
    lH3 = lH3 + math.log(p12)
    lH4 = lH4 + math.log(p12)
    denom = _logsum([lH0, lH1, lH2, lH3, lH4])
    pp = [math.exp(x - denom) for x in (lH0, lH1, lH2, lH3, lH4)]
    return {"n_snp": int(ok.sum()), "PP0": pp[0], "PP1": pp[1], "PP2": pp[2],
            "PP3": pp[3], "PP4": pp[4]}


# ------------------------------------------------------------------ MR
def ivw(r, s):
    w = 1.0 / np.square(s)
    return float(np.sum(w * r) / np.sum(w)), float(math.sqrt(1.0 / np.sum(w)))


def mr_egger(bx, by, sy):
    w = 1.0 / np.square(sy)
    X = np.column_stack([np.ones(len(bx)), bx]); W = np.diag(w)
    c = np.linalg.pinv(X.T @ W @ X) @ (X.T @ W @ by)
    resid = by - X @ c
    dof = max(len(bx) - 2, 1)
    s2 = float((w * resid ** 2).sum() / dof)
    cov = s2 * np.linalg.pinv(X.T @ W @ X)
    return float(c[1]), float(math.sqrt(max(cov[1, 1], 0))), float(c[0]), float(math.sqrt(max(cov[0, 0], 0)))


def wmedian(r, s):
    w = 1.0 / np.square(s); o = np.argsort(r)
    rr, ww = np.asarray(r)[o], w[o]
    cw = np.cumsum(ww) / np.sum(ww)
    k = int(np.searchsorted(cw, 0.5))
    return float(rr[min(k, len(rr) - 1)]), float(math.sqrt(1.0 / np.sum(ww)))


def cochran_q(r, s):
    w = 1.0 / np.square(s)
    b = float(np.sum(w * r) / np.sum(w))
    q = float(np.sum(w * (np.asarray(r) - b) ** 2))
    dof = max(len(r) - 1, 1)
    return q, dof, float(stats.chi2.sf(q, dof))


def _get(u, tries=4):
    for a in range(tries):
        try:
            return json.loads(urllib.request.urlopen(
                urllib.request.Request(u, headers=UA), timeout=90, context=CTX).read())
        except Exception:
            time.sleep(2)
    return None


def hg38_locus(gene):
    """eQTLGen is on GRCh37 and FinnGen R11 on GRCh38, so the FinnGen window is taken from the
    GRCh38 gene coordinates and the two data sets are joined on rsID rather than position."""
    j = _get(f"https://gtexportal.org/api/v2/reference/gene?geneId={gene}")
    d = j["data"][0]
    return d["chromosome"].replace("chr", ""), int(d["start"]), int(d["end"])


def main():
    print("=" * 100); print("1. eQTLGen exposure (GRCh37; joined to FinnGen on rsID)")
    exp = load_eqtlgen()
    for g, df in exp.items():
        pmin = df["p"].min()
        print(f"   {g:9s} n={len(df):>6d}  |Z|max={df['z'].abs().max():6.1f}  "
              f"p_min={pmin:.3g} (implies |Z|={abs(stats.norm.isf(pmin/2)):.1f})  "
              f"N={int(df['n'].max())}")

    tb = {}
    for pheno in FINNGEN:
        url = ("https://storage.googleapis.com/finngen-public-data-r11/summary_stats/"
               f"finngen_R11_{pheno}.gz")
        tbi = download(url + ".tbi", os.path.join(GWAS, f"finngen_R11_{pheno}.gz.tbi"))
        tb[pheno] = TabixHTTP(url, tbi)

    mr_rows, coloc_rows, snp_rows = [], [], []
    for gene, df in exp.items():
        try:
            chrom, gstart, gend = hg38_locus(gene)
        except Exception:
            print(f"\n{gene}: could not resolve the GRCh38 locus"); continue
        inst = clump(df[df["p"] < 5e-8])
        if len(inst) > MAX_INSTRUMENTS:
            inst = inst.head(MAX_INSTRUMENTS)
        pad = 1_500_000
        lo, hi = gstart - pad, gend + pad
        print(f"\n2. {gene}: {len(df)} cis-eQTLs -> {len(inst)} instruments (p<5e-8, clumped 250 kb)")
        print(f"   FinnGen window chr{chrom}:{lo}-{hi} (GRCh38), joined on rsID")
        if not len(inst):
            continue
        for pheno, t in tb.items():
            try:
                hits = t.fetch(chrom, lo, hi)
            except Exception as e:
                print(f"   {pheno}: fetch failed {type(e).__name__} {str(e)[:50]}"); continue
            by_rs = {}
            for f in hits:
                try:
                    b_out, se_out, af = float(f[8]), float(f[9]), float(f[10])
                except Exception:
                    continue
                for rs in f[4].split(","):
                    rs = rs.strip()
                    if rs:
                        by_rs.setdefault(rs, (f[2].upper(), f[3].upper(), b_out, se_out, af))

            def match(row):
                hit = by_rs.get(row["snp"])
                if not hit:
                    return None
                fr, fa, b_out, se_out, af = hit
                ra, oa = row["assessed"], row["other"]
                if (fr, fa) == (ra, oa):
                    sign = 1
                elif (fr, fa) == (oa, ra):
                    sign = -1
                else:
                    return None
                return (sign * b_out, se_out, (af if 0 < af < 1 else np.nan))

            rows = []
            for _, r in inst.iterrows():
                m = match(r)
                if not m:
                    continue
                b_out, se_out, f = m
                denom = math.sqrt(2 * f * (1 - f) * int(r["n"])) if np.isfinite(f) else np.nan
                if not np.isfinite(denom) or denom <= 0:
                    continue
                rows.append({"gene": gene, "phenotype": pheno, "snp": r["snp"], "chrom": chrom,
                             "af": f, "z_eqtl": r["z"], "p_eqtl": r["p"],
                             "b_eqtl": r["z"] / denom, "se_eqtl": 1.0 / denom,
                             "b_oa": b_out, "se_oa": se_out,
                             "ratio": b_out / (r["z"] / denom),
                             "se_ratio": abs(se_out / (r["z"] / denom)),
                             "F": (r["z"]) ** 2})
            if not rows:
                print(f"   {pheno}: no harmonised instruments"); continue
            d = pd.DataFrame(rows); snp_rows.append(d)
            r_, s_ = d["ratio"].values, d["se_ratio"].values
            if len(d) == 1:
                b, se, method = float(r_[0]), float(s_[0]), "Wald ratio"
                egg = (np.nan,) * 4; med = (np.nan, np.nan); q = (np.nan, np.nan, np.nan)
            else:
                b, se = ivw(r_, s_); method = f"IVW ({len(d)})"
                egg = mr_egger(d["b_eqtl"].values, d["b_oa"].values, d["se_oa"].values) \
                    if len(d) >= 3 else (np.nan,) * 4
                med = wmedian(r_, s_) if len(d) >= 3 else (np.nan, np.nan)
                q = cochran_q(r_, s_)
            p = 2 * stats.norm.sf(abs(b / se)) if se > 0 else np.nan
            mr_rows.append({"gene": gene, "phenotype": pheno, "n_snp": len(d), "method": method,
                            "OR": math.exp(b), "OR_lo": math.exp(b - 1.96 * se),
                            "OR_hi": math.exp(b + 1.96 * se), "beta": b, "se": se, "p": p,
                            "F_mean": float(d["F"].mean()),
                            "detectable_OR_80pct": math.exp(2.802 * se),
                            "egger_intercept": egg[2], "egger_intercept_se": egg[3],
                            "wmed_beta": med[0], "Q": q[0], "Q_p": q[2]})
            print(f"   -> {pheno:34s} {method:12s} OR={math.exp(b):.3f} "
                  f"({math.exp(b-1.96*se):.3f}-{math.exp(b+1.96*se):.3f}) p={p:.3g} "
                  f"meanF={d['F'].mean():.0f}")

            # ---- colocalisation on the cis region
            sub = df.head(MAX_COLOC_SNPS)
            b1, v1, f1, b2, v2 = [], [], [], [], []
            for _, r in sub.iterrows():
                m = match(r)
                if not m:
                    continue
                b_out, se_out, f = m
                denom = math.sqrt(2 * f * (1 - f) * int(r["n"])) if np.isfinite(f) else np.nan
                if not np.isfinite(denom) or denom <= 0:
                    continue
                b1.append(r["z"] / denom); v1.append(1.0 / denom ** 2); f1.append(f)
                b2.append(b_out); v2.append(se_out ** 2)
            if len(b1) >= 10:
                res = coloc_abf(np.array(b1), np.array(v1), np.array(f1),
                                np.array(b2), np.array(v2), 0.25)
                if res:
                    res.update({"gene": gene, "phenotype": pheno})
                    coloc_rows.append(res)
                    print(f"      coloc: n={res['n_snp']:>5d}  PP.H4={res['PP4']:.3f}  "
                          f"PP.H3={res['PP3']:.3f}  PP.H1={res['PP1']:.3f}  PP.H2={res['PP2']:.3f}")

    mr = pd.DataFrame(mr_rows)
    if len(mr):
        o = np.argsort(mr["p"].values); n = len(mr)
        adj = np.empty(n)
        ranked = mr["p"].values[o] * n / (np.arange(n) + 1)
        ranked = np.minimum.accumulate(ranked[::-1])[::-1]
        adj[o] = np.clip(ranked, 0, 1)
        mr["p_fdr"] = adj
    mr.to_csv(os.path.join(OUT, "mr_eqtlgen_results.csv"), index=False)
    if snp_rows:
        pd.concat(snp_rows, ignore_index=True).to_csv(
            os.path.join(OUT, "mr_eqtlgen_instruments.csv"), index=False)
    cl = pd.DataFrame(coloc_rows)
    cl.to_csv(os.path.join(OUT, "coloc_results.csv"), index=False)
    print("\n" + "=" * 100)
    print(mr.round(4).to_string(index=False) if len(mr) else "no MR estimates")
    print()
    print(cl.round(4).to_string(index=False) if len(cl) else "no coloc results")
    print(f"\nwrote mr_eqtlgen_results.csv ({len(mr)}), mr_eqtlgen_instruments.csv, "
          f"coloc_results.csv ({len(cl)})")


if __name__ == "__main__":
    main()
