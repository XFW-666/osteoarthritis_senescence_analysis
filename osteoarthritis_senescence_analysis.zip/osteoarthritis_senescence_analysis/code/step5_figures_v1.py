"""
step5_figures_v1.py — faithful re-creation of the FIRST figure set (v1) so the earlier
manuscript can be compared with the redesigned one (v2).

v1 grammar: every figure is a uniform 2x3 (or 2x2 / 3x3) grid of equal-weight panels built
from the same small vocabulary of bar / heatmap / scatter / ROC / box forms.
Writes to figures_v1/.
"""
import os, sys, json
import numpy as np
import pandas as pd
from scipy import stats
from scipy.cluster import hierarchy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
import matplotlib.patheffects as pe
import networkx as nx
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_curve, roc_auc_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from viz_style import (NEON, CYCLE, BG, GRID, TXT, MUTED, ACCENT, apply_style,
                       neon_axes, neon_line, neon_scatter, neon_bar, neon_text, save, add_sig)
import fig_helpers as H

BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); OUT = os.path.join(BASE, "results")
FIG = os.path.join(BASE, "figures_v1"); os.makedirs(FIG, exist_ok=True)
apply_style()


def load(acc):
    e = pd.read_csv(os.path.join(WORK, f"expr_{acc}.csv"), index_col=0)
    l = pd.read_csv(os.path.join(WORK, f"labels_{acc}.csv"), index_col=0).iloc[:, 0]
    return e, l


def J(n):
    return json.load(open(os.path.join(OUT, n), encoding="utf8"))


def bubble(ax, terms, pvals, ratios, colors, title, top=10):
    order = np.argsort(pvals)[:top]
    terms = [terms[i] for i in order]; pvals = np.array([pvals[i] for i in order])
    ratios = np.array([ratios[i] for i in order])
    y = np.arange(len(terms))[::-1]
    sizes = 45 + 330 * (ratios / max(ratios.max(), 1))
    vals = -np.log10(np.clip(pvals, 1e-300, None))
    for yy, s, v, col in zip(y, sizes, vals, colors):
        ax.scatter(v, yy, s=s, color=col, alpha=0.92, zorder=4, edgecolors="#FFFFFF", linewidths=0.7)
    ax.set_yticks(y); ax.set_yticklabels([t[:46] for t in terms], fontsize=8)
    ax.set_xlabel("$-\\log_{10}$ P"); ax.set_title(title, color=TXT, fontsize=10)
    ax.grid(axis="x", alpha=0.5); ax.grid(axis="y", visible=False)
    neon_axes(ax)


# ==================================================================== FIGURE 2 (v1)
def figure2():
    expr, labels = load("GSE114007")
    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)
    cohorts = json.load(open(os.path.join(WORK, "cohorts.json"), encoding="utf8"))
    srg = set(J("senescence_gene_universe.json"))
    y = (labels == "OA").astype(int).values

    fig = plt.figure(figsize=(16.4, 10.0), facecolor=BG)
    gs = fig.add_gridspec(2, 3, hspace=0.46, wspace=0.34, left=0.055, right=0.98,
                          top=0.93, bottom=0.09)
    ax = fig.add_subplot(gs[0, 0]); neon_axes(ax)
    keys = [k for k in ["GSE114007", "GSE169077", "GSE283079", "GSE55235", "GSE55457"] if k in cohorts]
    oa = [cohorts[k]["oa"] for k in keys]; no = [cohorts[k]["normal"] for k in keys]
    yy = np.arange(len(keys))[::-1]
    neon_bar(ax, yy + 0.19, oa, NEON["magenta"], width=0.34, label="OA")
    neon_bar(ax, yy - 0.19, no, NEON["blue"], width=0.34, label="Normal / non-OA")
    ax.set_yticks(yy)
    ax.set_yticklabels([f"{k}  ({cohorts[k]['oa']} vs {cohorts[k]['normal']})\n"
                        f"{cohorts[k]['tissue']} · {'RNA-seq' if 'RNA' in cohorts[k]['platform'] else 'microarray'}"
                        for k in keys], fontsize=7.6)
    ax.set_xlabel("Number of samples"); ax.set_title("Discovery and validation cohorts")
    ax.legend(loc="lower right"); ax.set_xlim(0, max(oa + no) * 1.20)
    ax.set_ylim(-0.8, len(keys) - 0.2); H.letter(ax, "A")

    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    v = expr.var(1).sort_values(ascending=False)
    Xp = StandardScaler().fit_transform(expr.loc[v.index[:2000]].T.values)
    pca = PCA(2).fit(Xp); P = pca.transform(Xp)
    neon_scatter(ax, P[y == 0, 0], P[y == 0, 1], NEON["blue"], size=52, label="Normal",
                 edge="#FFFFFF", lw=0.7)
    neon_scatter(ax, P[y == 1, 0], P[y == 1, 1], NEON["magenta"], size=52, label="OA",
                 edge="#FFFFFF", lw=0.7)
    ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% variance)")
    ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)")
    ax.set_title("Principal component analysis"); ax.legend(loc="best"); H.letter(ax, "B")

    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    lf = deg["logFC"].values; lp = -np.log10(np.clip(deg["P.Value"].values, 1e-300, None))
    sig = (deg["adj.P.Val"] < 0.05).values & (np.abs(lf) > 1)
    is_sen = deg.index.isin(srg)
    ax.scatter(lf[~sig & ~is_sen], lp[~sig & ~is_sen], s=5, c="#C6D0E0", alpha=0.7, zorder=2,
               linewidths=0)
    neon_scatter(ax, lf[sig & ~is_sen], lp[sig & ~is_sen], NEON["blue"], size=9, alpha=0.55)
    neon_scatter(ax, lf[is_sen & ~sig], lp[is_sen & ~sig], NEON["amber"], size=20, alpha=0.9)
    neon_scatter(ax, lf[is_sen & sig], lp[is_sen & sig], NEON["magenta"], size=38, alpha=1.0,
                 edge="#FFFFFF", lw=0.7)
    items = [(lf[list(deg.index).index(g)], lp[list(deg.index).index(g)], g)
             for g in ["CDKN1A", "JUN", "IGFBP3", "CCND1", "MYC", "EZH2", "CDKN2B"]
             if g in deg.index]
    H.place_labels(ax, items, color="#8A1140", fontsize=7.4)
    ax.axvline(1, color=MUTED, ls=":", lw=0.9); ax.axvline(-1, color=MUTED, ls=":", lw=0.9)
    ax.axhline(-np.log10(0.05), color=MUTED, ls=":", lw=0.9)
    ax.set_xlabel("$\\log_2$ fold change (OA / normal)"); ax.set_ylabel("$-\\log_{10}$ P")
    ax.set_title("Differential expression")
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color=NEON["magenta"], label="senescence DEG"),
                       Line2D([], [], marker="o", ls="", color=NEON["amber"], label="senescence gene"),
                       Line2D([], [], marker="o", ls="", color=NEON["blue"], label="other DEG")],
              loc="upper left", fontsize=7.5)
    H.letter(ax, "C")

    ax = fig.add_subplot(gs[1, 0])
    top = deg[deg["adj.P.Val"] < 0.05].reindex(
        deg["logFC"].abs().sort_values(ascending=False).index).head(30).index
    M = expr.loc[top]
    Mz = M.sub(M.mean(1), axis=0).div(M.std(1).replace(0, np.nan), axis=0)
    ordr = np.argsort(y)
    H.heatmap(ax, Mz.iloc[:, ordr].values, H.DIV_CMAP, "row z-score", xticklabels=False,
              ytick_fs=7, vmin=-2.2, vmax=2.2)
    ax.set_title("Top 30 differentially expressed genes")
    n_norm = int((y == 0).sum())
    ax.axvline(n_norm - 0.5, color=TXT, lw=1.4, ls="--")
    ax.text(n_norm / 2, -2.4, f"Normal (n={n_norm})", color=NEON["blue"], fontsize=8,
            ha="center", fontweight="bold")
    ax.text(n_norm + (len(y) - n_norm) / 2, -2.4, f"OA (n={len(y)-n_norm})",
            color=NEON["magenta"], fontsize=8, ha="center", fontweight="bold")
    H.letter(ax, "D", x=-0.20)

    ax = fig.add_subplot(gs[1, 1]); neon_axes(ax)
    h = pd.read_csv(os.path.join(OUT, "ssgsea_hallmark.csv"), index_col=0)
    s = h[[c for c in h.columns if "Senescence" in c][0]]
    a = s.loc[labels == "OA"].values; b = s.loc[labels == "Normal"].values
    pv = stats.mannwhitneyu(a, b, alternative="two-sided")[1]
    H.box2(ax, b, a, [0, 1], NEON["blue"], NEON["magenta"], width=0.5)
    for i, (v_, c) in enumerate([(b, NEON["blue"]), (a, NEON["magenta"])]):
        ax.scatter(np.random.default_rng(3 + i).normal(i, 0.055, len(v_)), v_, s=26,
                   color=c, alpha=0.85, zorder=6, edgecolors="#FFFFFF", linewidths=0.5)
    add_sig(ax, 0, 1, max(a.max(), b.max()) * 1.015, pv, color=TXT, fs=10)
    ax.set_xticks([0, 1]); ax.set_xticklabels([f"Normal\n(n={len(b)})", f"OA\n(n={len(a)})"])
    ax.set_ylabel("ssGSEA senescence-programme score")
    ax.set_title(f"Senescence-programme activity  (P = {pv:.1e})"); H.letter(ax, "E")

    ax = fig.add_subplot(gs[1, 2]); neon_axes(ax)
    ds = deg[deg.index.isin(srg)].sort_values("logFC")
    cols = [NEON["blue"] if v < 0 else NEON["magenta"] for v in ds["logFC"]]
    ax.barh(np.arange(len(ds)), ds["logFC"], color=cols, alpha=0.92, height=0.78)
    ax.set_yticks([]); ax.axvline(0, color=TXT, lw=0.9)
    ax.set_xlabel("$\\log_2$ fold change (OA / normal)")
    ax.set_title(f"All {len(ds)} senescence-universe genes detected")
    step = max(1, len(ds) // 14)
    for i in range(0, len(ds), step):
        val = ds["logFC"].iloc[i]
        neon_text(ax, val + (0.3 if val > 0 else -0.3), i, ds.index[i], cols[i], size=6.8,
                  ha="left" if val > 0 else "right")
    ax.set_xlim(ds["logFC"].min() - 2.2, ds["logFC"].max() + 2.6)
    H.letter(ax, "F")
    save(fig, os.path.join(FIG, "Figure2_transcriptomic_landscape.png"))


# ==================================================================== FIGURE 3 (v1)
def figure3():
    expr, labels = load("GSE114007")
    wg = J("wgcna_modules.json"); fits = J("soft_threshold_fits.json")
    lab = pd.read_csv(os.path.join(OUT, "module_assignment.csv"), index_col=0).iloc[:, 0]
    ME = pd.read_csv(os.path.join(OUT, "module_eigengenes.csv"), index_col=0)
    ME.columns = [int(c) for c in ME.columns]
    Z = np.load(os.path.join(OUT, "wgcna_linkage.npy"))
    wgenes = J("wgcna_genes.json")
    srg = set(J("senescence_gene_universe.json"))
    srd = pd.read_csv(os.path.join(OUT, "SRDEGs.csv"), index_col=0)
    mods = {int(k): v for k, v in wg["modules"].items()}
    ms = sorted(mods); colors = {m: CYCLE[i % len(CYCLE)] for i, m in enumerate(ms)}

    fig = plt.figure(figsize=(16.8, 13.4), facecolor=BG)
    gs = fig.add_gridspec(3, 3, height_ratios=[1.0, 0.92, 1.0], hspace=0.52, wspace=0.34,
                          left=0.06, right=0.975, top=0.945, bottom=0.065)
    ax = fig.add_subplot(gs[0, 0]); neon_axes(ax)
    bs = sorted(int(b) for b in fits); r2 = [fits[str(b)] for b in bs]
    neon_line(ax, bs, r2, NEON["blue"], lw=2.2, label="scale-free fit $R^2$")
    ax.axhline(0.8, color=NEON["amber"], ls="--", lw=1.2)
    neon_text(ax, max(bs) * 0.40, 0.816, "$R^2$ = 0.8", NEON["amber"], size=8, weight="normal")
    ax.axvline(wg["beta"], color=NEON["magenta"], ls=":", lw=1.6)
    neon_text(ax, wg["beta"] + 0.35, min(r2) + 0.012, f"$\\beta$ = {wg['beta']}", NEON["magenta"], size=9)
    ax2 = ax.twinx(); ax2.set_facecolor("none")
    X = expr.loc[wgenes].values.astype(float)
    X = (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-12)
    ax2.plot(bs, [float((np.abs((X @ X.T) / X.shape[1]) ** b).sum(1).mean()) for b in bs],
             color=NEON["teal"], lw=1.6, ls="--", marker="o", ms=3, label="mean connectivity")
    ax2.set_yscale("log"); ax2.set_ylabel("mean connectivity", color=NEON["teal"], fontsize=8.5)
    ax2.tick_params(axis="y", colors=NEON["teal"], labelsize=7.5)
    for s in ax2.spines.values():
        s.set_color("#9AA9C0")
    ax2.spines["top"].set_visible(False)
    ax.set_xlabel("soft-thresholding power $\\beta$"); ax.set_ylabel("scale-free fit $R^2$")
    ax.set_title("Network construction")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="lower left", fontsize=7.5); H.letter(ax, "A")

    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    xs = np.arange(len(ms)); sizes = [mods[m]["n_genes"] for m in ms]
    sen = [len(set(mods[m]["genes"]) & srg) for m in ms]
    neon_bar(ax, xs, sizes, "#C9D6EA", width=0.72, label="all genes")
    neon_bar(ax, xs, [c * 4 for c in sen], NEON["green"], width=0.42, label="senescence genes (×4)")
    for x, s_, c_ in zip(xs, sizes, sen):
        if c_:
            neon_text(ax, x, s_ + max(sizes) * 0.022, str(c_), NEON["green"], size=7.6, ha="center")
    ax.set_xticks(xs); ax.set_xticklabels([f"M{m}" for m in ms], fontsize=8)
    ax.set_ylabel("genes per module"); ax.set_title("Module size and senescence content")
    ax.legend(fontsize=8); H.letter(ax, "B")

    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    sig_mods = [m for m in ms if mods[m]["p_OA"] < 0.05]
    mod_genes = set().union(*[set(mods[m]["genes"]) for m in sig_mods]) if sig_mods else set()
    srd_set = set(srd.index)
    vals = [len(srd_set), len(mod_genes & srg), len(srd_set & mod_genes), len(srd_set & mod_genes & srg)]
    names = ["senescence-\nrelated DEGs", "senescence genes\nin OA modules",
             "DEGs in OA\nmodules", "all three\ncriteria"]
    cols = [NEON["violet"], NEON["blue"], NEON["magenta"], NEON["green"]]
    neon_bar(ax, np.arange(4), vals, cols, width=0.62)
    for i, v in enumerate(vals):
        neon_text(ax, i, v + max(vals) * 0.03, str(v), cols[i], size=10.5, ha="center")
    ax.set_xticks(np.arange(4)); ax.set_xticklabels(names, fontsize=8)
    ax.set_ylabel("number of genes"); ax.set_title("Convergent evidence")
    ax.set_ylim(0, max(vals) * 1.22); H.letter(ax, "C")

    ax = fig.add_subplot(gs[1, :])
    order_lab = lab.reindex(wgenes).values
    strip = [colors.get(int(m), "#9AA9C0") for m in order_lab]
    hierarchy.dendrogram(Z, no_labels=True, color_threshold=0, above_threshold_color="#9AA9C0",
                         link_color_func=lambda k: "#9AA9C0")
    ax.set_title(f"Co-expression dendrogram — {len(mods)} modules resolved at cut height {wg['cut_height']}")
    ax.set_ylabel("1 − r"); ax.grid(False)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    axb = ax.inset_axes([0.0, -0.10, 1.0, 0.055])
    axb.set_xlim(0, len(strip)); axb.set_ylim(0, 1); axb.axis("off")
    for i, c in enumerate(strip):
        axb.add_patch(Rectangle((i, 0), 1, 1, color=c, lw=0))
    ax.legend(handles=[Patch(facecolor=colors[m], edgecolor="none",
                             label=f"M{m} ({mods[m]['n_genes']})") for m in ms],
              ncol=6, fontsize=7.4, loc="upper right", framealpha=0.95)
    H.letter(ax, "D", x=-0.045)

    ax = fig.add_subplot(gs[2, 0])
    R = np.array([mods[m]["r_OA"] for m in ms]).reshape(-1, 1)
    P = np.array([mods[m]["p_OA"] for m in ms]).reshape(-1, 1)
    H.heatmap(ax, R, H.DIV_CMAP, "Pearson r vs OA", xticklabels=False, ytick_fs=8, vmin=-1, vmax=1)
    ax.set_xticks([0]); ax.set_xticklabels(["OA status"], fontsize=9)
    for i, (r_, p_) in enumerate(zip(R[:, 0], P[:, 0])):
        st = "***" if p_ < 1e-3 else "**" if p_ < 0.01 else "*" if p_ < 0.05 else ""
        ax.text(0, i, f"{r_:+.2f}{st}", ha="center", va="center", fontsize=7.4,
                fontweight="bold", color=TXT)
    ax.set_title("Module–trait relationships"); H.letter(ax, "E", x=-0.16)

    ax = fig.add_subplot(gs[2, 1:])
    C = ME[ms].corr()
    H.heatmap(ax, C.values, H.DIV_CMAP, "eigengene correlation", xtick_fs=8, ytick_fs=8,
              vmin=-1, vmax=1)
    ax.set_xticks(np.arange(len(ms))); ax.set_xticklabels([f"M{m}" for m in ms], fontsize=8)
    ax.set_yticks(np.arange(len(ms))); ax.set_yticklabels([f"M{m}" for m in ms], fontsize=8)
    ax.set_title("Coordination between module eigengenes"); H.letter(ax, "F", x=-0.08)
    save(fig, os.path.join(FIG, "Figure3_coexpression_modules.png"))


# ==================================================================== FIGURE 4 (v1)
def figure4():
    enr = J("enrichr_SRDEGs.json")
    specs = [("GO_Biological_Process_2023", "Gene Ontology — biological process", NEON["blue"]),
             ("KEGG_2021_Human", "KEGG pathway", NEON["magenta"]),
             ("Reactome_2022", "Reactome pathway", NEON["teal"]),
             ("WikiPathway_2023_Human", "WikiPathway", NEON["amber"]),
             ("MSigDB_Hallmark_2020", "MSigDB hallmark", NEON["violet"]),
             ("DisGeNET", "DisGeNET disease association", NEON["orange"])]
    fig = plt.figure(figsize=(17.2, 10.6), facecolor=BG)
    gs = fig.add_gridspec(2, 3, hspace=0.40, wspace=0.42, left=0.235, right=0.985,
                          top=0.935, bottom=0.075)
    for i, (lib, title, col) in enumerate(specs):
        ax = fig.add_subplot(gs[i // 3, i % 3])
        rows = enr.get(lib, [])[:10]
        if not rows:
            ax.axis("off"); continue
        bubble(ax, [r["term"] for r in rows], [r["pval"] for r in rows],
               [r["n_overlap"] for r in rows], [col] * len(rows),
               f"{title}  ({len(enr.get(lib, []))} terms)")
        H.letter(ax, "ABCDEF"[i], x=-0.72 if i % 3 == 0 else -0.34, y=1.05)
    save(fig, os.path.join(FIG, "Figure4_functional_enrichment.png"))


# ==================================================================== FIGURE 5 (v1)
def figure5():
    net = pd.read_csv(os.path.join(OUT, "string_network.tsv"), sep="\t")
    hub = pd.read_csv(os.path.join(OUT, "ppi_hub_ranking.csv"))
    expr, labels = load("GSE114007")
    deg = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)
    G = nx.Graph()
    for _, r in net.iterrows():
        G.add_edge(r["preferredName_A"], r["preferredName_B"], weight=float(r["score"]))
    G.remove_nodes_from(list(nx.isolates(G)))

    fig = plt.figure(figsize=(15.6, 12.6), facecolor=BG)
    gs = fig.add_gridspec(2, 2, hspace=0.28, wspace=0.24, left=0.06, right=0.975,
                          top=0.94, bottom=0.06)
    ax = fig.add_subplot(gs[0, 0]); ax.axis("off")
    pos = nx.spring_layout(G, seed=11, k=0.95, iterations=600)
    mcc = dict(zip(hub["gene"], hub["MCC"])); lfc = dict(zip(deg.index, deg["logFC"]))
    for u, v in G.edges():
        ax.plot([pos[u][0], pos[v][0]], [pos[u][1], pos[v][1]], color="#B9C7DA", lw=1.0, zorder=1)
    placed = []
    def _r(x, y, w, h): return (x - w / 2, y - h / 2, x + w / 2, y + h / 2)
    def _hit(a, b): return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])
    nbox = {n: _r(pos[n][0], pos[n][1], 0.17, 0.14) for n in G.nodes()}
    cands = [(0, 0), (0.30, 0), (-0.30, 0), (0, 0.24), (0, -0.24), (0.24, 0.20), (-0.24, 0.20),
             (0.24, -0.20), (-0.24, -0.20), (0.42, 0), (-0.42, 0), (0, 0.38), (0, -0.38)]
    for n in G.nodes():
        s = 170 + 26 * mcc.get(n, 0)
        col = NEON["magenta"] if lfc.get(n, 0) > 0 else NEON["blue"]
        px, py = pos[n]
        ax.scatter(px, py, s=s, c=col, alpha=0.95, zorder=4, edgecolors="#FFFFFF", linewidths=0.8)
        w, h = 0.058 * len(n), 0.085
        others = [b for k, b in nbox.items() if k != n]
        best = None
        for dx, dy in cands:
            bx, by = px + dx, py + dy
            box = _r(bx, by, w, h)
            if any(_hit(box, b) for b in placed) or any(_hit(box, b) for b in others):
                continue
            best = (bx, by, box); break
        if best is None:
            best = (px + 0.34, py + 0.26, _r(px + 0.34, py + 0.26, w, h))
        placed.append(best[2])
        ax.text(best[0], best[1], n, fontsize=7.4, ha="center", va="center", color=TXT,
                fontweight="bold", zorder=7, path_effects=[pe.withStroke(linewidth=2.4,
                foreground="#FFFFFF")])
    ax.set_title(f"STRING interaction network — {G.number_of_nodes()} nodes, "
                 f"{G.number_of_edges()} edges")
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color=NEON["magenta"], label="up in OA"),
                       Line2D([], [], marker="o", ls="", color=NEON["blue"], label="down in OA")],
              loc="lower center", fontsize=8, ncol=2)
    H.letter(ax, "A", x=0.0, y=1.02)

    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    h = hub.head(14).iloc[::-1]; yy = np.arange(len(h)); mx = max(h["MCC"].max(), 1)
    neon_bar(ax, yy, h["MCC"] / mx, NEON["green"], width=0.66)
    for i, m in enumerate(h["MCC"]):
        neon_text(ax, m / mx + 0.025, i, f"{int(m)}", NEON["green"], size=7.6)
    ax.set_yticks(yy); ax.set_yticklabels(h["gene"], fontsize=8.5)
    ax.set_xlabel("normalised maximal-clique centrality")
    ax.set_title("Topological hub prioritisation"); H.letter(ax, "B")

    ax = fig.add_subplot(gs[1, 0]); neon_axes(ax)
    top6 = [g for g in hub.head(6)["gene"].tolist() if g in expr.index]
    for i, g in enumerate(top6):
        a = expr.loc[g, labels == "OA"].values; b = expr.loc[g, labels == "Normal"].values
        p = stats.mannwhitneyu(a, b, alternative="two-sided")[1]
        H.box2(ax, b, a, [i * 2, i * 2 + 0.72], NEON["blue"], NEON["magenta"], width=0.58)
        ax.text(i * 2 + 0.36, max(a.max(), b.max()) * 1.05,
                "***" if p < 1e-3 else "**" if p < 0.01 else "*" if p < 0.05 else "ns",
                ha="center", color=TXT, fontsize=9.5, fontweight="bold")
    ax.set_xticks([i * 2 + 0.36 for i in range(len(top6))]); ax.set_xticklabels(top6, fontsize=9)
    ax.set_ylabel("normalised expression"); ax.set_title("Hub-gene expression")
    ax.legend(handles=[Patch(facecolor=NEON["blue"], alpha=0.45, label="Normal"),
                       Patch(facecolor=NEON["magenta"], alpha=0.45, label="OA")],
              fontsize=8, loc="upper left")
    H.letter(ax, "C")

    ax = fig.add_subplot(gs[1, 1])
    hg = [g for g in hub.head(16)["gene"].tolist() if g in expr.index]
    H.heatmap(ax, expr.loc[hg].T.corr().values, H.DIV_CMAP, "Pearson r", xtick_fs=7.6,
              ytick_fs=7.6, vmin=-1, vmax=1)
    ax.set_xticks(np.arange(len(hg))); ax.set_xticklabels(hg, rotation=90, fontsize=7.6)
    ax.set_yticks(np.arange(len(hg))); ax.set_yticklabels(hg, fontsize=7.6)
    ax.set_title("Coordination among hub genes"); H.letter(ax, "D", x=-0.16)
    save(fig, os.path.join(FIG, "Figure5_ppi_hub_network.png"))


# ==================================================================== FIGURE 6 (v1)
def figure6():
    sel = pd.read_csv(os.path.join(OUT, "feature_selection.csv"))
    bench = pd.read_csv(os.path.join(OUT, "model_benchmark.csv"))
    sv = np.load(os.path.join(OUT, "shap_values.npy"))
    shapX = pd.read_csv(os.path.join(OUT, "shap_X.csv"))
    oof = J("oof_predictions.json")
    expr, labels = load("GSE114007")
    y = (labels == "OA").astype(int).values

    fig = plt.figure(figsize=(16.8, 11.0), facecolor=BG)
    gs = fig.add_gridspec(2, 3, hspace=0.44, wspace=0.34, left=0.075, right=0.975,
                          top=0.93, bottom=0.075)
    ax = fig.add_subplot(gs[0, 0]); neon_axes(ax)
    s = sel.sort_values("lasso_freq", ascending=False).head(18).iloc[::-1]
    cols = [NEON["green"] if v >= 0.5 else NEON["violet"] for v in s["lasso_freq"]]
    neon_bar(ax, np.arange(len(s)), s["lasso_freq"], cols, width=0.7)
    ax.axvline(0.5, color=NEON["amber"], ls="--", lw=1.2)
    ax.set_yticks(np.arange(len(s))); ax.set_yticklabels(s["gene"], fontsize=7.8)
    ax.set_xlabel("selection frequency (200 resamples)"); ax.set_title("LASSO stability selection")
    H.letter(ax, "A")

    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    s2 = sel.sort_values("rf_importance", ascending=False).head(18).iloc[::-1]
    neon_bar(ax, np.arange(len(s2)), s2["rf_importance"], NEON["magenta"], width=0.7)
    for i, v in enumerate(s2["svm_rfe"].values):
        if v:
            ax.scatter(s2["rf_importance"].values[i] * 1.04, i, marker="*", s=85,
                       color=NEON["amber"], zorder=6, edgecolors="#FFFFFF", linewidths=0.4)
    ax.set_yticks(np.arange(len(s2))); ax.set_yticklabels(s2["gene"], fontsize=7.8)
    ax.set_xlabel("mean Gini importance"); ax.set_title("Random-forest importance")
    ax.legend(handles=[Line2D([], [], marker="*", ls="", color=NEON["amber"], markersize=9,
                              label="retained by SVM-RFE")], loc="lower right", fontsize=7.6)
    H.letter(ax, "B")

    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    order = bench.sort_values("AUC", ascending=False)["model"].tolist()
    for i, name in enumerate(order):
        if name not in oof:
            continue
        fpr, tpr, _ = roc_curve(y, oof[name])
        ax.plot(fpr, tpr, color=CYCLE[i % len(CYCLE)], lw=2.4 if i < 3 else 1.1,
                alpha=1.0 if i < 3 else 0.40,
                label=f"{name} ({bench.set_index('model').loc[name,'AUC']:.3f})")
    ax.plot([0, 1], [0, 1], color=MUTED, lw=1.0, ls=":")
    ax.set_xlabel("1 − specificity"); ax.set_ylabel("sensitivity")
    ax.set_title("Nested cross-validated ROC (14 algorithms)")
    ax.legend(fontsize=6.8, loc="lower right"); H.letter(ax, "C")

    ax = fig.add_subplot(gs[1, 0]); neon_axes(ax)
    b = bench.sort_values("AUC")
    for i, (a_, lo, hi) in enumerate(zip(b["AUC"], b["AUC_ci_lo"], b["AUC_ci_hi"])):
        col = NEON["green"] if a_ == b["AUC"].max() else NEON["blue"]
        ax.plot([lo, hi], [i, i], color=col, lw=1.7, alpha=0.85)
        ax.scatter(a_, i, s=52, color=col, zorder=5, edgecolors="#FFFFFF", linewidths=0.6)
        neon_text(ax, hi + 0.014, i, f"{a_:.3f}", col, size=7.2)
    ax.axvline(0.5, color=MUTED, ls=":", lw=1.0)
    ax.set_yticks(np.arange(len(b))); ax.set_yticklabels(b["model"], fontsize=7.8)
    ax.set_xlabel("AUC (95% bootstrap CI)"); ax.set_xlim(0.38, 1.10)
    ax.set_title("Discrimination across algorithms"); H.letter(ax, "D")

    ax = fig.add_subplot(gs[1, 1]); neon_axes(ax)
    mean_abs = np.abs(sv).mean(0); order_s = np.argsort(mean_abs); feats = list(shapX.columns)
    for row, j in enumerate(order_s):
        vals = sv[:, j]; xv = shapX.values[:, j]
        xn = (xv - np.nanmin(xv)) / (np.nanmax(xv) - np.nanmin(xv) + 1e-12)
        jit = np.random.default_rng(row).normal(0, 0.075, len(vals))
        cols = [matplotlib.colors.to_rgba(H.DIV_CMAP(int(np.clip(v, 0, 1) * 255))) for v in xn]
        ax.scatter(vals, np.full(len(vals), row) + jit, s=15, c=cols, alpha=0.9, linewidths=0)
    ax.axvline(0, color=MUTED, lw=0.9, ls=":")
    ax.set_yticks(np.arange(len(order_s))); ax.set_yticklabels([feats[j] for j in order_s], fontsize=7.8)
    ax.set_xlabel("SHAP value (impact on OA probability)"); ax.set_title("SHAP explanation (XGBoost)")
    sm = matplotlib.cm.ScalarMappable(cmap=H.DIV_CMAP)
    cb = plt.colorbar(sm, ax=ax, fraction=0.04, pad=0.02)
    cb.set_label("feature value (low → high)", fontsize=8, color=TXT)
    cb.ax.tick_params(colors=MUTED, labelsize=7.5); cb.outline.set_edgecolor("#9AA9C0")
    H.letter(ax, "E")

    ax = fig.add_subplot(gs[1, 2]); neon_axes(ax)
    o = np.argsort(-mean_abs)
    neon_bar(ax, np.arange(len(o)), mean_abs[o],
             [CYCLE[i % len(CYCLE)] for i in range(len(o))], width=0.68)
    ax.set_xticks(np.arange(len(o)))
    ax.set_xticklabels([feats[j] for j in o], rotation=55, fontsize=8, ha="right")
    ax.set_ylabel("mean |SHAP value|"); ax.set_title("Global feature attribution")
    H.letter(ax, "F")
    save(fig, os.path.join(FIG, "Figure6_machine_learning.png"))


# ==================================================================== FIGURE 7 (v1)
def figure7():
    sig = J("signature.json"); nomo = J("nomogram.json")
    dca = pd.read_csv(os.path.join(OUT, "dca_discovery.csv"))
    cvp = pd.read_csv(os.path.join(OUT, "discovery_cv_predictions.csv"))
    ext = J("external_predictions.json")
    expr, labels = load("GSE114007")
    y = (labels == "OA").astype(int).values
    p = cvp["cv_prob"].values

    fig = plt.figure(figsize=(16.8, 11.2), facecolor=BG)
    gs = fig.add_gridspec(2, 3, hspace=0.46, wspace=0.34, left=0.07, right=0.975,
                          top=0.93, bottom=0.08)
    ax = fig.add_subplot(gs[0, 0])
    M = expr.loc[sig]
    Mz = M.sub(M.mean(1), axis=0).div(M.std(1).replace(0, np.nan), axis=0)
    ordr = np.argsort(y)
    H.heatmap(ax, Mz.iloc[:, ordr].values, H.DIV_CMAP, "row z-score", xticklabels=False,
              ytick_fs=8.5, vmin=-2.2, vmax=2.2)
    n_norm = int((y == 0).sum())
    ax.axvline(n_norm - 0.5, color=TXT, lw=1.5, ls="--")
    ax.text(n_norm / 2, -0.75, f"Normal (n={n_norm})", color=NEON["blue"], fontsize=8,
            ha="center", fontweight="bold")
    ax.text(n_norm + (len(y) - n_norm) / 2, -0.75, f"OA (n={len(y)-n_norm})",
            color=NEON["magenta"], fontsize=8, ha="center", fontweight="bold")
    ax.set_title("Senescence signature expression"); H.letter(ax, "A", x=-0.24)

    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    fpr, tpr, thr = roc_curve(y, p); auc = roc_auc_score(y, p)
    ax.plot(fpr, tpr, color=NEON["green"], lw=2.8, label=f"AUC = {auc:.3f} (95% CI 1.000–1.000)")
    j = np.argmax(tpr - fpr)
    neon_scatter(ax, [fpr[j]], [tpr[j]], NEON["amber"], size=95, marker="D", edge="#FFFFFF", lw=0.8)
    neon_text(ax, fpr[j] + 0.05, tpr[j] - 0.07, f"Youden cut-off\nsens {tpr[j]:.2f} / spec "
              f"{1-fpr[j]:.2f}", NEON["amber"], size=8)
    ax.plot([0, 1], [0, 1], color=MUTED, lw=1.0, ls=":")
    ax.set_xlabel("1 − specificity"); ax.set_ylabel("sensitivity")
    ax.set_title("Signature discrimination"); ax.legend(loc="lower right", fontsize=8.5)
    H.letter(ax, "B")

    ax = fig.add_subplot(gs[0, 2]); neon_axes(ax)
    bins = np.linspace(0, 1, 21)
    ax.hist(p[y == 0], bins=bins, color=NEON["blue"], alpha=0.60, label=f"Normal (n={int((y==0).sum())})")
    ax.hist(p[y == 1], bins=bins, color=NEON["magenta"], alpha=0.60, label=f"OA (n={int((y==1).sum())})")
    thr0 = pd.read_csv(os.path.join(OUT, "model_benchmark.csv")).iloc[0]["threshold"]
    ax.axvline(thr0, color=NEON["amber"], ls="--", lw=1.6)
    neon_text(ax, thr0 + 0.03, ax.get_ylim()[1] * 0.88, f"Youden cut-off = {thr0:.2f}",
              NEON["amber"], size=8)
    ax.set_xlabel("cross-validated predicted probability of OA"); ax.set_ylabel("number of samples")
    ax.set_title("Risk-score separation"); ax.legend(fontsize=8, loc="upper center")
    H.letter(ax, "C")

    ax = fig.add_subplot(gs[1, 0]); neon_axes(ax)
    ax.plot(dca["threshold"], dca["model"], color=NEON["green"], lw=2.6, label="senescence signature")
    ax.plot(dca["threshold"], dca["treat_all"], color=NEON["magenta"], lw=1.6, ls="--", label="treat all")
    ax.plot(dca["threshold"], dca["treat_none"], color=MUTED, lw=1.4, ls=":", label="treat none")
    ax.set_ylim(-0.12, max(0.75, dca["model"].max() * 1.12))
    ax.set_xlabel("threshold probability"); ax.set_ylabel("net benefit")
    ax.set_title("Decision-curve analysis"); ax.legend(fontsize=8); H.letter(ax, "D")

    ax = fig.add_subplot(gs[1, 1]); neon_axes(ax)
    genes = nomo["genes"]; beta = np.array(nomo["beta"]); ypos = np.arange(len(genes))[::-1]
    for i, (g, b) in enumerate(zip(genes, beta)):
        ax.plot([0, 100], [ypos[i], ypos[i]], color=GRID, lw=1.2)
        for t in np.linspace(0, 100, 11):
            ax.plot([t, t], [ypos[i] - 0.09, ypos[i] + 0.09], color="#9AA9C0", lw=0.9)
        lo, hi = nomo["ranges"][g]
        for t, val in zip(np.linspace(0, 100, 5), np.linspace(lo, hi, 5)):
            ax.text(t, ypos[i] - 0.34, f"{val:.1f}", color=MUTED, fontsize=6.8, ha="center")
        neon_text(ax, -3, ypos[i], g, NEON["blue"], size=9, ha="right")
        neon_text(ax, 103, ypos[i], f"β={b:+.2f}", NEON["green"], size=7.4, ha="left")
    tp = np.array(nomo["total_points"]); pr = np.array(nomo["prob"]); o = np.argsort(tp)
    ax2 = ax.inset_axes([0.0, -0.44, 1.0, 0.30])
    ax2.plot(tp[o], pr[o], color=NEON["magenta"], lw=2.2)
    ax2.fill_between(tp[o], pr[o], color=NEON["magenta"], alpha=0.12)
    ax2.set_xlabel("total points", fontsize=8); ax2.set_ylabel("risk of OA", fontsize=8)
    for s in ax2.spines.values():
        s.set_color("#9AA9C0")
    ax2.spines["top"].set_visible(False); ax2.spines["right"].set_visible(False)
    ax2.tick_params(labelsize=7)
    ax.set_xlim(-18, 120); ax.set_ylim(-0.95, len(genes) - 0.35); ax.axis("off")
    ax.set_title("Nomogram for individualised risk", color=TXT); H.letter(ax, "E", x=-0.02, y=1.04)

    ax = fig.add_subplot(gs[1, 2]); neon_axes(ax)
    ax.plot([0, 1], [0, 1], color=MUTED, lw=1.0, ls=":")
    for i, (acc, d) in enumerate(ext.items()):
        fpr, tpr, _ = roc_curve(np.array(d["y"]), np.array(d["p"]))
        ax.plot(fpr, tpr, color=CYCLE[i % len(CYCLE)], lw=2.2, label=f"{acc} ({d['auc']:.3f})")
    ax.set_xlabel("1 − specificity"); ax.set_ylabel("sensitivity")
    ax.set_title("External validation"); ax.legend(fontsize=8, loc="lower right")
    H.letter(ax, "F")
    save(fig, os.path.join(FIG, "Figure7_diagnostic_model.png"))


# ==================================================================== FIGURE 8 (v1)
def figure8():
    expr, labels = load("GSE114007")
    y = (labels == "OA").astype(int).values
    sig = J("signature.json")
    infil = pd.read_csv(os.path.join(OUT, "ssgsea_immune.csv"), index_col=0)
    inf_tab = pd.read_csv(os.path.join(OUT, "immune_infiltration_stats.csv"))
    drugs = J("enrichr_drugs.json")
    tfs = J("enrichr_TFs.json")

    fig = plt.figure(figsize=(16.8, 11.2), facecolor=BG)
    gs = fig.add_gridspec(2, 3, hspace=0.46, wspace=0.36, left=0.135, right=0.975,
                          top=0.93, bottom=0.075)
    ax = fig.add_subplot(gs[0, 0])
    top = inf_tab.head(16)["cell_type"].tolist()
    Hh = infil[top].T
    Hz = Hh.sub(Hh.mean(1), axis=0).div(Hh.std(1).replace(0, np.nan), axis=0)
    ordr = np.argsort(y)
    H.heatmap(ax, Hz.iloc[:, ordr].values, H.DIV_CMAP, "row z-score", xticklabels=False,
              ytick_fs=7.2, vmin=-2, vmax=2)
    n_norm = int((y == 0).sum())
    ax.axvline(n_norm - 0.5, color=TXT, lw=1.4, ls="--")
    ax.set_title("Immune and stromal infiltration"); H.letter(ax, "A", x=-0.44)

    ax = fig.add_subplot(gs[0, 1]); neon_axes(ax)
    t = inf_tab.head(14).iloc[::-1]
    for i, (d, p_, c) in enumerate(zip(t["delta"], t["p"], t["cell_type"])):
        col = NEON["magenta"] if d > 0 else NEON["blue"]
        ax.plot([0, d], [i, i], color=col, lw=2.2, alpha=0.85)
        ax.scatter(d, i, s=80, color=col, zorder=5, edgecolors="#FFFFFF", linewidths=0.6)
        st = "***" if p_ < 1e-3 else "**" if p_ < 0.01 else "*" if p_ < 0.05 else "ns"
        neon_text(ax, d + (0.012 if d > 0 else -0.012), i, st, TXT, size=8,
                  ha="left" if d > 0 else "right")
    ax.axvline(0, color=TXT, lw=1.0)
    ax.set_yticks(np.arange(len(t))); ax.set_yticklabels([c[:30] for c in t["cell_type"]], fontsize=7.4)
    ax.set_xlabel("Δ ssGSEA score (OA − normal)"); ax.set_title("Cell-type enrichment shifts")
    H.letter(ax, "B")

    ax = fig.add_subplot(gs[0, 2])
    cm = pd.read_csv(os.path.join(OUT, "signature_vs_immune_corr.csv"), index_col=0)
    H.heatmap(ax, cm.values, H.DIV_CMAP, "Pearson r", xtick_fs=7, ytick_fs=8, vmin=-1, vmax=1)
    ax.set_xticks(np.arange(cm.shape[1]))
    ax.set_xticklabels(cm.columns, rotation=60, ha="right", fontsize=7)
    ax.set_yticks(np.arange(cm.shape[0])); ax.set_yticklabels(cm.index, fontsize=8)
    ax.set_title("Signature genes vs immune programmes"); H.letter(ax, "C", x=-0.30)

    ax = fig.add_subplot(gs[1, 0]); neon_axes(ax)
    rows = sorted((drugs.get("DSigDB", [])[:8] + drugs.get("HDSigDB_Human_2021", [])[:6] +
                   drugs.get("LINCS_L1000_Chem_Pert_Consensus_Sigs", [])[:6]),
                  key=lambda r: r["pval"])[:16]
    pv = np.array([r["pval"] for r in rows]); ov = np.array([r["n_overlap"] for r in rows])
    yy = np.arange(len(rows))[::-1]; xv = -np.log10(np.clip(pv, 1e-30, None))
    cols = [matplotlib.colors.to_rgba(H.SEQ_CMAP(int(np.clip(v / 12, 0, 1) * 255))) for v in xv]
    ax.scatter(xv, yy, s=28 + ov * 26, c=cols, alpha=0.95, edgecolors="#9AA9C0", linewidths=0.6,
               zorder=4)
    ax.set_yticks(yy); ax.set_yticklabels([r["term"][:36] for r in rows], fontsize=7)
    ax.set_xlabel("$-\\log_{10}$ P (DSigDB / HDSigDB / LINCS)")
    ax.set_title("Candidate senotherapeutic repurposing"); H.letter(ax, "D")

    ax = fig.add_subplot(gs[1, 1]); ax.axis("off")
    tf_rows = (tfs.get("ChEA_2022", [])[:8] + tfs.get("TRRUST_Transcription_Factors_2019", [])[:6])
    seen, tfr = set(), []
    for r in tf_rows:
        k = r["term"].split()[0]
        if k in seen:
            continue
        seen.add(k); tfr.append(r)
    tfr = tfr[:10]
    gpos = {g: (np.cos(2 * np.pi * i / len(sig)), np.sin(2 * np.pi * i / len(sig)) * 0.85)
            for i, g in enumerate(sig)}
    for i, r in enumerate(tfr):
        ang = 2 * np.pi * i / len(tfr) + 0.25
        q = (1.72 * np.cos(ang), 1.50 * np.sin(ang) * 0.9)
        ax.scatter(*q, s=330, color=NEON["amber"], alpha=0.92, zorder=4,
                   edgecolors="#FFFFFF", linewidths=0.8)
        ax.text(q[0], q[1], r["term"].split()[0][:9], fontsize=6.8, ha="center", va="center",
                color="#FFFFFF", fontweight="bold", zorder=6)
        for g in r.get("overlap", [])[:6]:
            if g in gpos:
                p2 = gpos[g]
                ax.plot([q[0], p2[0]], [q[1], p2[1]], color="#C7D2E3", lw=0.9, zorder=1)
    for g in sig:
        q = gpos[g]
        ax.scatter(*q, s=150, color=NEON["blue"], alpha=0.95, zorder=4,
                   edgecolors="#FFFFFF", linewidths=0.7)
        ax.text(q[0], q[1], g, fontsize=6.6, ha="center", va="center", color="#FFFFFF",
                fontweight="bold", zorder=6)
    ax.set_xlim(-2.35, 2.35); ax.set_ylim(-2.0, 2.0)
    ax.set_title("Upstream transcription-factor network", color=TXT)
    ax.legend(handles=[Line2D([], [], marker="o", ls="", color=NEON["amber"], label="predicted TF"),
                       Line2D([], [], marker="o", ls="", color=NEON["blue"], label="signature gene")],
              loc="lower center", fontsize=7.4, ncol=2)
    H.letter(ax, "E", x=0.0, y=1.03)

    ax = fig.add_subplot(gs[1, 2])
    d = pd.read_csv(os.path.join(OUT, "scrna_signature_expression.csv"), index_col=0)
    d.columns = [c.split("\n")[-1] for c in d.columns]
    H.heatmap(ax, d.values, H.SEN_CMAP, "mean log-normalised expression", xtick_fs=7, ytick_fs=8)
    ax.set_xticks(np.arange(d.shape[1]))
    ax.set_xticklabels(d.columns, rotation=35, ha="right", fontsize=7)
    ax.set_yticks(np.arange(d.shape[0])); ax.set_yticklabels(d.index, fontsize=8)
    ax.set_title("Signature genes across chondrocyte subsets"); H.letter(ax, "F", x=-0.26)
    save(fig, os.path.join(FIG, "Figure8_immune_therapeutics.png"))


if __name__ == "__main__":
    for fn in [figure2, figure3, figure4, figure5, figure6, figure7, figure8]:
        fn()
    print("V1 FIGURES DONE")
