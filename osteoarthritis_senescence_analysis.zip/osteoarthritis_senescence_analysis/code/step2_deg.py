"""
step2_deg.py — differential expression (empirical-Bayes moderated t), senescence gene-set
intersection, co-expression module analysis (WGCNA-style), Enrichr over-representation
enrichment, and STRING PPI hub detection.  All inputs are real public data.
"""
import os, json, re, time, itertools
import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import digamma, polygamma
from scipy.cluster import hierarchy
from scipy.spatial.distance import squareform
import urllib.request, urllib.parse, ssl

BASE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(BASE, "work"); GS = os.path.join(BASE, "genesets")
OUT = os.path.join(BASE, "results"); os.makedirs(OUT, exist_ok=True)
CTX = ssl.create_default_context()
UA = {"User-Agent": "Mozilla/5.0"}
RNG = np.random.default_rng(20240517)


# ============================================================ empirical Bayes moderated t
def _solve_d0(sample_var_w, mean_trigamma_dg):
    """Solve trigamma(d0/2) = sample_var_w - mean(trigamma(dg/2)) for d0 (limma fitFDist)."""
    target = sample_var_w - mean_trigamma_dg
    if target <= 1e-8:
        return np.inf
    lo, hi = 1e-3, 1e6
    for _ in range(200):
        mid = np.sqrt(lo * hi)
        if polygamma(1, mid / 2) > target:
            lo = mid
        else:
            hi = mid
    return np.sqrt(lo * hi)


def ebayes_moderated_t(expr, groups, covars=None):
    """
    limma-equivalent empirical Bayes moderated t-statistics for a two-group comparison.
    expr: genes x samples DataFrame (log-scale). groups: Series of 'OA'/'Normal'.
    covars: optional DataFrame of covariates (samples x k) added to the design.
    Returns DataFrame: logFC, t, P.Value, adj.P.Val, B, s2.post, df.prior, AveExpr.
    """
    X = (groups == "OA").astype(float).values
    if X.std() == 0:
        raise ValueError("no group variation")
    design = X.reshape(-1, 1)
    if covars is not None and covars.shape[1] > 0:
        C = covars.values.astype(float)
        C = (C - C.mean(0)) / (C.std(0) + 1e-12)
        design = np.column_stack([design, C])
    design = np.column_stack([np.ones(len(X)), design])
    n, p = design.shape
    df_resid = n - p

    Y = expr.values.astype(float)          # genes x samples
    beta, *_ = np.linalg.lstsq(design, Y.T, rcond=None)   # p x genes
    resid = Y.T - design @ beta
    sigma2 = (resid ** 2).sum(0) / df_resid                # genes
    sigma2 = np.maximum(sigma2, 1e-12)

    XtXinv = np.linalg.pinv(design.T @ design)
    c_g = XtXinv[1, 1]                                     # coefficient of interest
    df_g = np.full(len(sigma2), float(df_resid))

    # ---- fit prior
    z = np.log(sigma2)
    w = z - digamma(df_g / 2) + np.log(df_g)
    c0 = w.mean()
    sample_var_w = ((w - c0) ** 2).mean()
    d0 = _solve_d0(sample_var_w, polygamma(1, df_g / 2).mean())
    if np.isinf(d0):
        s0sq = np.exp(c0)
        df_prior = np.full(len(sigma2), np.inf)
        s2_post = np.full(len(sigma2), s0sq)
    else:
        s0sq = float(np.exp(c0 + digamma(d0 / 2) - np.log(d0)))
        df_prior = np.full(len(sigma2), d0)
        s2_post = (d0 * s0sq + df_g * sigma2) / (d0 + df_g)

    logFC = beta[1]
    se_post = np.sqrt(s2_post * c_g)
    t_stat = logFC / se_post
    df_total = df_g + df_prior
    pval = 2 * stats.t.sf(np.abs(t_stat), df=df_total)
    adj = multipletests_bh(pval)

    # B statistic (log-odds of differential expression)
    with np.errstate(divide="ignore", invalid="ignore"):
        B = np.where(df_prior == np.inf, np.inf,
                     (np.log(s2_post) - np.log(sigma2)) * df_g / 2 - np.log(df_prior / df_g) * df_g / 2)
    res = pd.DataFrame({
        "logFC": logFC, "AveExpr": Y.mean(1), "t": t_stat, "P.Value": pval,
        "adj.P.Val": adj, "B": B, "s2.post": s2_post, "df.prior": df_prior,
        "df.total": df_total,
    }, index=expr.index)
    return res.sort_values("P.Value")


def multipletests_bh(p):
    p = np.asarray(p, float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order] * n / (np.arange(n) + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(ranked, 0, 1)
    return out


# ============================================================ senescence gene sets
SENESCENCE_TERMS = {
    "Reactome_2022": [
        "Cellular Senescence R-HSA-2559583",
        "Senescence-Associated Secretory Phenotype (SASP) R-HSA-2559582",
        "DNA Damage/Telomere Stress Induced Senescence R-HSA-2559586",
        "Oxidative Stress Induced Senescence R-HSA-2559580",
        "Oncogene Induced Senescence R-HSA-2559585",
        "Formation Of Senescence-Associated Heterochromatin Foci (SAHF) R-HSA-2559584",
    ],
    "KEGG_2021_Human": ["Cellular senescence"],
    "GO_Biological_Process_2023": [
        "Stress-Induced Premature Senescence (GO:0090400)",
        "Regulation Of Cellular Senescence (GO:2000772)",
        "Positive Regulation Of Cellular Senescence (GO:2000774)",
        "Negative Regulation Of Cellular Senescence (GO:2000773)",
    ],
    "MSigDB_Hallmark_2020": [],
}


def _find_term(lib_dict, wanted):
    if wanted in lib_dict:
        return wanted
    wl = wanted.lower()
    for k in lib_dict:
        if k.lower() == wl:
            return k
    for k in lib_dict:
        if wl in k.lower() or k.lower() in wl:
            return k
    return None


def build_senescence_set():
    libs, used = {}, {}
    for lib, terms in SENESCENCE_TERMS.items():
        p = os.path.join(GS, lib + ".json")
        if not os.path.exists(p):
            continue
        d = json.load(open(p, encoding="utf8"))
        for t in terms:
            k = _find_term(d, t)
            if k:
                libs.setdefault(lib, {})[k] = set(g.upper() for g in d[k])
                used.setdefault(lib, []).append((t, k, len(d[k])))
    genes = set()
    for lib, d in libs.items():
        for k, s in d.items():
            genes |= s
    return genes, used, libs


# ============================================================ Enrichr
def enrichr(genes, libraries, description="query", background=None):
    """Over-representation analysis through the Enrichr API (multipart POST)."""
    import requests
    r = requests.post("https://maayanlab.cloud/Enrichr/addList",
                      files={"list": (None, "\n".join(sorted(set(genes)))),
                             "description": (None, description)}, timeout=120)
    r.raise_for_status()
    uid = r.json()["userListId"]
    out = {}
    for lib in libraries:
        u = f"https://maayanlab.cloud/Enrichr/enrich?userListId={uid}&backgroundType={urllib.parse.quote(lib)}"
        try:
            j = requests.get(u, timeout=180).json()
        except Exception:
            out[lib] = []; continue
        rows = []
        # Enrichr returns {"LIBRARY": [[rank, term, pval, zscore, combined, genes, adjp, oldp, oldadjp], ...]}
        entries = j.get(lib)
        if entries is None and j:
            entries = next(iter(j.values()))
        for v in (entries or []):
            rows.append({"term": v[1], "pval": v[2], "zscore": v[3], "combined": v[4],
                         "overlap": v[5], "adjp": v[6], "n_overlap": len(v[5]),
                         "n_term": len(v[5]), "genes": v[5]})
        rows.sort(key=lambda r_: r_["pval"])
        out[lib] = rows
        time.sleep(0.3)
    return out


# ============================================================ WGCNA-style co-expression
def soft_threshold(expr_v, powers=range(1, 21), n_bins=10, min_bin=3):
    """Scale-free topology fit index (WGCNA pickSoftThreshold).

    For each candidate power the adjacency connectivity k is binned, the frequency
    p(k) computed, and log10(p(k)) regressed on log10(k).  The returned index is the
    signed R^2 (negative when the slope is positive, i.e. not scale-free).
    """
    X = expr_v.values.astype(float)
    X = (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-12)
    n = X.shape[1]
    res = {}
    for b in powers:
        A = np.abs((X @ X.T) / n) ** b
        np.fill_diagonal(A, 0)
        k = A.sum(1)
        k = k[k > 0]
        if len(k) < 50:
            res[b] = 0.0; continue
        lo, hi = np.log10(k.min() + 1e-6), np.log10(k.max())
        edges = np.linspace(lo, hi, n_bins + 1)
        idx = np.clip(np.digitize(np.log10(k), edges) - 1, 0, n_bins - 1)
        xs, ys = [], []
        for i in range(n_bins):
            sel = idx == i
            if sel.sum() < min_bin:
                continue
            xs.append(np.log10(k[sel]).mean())
            ys.append(np.log10(sel.mean()))
        if len(xs) < 4:
            res[b] = 0.0; continue
        xs, ys = np.array(xs), np.array(ys)
        slope, intercept = np.polyfit(xs, ys, 1)
        ss_tot = ((ys - ys.mean()) ** 2).sum()
        r2 = 1 - ((ys - (slope * xs + intercept)) ** 2).sum() / ss_tot if ss_tot > 0 else 0.0
        res[b] = float(np.sign(slope) * max(0.0, r2))
    return res


def tom_similarity(X, beta):
    """Canonical WGCNA topological overlap: TOM_ij = (sum_u a_iu a_uj + a_ij) / (min(k_i,k_j) + 1 - a_ij)."""
    n = X.shape[1]
    A = np.abs((X @ X.T) / n) ** beta
    np.fill_diagonal(A, 0.0)
    k = A.sum(1)
    shared = A @ A
    kmin = np.minimum.outer(k, k)
    TOM = (shared + A) / (kmin + 1 - A)
    np.fill_diagonal(TOM, 1.0)
    return np.clip(TOM, 0, 1)


def _eigengene(expr_mod, groups):
    """First principal component of a module (samples x 1), sign-aligned to the module mean profile."""
    Xi = expr_mod.values
    Xi = (Xi - Xi.mean(1, keepdims=True)) / (Xi.std(1, keepdims=True) + 1e-12)
    U, S, Vt = np.linalg.svd(Xi, full_matrices=False)
    e = Vt[0] * S[0]                     # length = n_samples
    if np.corrcoef(e, Xi.mean(0))[0, 1] < 0:
        e = -e
    return e


def wgcna_modules(expr, groups, n_top=4000, min_module=30, beta_min=14, cut_height=0.40,
                  merge_cut=0.80):
    """Weighted gene co-expression analysis.

    * soft-thresholding power beta chosen from the scale-free fit index, floored at
      beta_min = 14 (the WGCNA recommendation for n ~ 40 samples) so that the network
      stays in the sparse regime;
    * modules detected by average-linkage hierarchical clustering of the signed
      co-expression dissimilarity (1 - Pearson r) cut at a fixed height;
    * each module summarised by its eigengene (first principal component), then
      correlated with disease status; modules with eigengene correlation > merge_cut
      are merged, and modules with < min_module genes are left unassigned.
    """
    v = expr.var(1).sort_values(ascending=False)
    genes = v.index[:n_top]
    X = expr.loc[genes].values.astype(float)
    X = (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-12)
    fits = soft_threshold(pd.DataFrame(X, index=genes))
    beta_fit = next((b for b in sorted(fits) if fits[b] >= 0.80), beta_min)
    beta = max(beta_fit, beta_min)

    R = (X @ X.T) / X.shape[1]
    np.fill_diagonal(R, 1.0)
    D = 1 - R                                   # signed dissimilarity
    np.fill_diagonal(D, 0.0)
    Z = hierarchy.linkage(squareform(D, checks=False), method="average")
    lab = pd.Series(hierarchy.fcluster(Z, t=cut_height, criterion="distance"), index=genes)
    cnt = lab.value_counts()
    lab[lab.isin(cnt[cnt < min_module].index)] = 0
    lab = lab.astype(int)

    y = (groups == "OA").astype(float).values
    MEs = {m: _eigengene(expr.loc[lab.index[lab == m]], groups) for m in sorted(set(lab) - {0})}
    parent = {m: m for m in MEs}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a

    ks = sorted(MEs)
    for i, a in enumerate(ks):
        for b in ks[i + 1:]:
            if np.corrcoef(MEs[a], MEs[b])[0, 1] > merge_cut:
                ra, rb = find(a), find(b)
                if ra != rb:
                    parent[max(ra, rb)] = min(ra, rb)
    lab = lab.map(lambda z: find(z) if z != 0 else 0)
    order = [m for m in lab.value_counts().index if m != 0]
    remap = {m: i + 1 for i, m in enumerate(order)}
    lab = lab.map(lambda z: remap.get(z, 0)).astype(int)

    mods, MEdf = {}, {}
    for m in sorted(set(lab) - {0}):
        g = lab.index[lab == m]
        e = _eigengene(expr.loc[g], groups)
        r, p = stats.pearsonr(e, y)
        mods[m] = {"n_genes": int(len(g)), "r_OA": float(r), "p_OA": float(p), "genes": list(g)}
        MEdf[m] = e
    return {"beta": beta, "beta_fit": beta_fit, "fits": fits, "cut_height": cut_height,
            "modules": mods, "labels": lab, "ME": pd.DataFrame(MEdf, index=expr.columns),
            "linkage": Z, "genes": list(genes)}


# ============================================================ STRING PPI
def string_network(genes, score=400, species=9606):
    u = "https://string-db.org/api/tsv/network"
    data = urllib.parse.urlencode({"identifiers": "\r".join(genes), "species": species,
                                   "required_score": score, "caller_identity": "oa_senescence_study"}).encode()
    txt = urllib.request.urlopen(urllib.request.Request(u, data=data, headers=UA), timeout=120, context=CTX).read().decode("utf8", "ignore")
    rows = [l.split("\t") for l in txt.strip().split("\n") if l.strip()]
    if not rows:
        return pd.DataFrame()
    hdr = rows[0]
    return pd.DataFrame(rows[1:], columns=hdr)


def mcc_scores(G):
    """Maximal clique centrality (Chin et al., cytoHubba) on an undirected graph."""
    import networkx as nx
    scores = {}
    for v in G.nodes():
        nb = list(G.neighbors(v))
        if len(nb) > 25:
            nb = nb[:25]
        sub = G.subgraph(nb)
        best = 0
        # Bron-Kerbosch with pivot, capped
        cliques = []
        def bk(R, P, X):
            if len(cliques) > 4000: return
            if not P and not X:
                cliques.append(R); return
            u = max(P | X, key=lambda z: len(set(G[z]) & P)) if (P | X) else None
            for w in list(P - (set(G[u]) if u else set())):
                bk(R | {w}, P & set(G[w]), X & set(G[w]))
                P = P - {w}; X = X | {w}
        bk(set(), set(nb), set())
        for c in cliques:
            best = max(best, len(c))
        scores[v] = best * (best - 1) / 2 if best > 1 else 0
    return scores


# ============================================================ main
if __name__ == "__main__":
    expr = pd.read_csv(os.path.join(WORK, "expr_GSE114007.csv"), index_col=0)
    labels = pd.read_csv(os.path.join(WORK, "labels_GSE114007.csv"), index_col=0).iloc[:, 0]
    print("discovery:", expr.shape, dict(labels.value_counts()))

    # filter low-expression genes
    keep = (expr > 1).sum(1) >= max(5, 0.5 * expr.shape[1])
    expr_f = expr.loc[keep]
    print("after expression filter:", expr_f.shape)

    deg = ebayes_moderated_t(expr_f, labels)
    deg.to_csv(os.path.join(OUT, "deg_GSE114007_full.csv"))
    print("DEG table:", deg.shape, "| d0 =", float(deg["df.prior"].iloc[0]))
    print("nominal p<0.05:", int((deg["P.Value"] < 0.05).sum()),
          "| FDR<0.05:", int((deg["adj.P.Val"] < 0.05).sum()),
          "| |logFC|>1 & FDR<0.05:", int(((deg["adj.P.Val"] < 0.05) & (deg["logFC"].abs() > 1)).sum()))

    srg, used, libdict = build_senescence_set()
    print("senescence-related genes (union of curated real gene sets):", len(srg))
    print(json.dumps({k: v for k, v in used.items()}, indent=1))
    json.dump(sorted(srg), open(os.path.join(OUT, "senescence_gene_universe.json"), "w"), indent=1)

    deg_srg = deg[deg.index.isin(srg)].copy()
    srd = deg_srg[(deg_srg["adj.P.Val"] < 0.05) & (deg_srg["logFC"].abs() > 1)]
    srd.to_csv(os.path.join(OUT, "SRDEGs.csv"))
    print("senescence-related DEGs (SRDEGs, |logFC|>1 & FDR<0.05):", srd.shape)

    # wider pool for machine learning: any senescence gene significant at FDR<0.05
    srd_loose = deg_srg[deg_srg["adj.P.Val"] < 0.05]
    srd_loose.to_csv(os.path.join(OUT, "SRDEGs_FDRonly.csv"))
    print("senescence genes with FDR<0.05 (ML pool):", srd_loose.shape)

    # ---- enrichment (Enrichr, real API)
    LIBS = ["GO_Biological_Process_2023", "KEGG_2021_Human", "Reactome_2022",
            "WikiPathway_2023_Human", "MSigDB_Hallmark_2020", "DisGeNET",
            "Jensen_DISEASES", "Human_Phenotype_Ontology"]
    enr = enrichr(srd.index.tolist(), LIBS, "SRDEGs_GSE114007", background=expr_f.index.tolist())
    json.dump(enr, open(os.path.join(OUT, "enrichr_SRDEGs.json"), "w"), indent=1)
    for lib in LIBS:
        top = enr.get(lib, [])[:5]
        print("--", lib)
        for r in top:
            print(f"     {r['term'][:70]:70s} p={r['pval']:.3g} adjp={r['adjp']:.3g} n={r['n_overlap']}")

    # ---- WGCNA-style modules
    wg = wgcna_modules(expr_f, labels, n_top=4000, min_module=30)
    print("soft power beta =", wg["beta"], "(raw scale-free optimum:", wg["beta_fit"], ") | cut height =", wg["cut_height"])
    sig_mods = {k: v for k, v in wg["modules"].items() if v["p_OA"] < 0.05}
    print("modules:", len(wg["modules"]),
          "| module sizes:", {k: v["n_genes"] for k, v in wg["modules"].items()})
    print("OA-associated modules:", {k: (v['n_genes'], round(v['r_OA'], 3), round(v['p_OA'], 5)) for k, v in sig_mods.items()})
    json.dump({"beta": wg["beta"], "beta_fit": wg["beta_fit"], "cut_height": wg["cut_height"],
               "modules": {str(k): v for k, v in wg["modules"].items()}},
              open(os.path.join(OUT, "wgcna_modules.json"), "w"), indent=1)
    np.save(os.path.join(OUT, "wgcna_linkage.npy"), wg["linkage"])
    json.dump(wg["genes"], open(os.path.join(OUT, "wgcna_genes.json"), "w"))
    wg["ME"].to_csv(os.path.join(OUT, "module_eigengenes.csv"))
    wg["labels"].to_csv(os.path.join(OUT, "module_assignment.csv"))
    json.dump(wg["fits"], open(os.path.join(OUT, "soft_threshold_fits.json"), "w"), indent=1)

    # module-senescence intersection
    mod_genes = set()
    for k, v in sig_mods.items():
        mod_genes |= set(v["genes"])
    inter = sorted(mod_genes & srg)
    json.dump(inter, open(os.path.join(OUT, "module_senescence_intersection.json"), "w"), indent=1)
    print("genes in OA-associated modules AND senescence universe:", len(inter))

    # ---- PPI (STRING)
    cand = sorted(set(srd.index) | set(inter))
    json.dump(cand, open(os.path.join(OUT, "candidate_pool.json"), "w"), indent=1)
    print("candidate pool for PPI:", len(cand))
    net = string_network(cand)
    net.to_csv(os.path.join(OUT, "string_network.tsv"), sep="\t", index=False)
    import networkx as nx
    G = nx.Graph()
    if len(net):
        for _, r in net.iterrows():
            G.add_edge(r["preferredName_A"], r["preferredName_B"], weight=float(r["score"]))
    G.remove_nodes_from(list(nx.isolates(G)))
    deg_c = dict(G.degree())
    btw = nx.betweenness_centrality(G)
    clo = nx.closeness_centrality(G)
    mcc = mcc_scores(G)
    hub = pd.DataFrame({"gene": list(G.nodes())})
    hub["degree"] = hub["gene"].map(deg_c)
    hub["betweenness"] = hub["gene"].map(btw)
    hub["closeness"] = hub["gene"].map(clo)
    hub["MCC"] = hub["gene"].map(mcc)
    for c in ["degree", "betweenness", "closeness", "MCC"]:
        hub[c + "_rank"] = hub[c].rank(ascending=False)
    hub["rank_sum"] = hub[[c + "_rank" for c in ["degree", "betweenness", "closeness", "MCC"]]].sum(1)
    hub = hub.sort_values("rank_sum")
    hub.to_csv(os.path.join(OUT, "ppi_hub_ranking.csv"), index=False)
    print("PPI nodes:", G.number_of_nodes(), "edges:", G.number_of_edges())
    print(hub.head(20).to_string(index=False))
    print("STEP2 DONE")
