"""
step21_rediscovery.py — independent re-discovery in a second cartilage cohort.

The signature was derived from GSE114007 (RNA-sequencing, 20 OA / 18 normal).  A fair objection
is that it is specific to that cohort.  GSE57218 provides a genuinely independent cartilage
cohort profiled on a different platform (Illumina HumanHT-12 V3) with three arms: healthy
cartilage (n = 7), macroscopically osteoarthritic cartilage (n = 33) and macroscopically
preserved cartilage from the same osteoarthritic joints (n = 33).

Two questions are asked:
  1. does the *biology* replicate -- is the checkpoint / AP-1 arm suppressed here too, when the
     differential expression analysis is redone from scratch on this cohort alone?
  2. does the *frozen* signature transfer, and does it track lesion status within the joint?
"""
import gzip, json, os
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

import step1_prepare as P
from step2_deg import ebayes_moderated_t

BASE = os.path.dirname(os.path.abspath(__file__))
EXTRA = os.path.join(BASE, "data", "extra")
OUT = os.path.join(BASE, "results")
WORK = os.path.join(BASE, "work")

# the two arms of the decoupled programme, as reported for the discovery cohort
SUPPRESSED = ["JUN", "CDKN1A", "GADD45B", "FOS", "ETS2", "GADD45A", "UBC", "CEBPB",
              "CDKN1B", "RELA", "MYC", "FOXO3"]
INDUCED = ["IGFBP3", "CCND1", "TWIST1", "CCNA2", "CDK6", "CDKN2B", "EZH2", "TFDP1", "FOXM1"]


def bh(p):
    p = np.asarray(p, float)
    ok = np.isfinite(p)
    q = np.full(len(p), np.nan)
    po = p[ok]
    o = np.argsort(po)
    qq = np.empty(len(po))
    qq[o] = np.minimum.accumulate((po[o] * len(po) / (np.arange(len(po)) + 1))[::-1])[::-1]
    q[ok] = np.clip(qq, 0, 1)
    return q


def boot_ci(y, p, n=2000, seed=1):
    rng = np.random.default_rng(seed); a = []
    y = np.asarray(y); p = np.asarray(p)
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if len(set(y[i])) < 2:
            continue
        a.append(roc_auc_score(y[i], p[i]))
    return np.percentile(a, [2.5, 97.5]) if a else np.array([np.nan, np.nan])


def read_gpl6947():
    f = os.path.join(EXTRA, "GPL6947.annot.gz")
    with gzip.open(f, "rt", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("ID\t") or line.startswith("ID "):
                hdr = line.rstrip("\n").split("\t")
                rows = [r.rstrip("\n").split("\t") for r in fh]
                break
    df = pd.DataFrame(rows, columns=hdr)
    sym = next(c for c in df.columns if c.strip().lower() in ("gene symbol", "symbol", "genesymbol"))
    return dict(zip(df["ID"], df[sym]))


def main():
    sig = json.load(open(os.path.join(OUT, "signature.json")))
    srg = json.load(open(os.path.join(OUT, "senescence_gene_universe.json")))

    expr, meta = P.parse_series_matrix(os.path.join(EXTRA, "GSE57218_series_matrix.txt.gz"))
    probe2sym = read_gpl6947()
    print(f"GPL6947 annotation: {len(probe2sym)} probes")
    expr = P.collapse_to_symbols(P.quantile_normalize(P.log2_if_needed(expr)), probe2sym)
    expr = expr.loc[:, ~expr.columns.duplicated()]
    meta = meta.set_index("gsm")
    chars = pd.Series({c: P._chars(meta.loc[c]) for c in expr.columns})
    grp = chars.map(lambda t: "OA" if "oa" in t and "healthy" not in t else
                    ("Healthy" if "healthy" in t else
                     ("Preserved" if "preserved" in t else None)))
    keep = grp[grp.notna()].index
    expr, grp = expr.loc[:, keep], grp.loc[keep]
    print("GSE57218 arms:", dict(grp.value_counts()), f"| genes: {expr.shape[0]}")

    # ---------- 1. independent differential expression, OA vs healthy, from scratch
    oa_h = grp.isin(["OA", "Healthy"])
    e2 = expr.loc[:, oa_h]
    g2 = pd.Series(np.where(grp[oa_h] == "OA", "OA", "Normal"), index=e2.columns)
    de = ebayes_moderated_t(e2, g2)
    de["fdr"] = bh(de["P.Value"])
    de.to_csv(os.path.join(OUT, "rediscovery_deg.csv"))
    print(f"\nindependent DE (OA vs healthy, n={int(oa_h.sum())}): "
          f"{int((de['fdr'] < 0.05).sum())} genes at FDR<0.05, "
          f"{int(((de['fdr'] < 0.05) & (de['logFC'].abs() > 1)).sum())} with |logFC|>1")

    disc = pd.read_csv(os.path.join(OUT, "deg_GSE114007_full.csv"), index_col=0)

    def arm(genes, label):
        rows = []
        for g in genes:
            if g not in de.index:
                continue
            rows.append({"gene": g, "logFC_GSE57218": float(de.loc[g, "logFC"]),
                         "fdr_GSE57218": float(de.loc[g, "fdr"]),
                         "logFC_discovery": float(disc.loc[g, "logFC"]) if g in disc.index else np.nan})
        d = pd.DataFrame(rows)
        if not len(d):
            return d, {}
        d["same_direction"] = np.sign(d["logFC_GSE57218"]) == np.sign(d["logFC_discovery"])
        conc = int(d["same_direction"].sum())
        # one-sided sign test against a null of no directional agreement
        sp = float(stats.binomtest(conc, len(d), 0.5, alternative="greater").pvalue)
        print(f"  {label:12s} n={len(d):2d}  direction concordant {conc}/{len(d)}  "
              f"sign-test P={sp:.4f}  median logFC={d['logFC_GSE57218'].median():+.3f}")
        return d, {"n": len(d), "concordant": conc, "sign_test_p": sp}

    print("\nreplication of the two programme arms:")
    d_sup, s_sup = arm(SUPPRESSED, "suppressed")
    d_ind, s_ind = arm(INDUCED, "induced")
    pd.concat([d_sup.assign(arm="suppressed"), d_ind.assign(arm="induced")]).to_csv(
        os.path.join(OUT, "rediscovery_arms.csv"), index=False)

    # ---------- 2. frozen signature transferred, and lesion gradient
    dl = pd.read_csv(os.path.join(WORK, "labels_GSE114007.csv"), index_col=0).iloc[:, 0]
    disc_expr = pd.read_csv(os.path.join(WORK, "expr_GSE114007.csv"), index_col=0)
    present = [g for g in sig if g in expr.index]
    z = lambda D: ((D - D.mean()) / D.std().replace(0, np.nan)).fillna(0.0)
    model = LogisticRegression(max_iter=5000, C=1.0).fit(
        z(disc_expr.loc[present].T).values, (dl == "OA").astype(int).values)
    pr = pd.Series(model.predict_proba(z(expr.loc[present].T).values)[:, 1], index=expr.columns)
    score = z(expr.loc[present].T).mean(1)

    out = {}
    for a, b in [("OA", "Healthy"), ("Preserved", "Healthy"), ("OA", "Preserved")]:
        sel = grp.isin([a, b])
        y = (grp[sel] == a).astype(int).values
        auc = roc_auc_score(y, pr[sel].values); lo, hi = boot_ci(y, pr[sel].values)
        sc = score[sel].values
        aucs = roc_auc_score(y, sc)
        pv = float(stats.mannwhitneyu(sc[y == 1], sc[y == 0]).pvalue)
        out[f"{a}_vs_{b}"] = {"n": int(sel.sum()), "auc_panel": float(auc),
                              "ci": [float(lo), float(hi)], "auc_score": float(aucs),
                              "score_p": pv}
        print(f"  {a:9s} vs {b:8s} n={int(sel.sum()):2d}  panel AUC={auc:.3f} "
              f"[{lo:.3f},{hi:.3f}]  score AUC={aucs:.3f}  score P={pv:.4f}")

    pd.DataFrame([{"contrast": k, **v} for k, v in out.items()]).to_csv(
        os.path.join(OUT, "rediscovery_contrasts.csv"), index=False)
    json.dump({"arms": {"suppressed": s_sup, "induced": s_ind}, "contrasts": out,
               "n_genes_tested": int(de.shape[0]),
               "n_de_fdr05": int((de["fdr"] < 0.05).sum()),
               "genes_present": present},
              open(os.path.join(OUT, "rediscovery_summary.json"), "w"), indent=1)
    print("\nSTEP21 DONE")


if __name__ == "__main__":
    main()
