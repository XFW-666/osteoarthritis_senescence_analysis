"""Read only the header of each candidate GEO series matrix (HTTP range) to learn the platform,
sample count and case/control groups without downloading the full matrix."""
import gzip, io, subprocess, re, collections, zlib

CANDS = ["GSE63695", "GSE43269", "GSE43270", "GSE73626", "GSE63106", "GSE162484", "GSE169077"]


def url_for(g):
    stub = g[:-3] + "nnn"
    return (f"https://ftp.ncbi.nlm.nih.gov/geo/series/{stub}/{g}/matrix/"
            f"{g}_series_matrix.txt.gz")


def partial_gunzip(raw):
    """Decompress as much of a truncated gzip stream as possible (range requests cut it short)."""
    d = zlib.decompressobj(16 + zlib.MAX_WBITS)
    return d.decompress(raw).decode("utf-8", "replace")


for g in CANDS:
    u = url_for(g)
    p = subprocess.run(["curl", "-sS", "-m", "90", "-r", "0-400000", u],
                       capture_output=True)
    if p.returncode != 0 or len(p.stdout) < 200:
        print(f"{g}: fetch failed rc={p.returncode} bytes={len(p.stdout)}")
        continue
    if not p.stdout.startswith(b"\x1f\x8b"):
        print(f"{g}: not gzip, first bytes = {p.stdout[:80]!r}")
        continue
    txt = partial_gunzip(p.stdout)
    plat = re.search(r"!Series_platform_id\t(\S+)", txt)
    n = re.search(r"!Series_summary\t(.*)", txt)
    print("=" * 100)
    print(f"{g}  platform={plat.group(1) if plat else '?'}")
    print("  title:", (re.search(r'!Series_title\t"(.*)"', txt) or [None, "?"])[1][:110])
    for l in txt.split("\n"):
        if l.startswith("!Sample_characteristics"):
            vals = [v.strip().strip('"') for v in l.split("\t")[1:]]
            c = collections.Counter(vals)
            if len(c) <= 12:
                print(f"  {l.split(chr(9))[0][:44]:46s} n={len(vals)} {dict(c)}")
            else:
                print(f"  {l.split(chr(9))[0][:44]:46s} n={len(vals)} (all distinct) e.g. {vals[:3]}")
        if l.startswith("!Sample_source_name"):
            vals = [v.strip().strip('"') for v in l.split("\t")[1:]]
            print(f"  source_name n={len(vals)} e.g. {collections.Counter(vals).most_common(4)}")
