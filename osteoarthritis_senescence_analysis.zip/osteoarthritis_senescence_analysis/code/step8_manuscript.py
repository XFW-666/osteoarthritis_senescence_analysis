"""
step8_manuscript.py — assemble the full manuscript (Medicine / LWW style) as a Word file,
with embedded figures, five tables, the verified reference list and a cover letter.
"""
import os, re, json, sys
import pandas as pd
import numpy as np
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "results"); FIG = os.path.join(BASE, "figures")
sys.path.insert(0, BASE)

import manuscript_text as T1
import manuscript_text2 as T2
from refs_build import build as build_refs

ACCENT = RGBColor(0x0B, 0x3D, 0x91)


# --------------------------------------------------------------------------- helpers
def set_base_style(doc):
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(10)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    pf = st.paragraph_format
    # so the space is taken from leading and figure size rather than from the prose.
    pf.space_after = Pt(5); pf.line_spacing = 1.25


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = True
    run.font.size = Pt(13 if level == 1 else 11.5)
    run.font.color.rgb = ACCENT if level == 1 else RGBColor(0x20, 0x20, 0x20)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    return p


def add_para(doc, text, italic=False, size=10, align=None, bold=False, first_indent=None):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.italic = italic; r.bold = bold; r.font.size = Pt(size)
    if align == "center":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "justify":
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    if first_indent is not None:
        p.paragraph_format.first_line_indent = Inches(first_indent)
    return p


def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def add_table(doc, df, caption, note=None, fontsize=8.5, widths=None, align_right=None):
    add_para(doc, caption, bold=True, size=10)
    t = doc.add_table(rows=1, cols=len(df.columns))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for i, c in enumerate(df.columns):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        r = p.add_run(str(c)); r.bold = True; r.font.size = Pt(fontsize)
        p.paragraph_format.space_after = Pt(0)
        shade(hdr[i], "DCE6F1")
    for _, row in df.iterrows():
        cells = t.add_row().cells
        for i, c in enumerate(df.columns):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            r = p.add_run("" if pd.isna(row[c]) else str(row[c]))
            r.font.size = Pt(fontsize)
            p.paragraph_format.space_after = Pt(0)
            if align_right and c in align_right:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    if note:
        add_para(doc, note, italic=True, size=8.5)
    doc.add_paragraph()
    return t


def add_figure(doc, path, legend_title, legend_text, width=6.6, max_px=2400):
    """Embed a manuscript-resolution copy (the full-resolution PNGs remain in figures/)."""
    if os.path.exists(path):
        from PIL import Image
        im = Image.open(path)
        if im.width > max_px:
            h = int(round(im.height * max_px / im.width))
            tmp = os.path.join(BASE, "_build", "_embed_" + os.path.basename(path))
            os.makedirs(os.path.dirname(tmp), exist_ok=True)
            im.resize((max_px, h), Image.LANCZOS).save(tmp, dpi=(300, 300))
            path = tmp
        doc.add_picture(path, width=Inches(width))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = doc.add_paragraph()
    r = p.add_run(legend_title + " "); r.bold = True; r.font.size = Pt(9)
    r2 = p.add_run(legend_text); r2.font.size = Pt(9)
    p.paragraph_format.space_after = Pt(12)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


def fmt_p(p):
    try:
        p = float(p)
    except Exception:
        return str(p)
    if p == 0 or p < 1e-300:
        return "<1e-300"
    if p < 1e-4:
        return f"{p:.1e}"
    return f"{p:.4f}"


# --------------------------------------------------------------------------- tables
def table1():
    c = json.load(open(os.path.join(BASE, "work", "cohorts.json")))
    order = ["GSE114007", "GSE169077", "GSE283079", "GSE55235", "GSE55457"]
    rows = []
    for k in order:
        d = c[k]
        rows.append({"Accession": k, "Tissue": d["tissue"].capitalize(),
                     "Platform": ("RNA-sequencing" if "RNA" in d["platform"] else "Affymetrix HG-U133A (GPL96)"),
                     "OA (n)": d["oa"], "Non-OA (n)": d["normal"], "Total (n)": d["n"],
                     "Analytic role": d["role"]})
    rows.append({"Accession": "GSE104782", "Tissue": "Cartilage (single cell)", "Platform": "10x Genomics scRNA-seq",
                 "OA (n)": "10 patients", "Non-OA (n)": "0", "Total (n)": "1,600 cells",
                 "Analytic role": "Cellular localisation"})
    rows.append({"Accession": "GSE255460", "Tissue": "Cartilage (single cell)", "Platform": "10x Genomics scRNA-seq",
                 "OA (n)": "8 donors", "Non-OA (n)": "1 donor", "Total (n)": "134,551 cells",
                 "Analytic role": "Independent cellular replication"})
    rows.append({"Accession": "GSE57218", "Tissue": "Cartilage", "Platform": "Illumina HumanHT-12 V3",
                 "OA (n)": "33", "Non-OA (n)": "7 healthy; 33 preserved",
                 "Total (n)": "73", "Analytic role": "Independent re-discovery"})
    rows.append({"Accession": "GSE43269", "Tissue": "Cartilage (methylation)", "Platform": "Illumina HumanMethylation27",
                 "OA (n)": "23", "Non-OA (n)": "18", "Total (n)": "41",
                 "Analytic role": "Epigenetic layer"})
    rows.append({"Accession": "GSE73626", "Tissue": "Cartilage (methylation)", "Platform": "Illumina HumanMethylation450",
                 "OA (n)": "11", "Non-OA (n)": "7", "Total (n)": "18",
                 "Analytic role": "Epigenetic layer"})
    return pd.DataFrame(rows)


def table2():
    srd = pd.read_csv(os.path.join(OUT, "SRDEGs.csv"), index_col=0)
    coefs = pd.read_csv(os.path.join(OUT, "signature_coefficients.csv"))
    sig = set(json.load(open(os.path.join(OUT, "signature.json"))))
    cmap = dict(zip(coefs["gene"], coefs["coef"]))
    df = srd.reset_index().rename(columns={"gene": "Gene"})
    df["Signature"] = ["Yes" if g in sig else "" for g in df["Gene"]]
    df["Logistic coefficient"] = [f"{cmap[g]:.3f}" if g in cmap else "" for g in df["Gene"]]
    df = df[["Gene", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "Signature", "Logistic coefficient"]]
    df.columns = ["Gene", "log2 FC", "Average expression", "Moderated t", "P", "FDR", "In signature", "Logistic coefficient"]
    df["log2 FC"] = df["log2 FC"].round(3)
    df["Average expression"] = df["Average expression"].round(2)
    df["Moderated t"] = df["Moderated t"].round(3)
    df["P"] = df["P"].map(fmt_p)
    df["FDR"] = df["FDR"].map(fmt_p)
    return df


def table3():
    enr = json.load(open(os.path.join(OUT, "enrichr_SRDEGs.json")))
    pick = [("Reactome_2022", "Reactome", 5), ("KEGG_2021_Human", "KEGG", 4),
            ("GO_Biological_Process_2023", "GO biological process", 5),
            ("MSigDB_Hallmark_2020", "MSigDB hallmark", 4), ("WikiPathway_2023_Human", "WikiPathway", 3)]
    rows = []
    for lib, label, k in pick:
        for r in enr.get(lib, [])[:k]:
            rows.append({"Library": label, "Term": r["term"], "Genes": r["n_overlap"],
                         "P": fmt_p(r["pval"]), "FDR": fmt_p(r["adjp"])})
    return pd.DataFrame(rows)


def table4():
    b = pd.read_csv(os.path.join(OUT, "model_benchmark.csv"))
    b = b.sort_values("AUC", ascending=False)
    df = pd.DataFrame({
        "Classifier": b["model"],
        "AUC": b["AUC"].round(3),
        "95% CI": [f"{lo:.3f}-{hi:.3f}" for lo, hi in zip(b["AUC_ci_lo"], b["AUC_ci_hi"])],
        "Sensitivity": b["sensitivity"].round(2),
        "Specificity": b["specificity"].round(2),
        "PPV": b["PPV"].round(2),
        "NPV": b["NPV"].round(2),
        "F1": b["F1"].round(3),
        "MCC": b["MCC"].round(3),
        "Brier": b["Brier"].round(3),
    })
    return df


def table5():
    ext = json.load(open(os.path.join(OUT, "external_predictions.json")))
    dc = pd.read_csv(os.path.join(OUT, "direction_consistency.csv")).set_index("cohort")
    rows = []
    for acc, d in ext.items():
        rows.append({"Cohort": acc, "n": d["n"], "OA (n)": d["n_oa"],
                     "Panel AUC": f"{d['auc']:.3f}",
                     "Panel 95% CI": f"{d['ci'][0]:.3f}-{d['ci'][1]:.3f}",
                     "Senescence-score AUC": f"{d['auc_score']:.3f}",
                     "Signature genes available": f"{d['n_present']}/8",
                     "Direction-concordant genes": f"{dc.loc[acc,'direction_consistent']}/{dc.loc[acc,'genes_present']}"})
    return pd.DataFrame(rows)


def table6():
    coefs = pd.read_csv(os.path.join(OUT, "signature_coefficients.csv"))
    df = coefs.rename(columns={"gene": "Gene", "coef": "Logistic coefficient", "logFC": "log2 fold change (OA vs normal)"})
    df["Logistic coefficient"] = df["Logistic coefficient"].round(3)
    df["log2 fold change (OA vs normal)"] = df["log2 fold change (OA vs normal)"].round(3)
    df["Direction in OA"] = "Down-regulated"
    return df


# --------------------------------------------------------------------------- citation check
def cited_numbers(texts):
    nums = set()
    for t in texts:
        for m in re.findall(r"\[([0-9,\-\s]+)\]", t):
            for part in m.split(","):
                part = part.strip()
                if "-" in part:
                    try:
                        a, b = part.split("-"); nums.update(range(int(a), int(b) + 1))
                    except Exception:
                        pass
                elif part.isdigit():
                    nums.add(int(part))
    return nums


def collect_texts():
    out = []
    for k, v in T1.ABSTRACT.items():
        out.append(v)
    out += T1.KEY_POINTS
    for sec in (T1.INTRODUCTION,):
        for p in sec:
            out.append(p if isinstance(p, str) else " ".join(p))
    for name, blocks in T1.METHODS:
        for b in blocks:
            out.append(b)
    for name, blocks in T2.RESULTS:
        for b in blocks:
            out.append(b)
    for name, blocks in T2.DISCUSSION:
        for b in blocks:
            out.append(b)
    out += T2.CONCLUSION
    return out


# --------------------------------------------------------------------------- build
# --------------------------------------------------------------------------- v1 (earlier) legends
# The figure set that preceded the redesign.  Kept so the two versions can be built and compared.
V1_LEGENDS = [
    ("Figure 1.", "Conceptual framework of the study. (A) Schematic of the osteoarthritic joint showing the "
     "articular cartilage layers, synovial involvement, enlarged senescent chondrocytes, the "
     "senescence-associated secretory phenotype (SASP) secretome and immune cell recruitment. (B) The "
     "senescence-SASP vicious cycle linking mechanical and oxidative stress to checkpoint activation, "
     "secretome output, matrix catabolism and further senescence; the diagnostic senescence signature is "
     "highlighted at the centre. (C) The decoupled senescence programme in OA: the p53/p21-GADD45 "
     "checkpoint and AP-1 arms are suppressed while cell-cycle re-entry and SASP output are induced, with a "
     "net increase in programme activity. (D) Analytical workflow, from five public cohorts through "
     "differential expression, curated senescence gene sets, co-expression and interaction network "
     "analysis, three-algorithm feature selection, a fourteen-model nested cross-validation benchmark and "
     "senotherapeutic repurposing."),
    ("Figure 2.", "Transcriptomic landscape of the discovery cohort (GSE114007). (A) Composition of the "
     "discovery and validation cohorts by tissue and platform. (B) Principal component analysis of the "
     "2,000 most variable genes. (C) Volcano plot of differential expression with senescence-universe genes "
     "highlighted. (D) Heatmap of the 30 most differentially expressed genes, ordered by group. (E) "
     "Tissue-level senescence-programme activity (ssGSEA) in OA versus normal cartilage. (F) Log2 fold "
     "change of all senescence-universe genes detected in the discovery cohort."),
    ("Figure 3.", "Weighted co-expression analysis. (A) Scale-free topology fit and mean connectivity as a "
     "function of the soft-thresholding power; the selected power (beta = 14) is marked. (B) Size of each "
     "module and its content of senescence-universe genes. (C) Convergent evidence for candidate genes "
     "across the differential expression, co-expression and senescence-universe analyses. (D) Hierarchical "
     "clustering dendrogram of the 4,000 most variable genes with the module colour strip shown below. (E) "
     "Module-trait heatmap showing the correlation of each module eigengene with disease status. (F) "
     "Correlation between module eigengenes, indicating coordination between modules."),
    ("Figure 4.", "Functional enrichment of the 24 senescence-related differentially expressed genes. Bubble "
     "plots show over-representation results for the Gene Ontology biological process, KEGG, Reactome, "
     "WikiPathway, MSigDB hallmark and DisGeNET libraries; bubble area is proportional to the number of "
     "overlapping genes and colour denotes the library."),
    ("Figure 5.", "Protein-protein interaction network and hub prioritisation. (A) STRING network of "
     "candidate genes; node size is proportional to maximal clique centrality and colour indicates the "
     "direction of change in OA. (B) Ranking of hub genes by normalised maximal clique centrality. (C) "
     "Expression of the six highest-ranked hub genes in OA and normal cartilage. (D) Correlation matrix "
     "among hub genes."),
    ("Figure 6.", "Machine-learning feature selection and model benchmarking. (A) LASSO stability selection "
     "frequency across 200 bootstrap resamples. (B) Random-forest Gini importance, with stars marking genes "
     "retained by support-vector-machine recursive feature elimination. (C) Nested cross-validated receiver "
     "operating characteristic curves for the 14 benchmarked classifiers. (D) Area under the curve with 95% "
     "bootstrap confidence intervals for each classifier. (E) SHAP beeswarm plot summarising the "
     "contribution of each signature gene to the predicted probability of OA. (F) Global feature attribution "
     "by mean absolute SHAP value."),
    ("Figure 7.", "Diagnostic performance and clinical utility of the eight-gene signature. (A) Expression "
     "heatmap of the signature genes, ordered by group. (B) Receiver operating characteristic curve of the "
     "signature in the discovery cohort with the Youden-optimal operating point. (C) Distribution of "
     "cross-validated predicted probabilities by group. (D) Decision-curve analysis of net benefit across "
     "threshold probabilities. (E) Nomogram assigning points to each signature gene, with the corresponding "
     "predicted risk of OA. (F) External validation of the frozen signature in four independent cohorts."),
    ("Figure 8.", "Immune and stromal landscape, single-cell localisation and candidate therapeutics. (A) "
     "Heatmap of cell-type and immune infiltration scores in OA and normal cartilage. (B) Difference in "
     "cell-type enrichment scores between groups with significance annotation. (C) Correlation between "
     "signature genes and cell-type programmes. (D) Candidate compounds nominated by drug-perturbation "
     "enrichment. (E) Inferred upstream transcription-factor network. (F) Expression of the signature genes "
     "across single-cell chondrocyte subpopulations."),
]


# --------------------------------------------------------------------------- citation numbering
def _n_supplementary(default=20):
    """Count the sheets actually written to the supplementary workbook, so the summary line
    on the title page cannot drift out of step with the workbook."""
    x = os.path.join(BASE, "Supplementary_Tables.xlsx")
    if not os.path.exists(x):
        return default
    try:
        from openpyxl import load_workbook
        return len(load_workbook(x, read_only=True).sheetnames)
    except Exception:
        return default


def _parse_cites(text):
    out = []
    for m in re.finditer(r"\[([0-9,\-\s]+)\]", text):
        for part in m.group(1).split(","):
            part = part.strip()
            if "-" in part:
                try:
                    a, b = part.split("-")
                    out.extend(range(int(a), int(b) + 1))
                except Exception:
                    pass
            elif part.isdigit():
                out.append(int(part))
    return out


def citation_map(texts):
    """AMA numbers references in order of first appearance, so rebuild the map in document order."""
    order = []
    for t in texts:
        for n in _parse_cites(t):
            if n not in order:
                order.append(n)
    return {old: i + 1 for i, old in enumerate(order)}, order


def apply_citation_map(text, mp):
    def repl(m):
        nums = sorted({mp.get(n, n) for n in _parse_cites("[" + m.group(1) + "]")})
        out, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            if j - i >= 2:
                out.append(f"{nums[i]}-{nums[j]}")
            else:
                out.extend(str(x) for x in nums[i:j + 1])
            i = j + 1
        return "[" + ",".join(out) + "]"
    return re.sub(r"\[([0-9,\-\s]+)\]", repl, text)


def save_docx(doc, path):
    """Save, falling back to a suffixed name if the target is open in Word (it locks the file)."""
    try:
        doc.save(path)
        return path
    except PermissionError:
        root, ext = os.path.splitext(path)
        alt = f"{root}_updated{ext}"
        doc.save(alt)
        print(f"  !! {os.path.basename(path)} is open in another program; wrote {os.path.basename(alt)} instead")
        return alt


def build(out_name="Osteoarthritis_senescence_manuscript.docx", fig_dir=None, legends=None,
          version_label=None):
    import re
    refs = build_refs()
    texts = collect_texts()
    cited = cited_numbers(texts)
    all_n = set(r["n"] for r in refs)
    missing = sorted(all_n - cited)
    print(f"references: {len(refs)} | cited: {len(cited & all_n)} | uncited: {missing}")
    assert not missing, f"uncited references: {missing}"

    fdir = fig_dir or FIG
    leg = legends if legends is not None else T2.FIGURE_LEGENDS
    leg_map = {t.rstrip("."): b for t, b in leg}

    # label -> (file, printed width in inches)
    FIG_DEFS = {
        "Figure 1": ("Figure1_conceptual_framework.png", 5.0),
        "Figure 2": ("Figure2_transcriptomic_landscape.png", 5.2),
        "Figure 3": ("Figure3_coexpression_modules.png", 5.2),
        "Figure 4": ("Figure4_functional_enrichment.png", 5.2),
        "Figure 5": ("Figure5_ppi_hub_network.png", 5.2),
        "Figure 6": ("Figure6_machine_learning.png", 5.2),
        "Figure 7": ("Figure7_diagnostic_model.png", 5.2),
        "Figure 8": ("Figure8_immune_therapeutics.png", 5.3),
        "Figure 9": ("Figure9_causal_reversal_boundary.png", 5.3),
        "Figure 10": ("Figure10_replication_specificity_layers.png", 5.3),
    }
    TAB_DEFS = {
        "Table 1": (table1(), "Table 1. Characteristics of the included datasets.",
                    "OA = osteoarthritis; scRNA-seq = single-cell RNA sequencing. Samples annotated as "
                    "rheumatoid arthritis or other inflammatory arthritides were excluded. GSE169077 "
                    "comprises pooled cartilage samples (five individual RNA samples per pool)."),
        "Table 2": (table2(), "Table 2. Senescence-related differentially expressed genes in OA versus "
                    "normal cartilage (n = 24; |log2 FC| > 1 and FDR < 0.05).",
                    "FC = fold change; FDR = false-discovery rate. Genes were derived from the discovery "
                    "cohort GSE114007 (20 OA, 18 normal). Positive log2 FC indicates higher expression in OA."),
        "Table 3": (table3(), "Table 3. Leading over-representation results for the 24 senescence-related "
                    "differentially expressed genes.",
                    "FDR = false-discovery rate. Terms were returned by the Enrichr application-programming "
                    "interface; FDR values are adjusted within each library."),
        "Table 5": (table4(), "Table 5. Nested cross-validated performance of 14 classifiers on the "
                    "eight-gene senescence signature (inner 5-fold tuning; outer 5-fold stratified split "
                    "repeated five times).",
                    "AUC = area under the receiver operating characteristic curve; CI = confidence interval; "
                    "PPV = positive predictive value; NPV = negative predictive value; MCC = Matthews "
                    "correlation coefficient. Confidence intervals were obtained by bootstrap resampling "
                    "(2,000 replicates)."),
        "Table 6": (table5(), "Table 6. External validation of the frozen eight-gene signature in four "
                    "independent cohorts.",
                    "AUC = area under the receiver operating characteristic curve; CI = confidence interval. "
                    "The multi-gene panel was applied after within-cohort standardisation of expression "
                    "values. Direction concordance indicates the proportion of signature genes whose "
                    "direction of change matched the discovery cohort."),
        "Table 4": (table6(), "Table 4. The eight-gene senescence signature.",
                    "Genes were selected by consensus of at least two of three algorithms (LASSO stability "
                    "selection, support-vector-machine recursive feature elimination and random-forest "
                    "importance) and ranked by absolute logistic coefficient."),
    }

    doc = Document()
    set_base_style(doc)
    st = doc.styles["Normal"]
    st.paragraph_format.space_after = Pt(3)
    st.paragraph_format.line_spacing = 1.08
    for s in doc.sections:
        s.top_margin = Inches(0.9); s.bottom_margin = Inches(0.9)
        s.left_margin = Inches(1.0); s.right_margin = Inches(1.0)

    placed_f, placed_t = set(), set()

    # references are renumbered in order of first appearance (AMA style)
    body_texts = list(T1.INTRODUCTION)
    for _n, blk in T1.METHODS:
        body_texts += list(blk)
    for _n, blk in T2.RESULTS:
        body_texts += list(blk)
    for _n, blk in T2.DISCUSSION:
        body_texts += list(blk)
    body_texts += list(T2.CONCLUSION)
    cite_map, cite_order = citation_map(body_texts)
    ref_by_old = {r["n"]: r for r in refs}
    refs = [ref_by_old[o] for o in cite_order if o in ref_by_old]
    for i, r in enumerate(refs, 1):
        r["n"] = i
    print(f"citations renumbered: {len(refs)} references, first 5 in text: {cite_order[:5]}")

    def emit(text, **kw):
        text = apply_citation_map(text, cite_map)
        add_para(doc, text, **kw)
        for m in re.findall(r"Figure\s+(\d+)", text):
            k = f"Figure {m}"
            if k not in placed_f and k in FIG_DEFS:
                placed_f.add(k)
                fn, w = FIG_DEFS[k]
                add_figure(doc, os.path.join(fdir, fn), k + ".", leg_map.get(k, ""), width=w)
        for m in re.findall(r"Table\s+(\d+)", text):
            k = f"Table {m}"
            if k not in placed_t and k in TAB_DEFS:
                placed_t.add(k)
                df, cap, note = TAB_DEFS[k]
                add_table(doc, df, cap, note, fontsize=6.9)

    # ---------------- title block
    add_para(doc, "Medicine (Baltimore) — Original Research Article", italic=True, size=9.5, align="center")
    if version_label:
        add_para(doc, version_label, italic=True, size=9.5, align="center", bold=True)
    p = doc.add_paragraph(); r = p.add_run(T1.TITLE); r.bold = True; r.font.size = Pt(14)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(3)
    add_para(doc, T1.AUTHORS, align="center", size=10.5)
    add_para(doc, T1.AFFILIATIONS, align="center", size=9)
    add_para(doc, "Running head: " + T1.RUNNING_HEAD, size=9)
    add_para(doc, "Abbreviations: AUC, area under the receiver-operating-characteristic curve; CI, "
                  "confidence interval; DEG, differentially expressed gene; DCA, decision-curve analysis; "
                  "eQTL, expression quantitative trait locus; FDR, false-discovery rate; GEO, Gene Expression "
                  "Omnibus; GO, Gene Ontology; IVW, inverse-variance weighted; LASSO, least absolute shrinkage "
                  "and selection operator; MCC, maximal clique centrality; MR, Mendelian randomisation; NPV, "
                  "negative predictive value; OA, osteoarthritis; PPI, protein-protein interaction; PPV, "
                  "positive predictive value; SASP, senescence-associated secretory phenotype; SHAP, SHapley "
                  "Additive exPlanations; SRDEG, senescence-related differentially expressed gene; ssGSEA, "
                  "single-sample gene-set enrichment analysis; SVM, support vector machine; WGCNA, weighted "
                  "gene co-expression network analysis.", size=8.5)
    add_para(doc, "Correspondence: Fangwei Xue, MD, PhD, School of Clinical and Basic Medical Sciences, "
                  "Shandong First Medical University, Jinan, China. "
                  "E-mail: 4124640088@email.sdfmu.edu.cn. ORCID: [to be inserted].", size=9)
    add_para(doc, "Statistical consultation: the statistical analyses were designed and performed by "
                  "Yangjie Li and Haiyan Xue, who are authors of this work, and were reviewed by "
                  "Fangwei Xue.", size=9)
    n_words = len(" ".join(body_texts).split())
    n_abs = len(" ".join(T1.ABSTRACT.values()).split())
    n_supp = _n_supplementary()
    add_para(doc, f"Main text {n_words:,} words; {len(TAB_DEFS)} tables; {len(FIG_DEFS)} figures; "
                  f"{len(refs)} references; {n_supp} supplementary tables. Abstract {n_abs} words. No "
                  f"conflicts of interest. No funding. All data are public (GEO, eQTLGen, FinnGen); no "
                  f"ethical approval required.", size=9)

    # ---------------- abstract
    add_heading(doc, "Abstract")
    for k, v in T1.ABSTRACT.items():
        p = doc.add_paragraph(); r = p.add_run(k + ": "); r.bold = True
        p.add_run(v); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.space_after = Pt(2)
    p = doc.add_paragraph(); r = p.add_run("Keywords: "); r.bold = True
    p.add_run("; ".join(T1.KEYWORDS) + ".")
    p.paragraph_format.space_after = Pt(2)

    add_heading(doc, "Introduction")
    for para in T1.INTRODUCTION:
        emit(para, align="justify")

    add_heading(doc, "2. Methods")
    for i, (name, blocks) in enumerate(T1.METHODS, 1):
        add_heading(doc, name, level=2)
        for b in blocks:
            emit(b, align="justify")

    add_heading(doc, "Results")
    for i, (name, blocks) in enumerate(T2.RESULTS, 1):
        add_heading(doc, name, level=2)
        for b in blocks:
            emit(b, align="justify")

    add_heading(doc, "Discussion")
    for i, (name, blocks) in enumerate(T2.DISCUSSION, 1):
        add_heading(doc, name, level=2)
        for b in blocks:
            emit(b, align="justify")

    add_heading(doc, "Conclusion")
    for b in T2.CONCLUSION:
        emit(b, align="justify")

    # safety net: anything never cited still gets placed, in order
    for k in FIG_DEFS:
        if k not in placed_f:
            print("  note: placing uncited", k)
            fn, w = FIG_DEFS[k]
            add_figure(doc, os.path.join(fdir, fn), k + ".", leg_map.get(k, ""), width=w)
    for k in TAB_DEFS:
        if k not in placed_t:
            print("  note: placing uncited", k)
            df, cap, note = TAB_DEFS[k]
            add_table(doc, df, cap, note, fontsize=6.9)

    add_heading(doc, "Declarations")
    for name, body in T2.STATEMENTS:
        p = doc.add_paragraph(); r = p.add_run(name + ": "); r.bold = True
        p.add_run(body); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.space_after = Pt(2)

    add_heading(doc, "References")
    for r in refs:
        p = doc.add_paragraph()
        run = p.add_run(f"{r['n']}. {r['text']}")
        run.font.size = Pt(7.5)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 0.88
        p.paragraph_format.left_indent = Inches(0.26)
        p.paragraph_format.first_line_indent = Inches(-0.26)

    save_docx(doc, os.path.join(BASE, out_name))
    print("saved", out_name, "| figures placed:", len(placed_f), "| tables placed:", len(placed_t))

    # ---------------- cover letter
    cl = Document(); set_base_style(cl)
    add_para(cl, "[Date]", size=10)
    add_para(cl, "The Editor-in-Chief")
    add_para(cl, "Medicine (Baltimore)")
    add_para(cl, "")
    add_para(cl, "Dear Editor,", size=11)
    add_para(cl, "We are pleased to submit our original research article entitled "
                 f"\u201c{T1.TITLE}\u201d for consideration for publication in Medicine (Baltimore).",
             align="justify")
    add_para(cl, "Osteoarthritis is a leading cause of disability worldwide and no disease-modifying therapy "
                 "exists. Cellular senescence is an established driver of joint degeneration, yet the field "
                 "has largely treated the senescence programme as a single quantity that increases with "
                 "disease. Using exclusively real, publicly available human data from five bulk knee cohorts "
                 "and two single-cell cohorts, we show that the programme is in fact decoupled in end-stage "
                 "osteoarthritis cartilage: the p53/p21-GADD45 checkpoint and AP-1 stress-response arms are "
                 "suppressed while cell-cycle re-entry and senescence-associated secretory output are "
                 "induced. We derive an eight-gene signature from the suppressed arm using a three-algorithm "
                 "consensus, benchmark fourteen classifiers under nested cross-validation, repeat feature "
                 "selection inside every training fold to exclude optimistic bias, and validate the frozen "
                 "signature in four independent cohorts spanning two joint tissues and two expression "
                 "platforms. The signature localises to homeostatic chondrocytes in both single-cell atlases, "
                 "and drug-repurposing analysis nominates candidate senescence-directed agents. We then test "
                 "the signature causally: two-sample Mendelian randomisation with eQTLGen cis-eQTL "
                 "instruments against four FinnGen osteoarthritis phenotypes yields 32 estimates with strong "
                 "instruments, of which one survives false-discovery correction, but formal colocalisation "
                 "shows that no locus shares a causal variant. We report this because it defines what the "
                 "signature is: a marker of the osteoarthritic state rather than a causal driver. To our "
                 "knowledge this is the first multi-cohort study to report a decoupled rather than uniformly "
                 "increased senescence programme in osteoarthritis, to replicate the cellular localisation "
                 "in an independent single-cell cohort under donor-controlled testing, and to report "
                 "external cohorts in which the signature did not validate alongside those in which it did.",
             align="justify")
    add_para(cl, "We believe the work is well suited to Medicine because it combines a clinically relevant "
                 "orthopaedic question with a rigorous, transparent and fully reproducible analytical design, "
                 "and because it provides both a mechanistically interpretable biomarker signature and "
                 "candidate therapeutic directions. The manuscript is original, has not been published "
                 "elsewhere, and is not under consideration by another journal. All authors have read and "
                 "approved the submission and declare no conflicts of interest. No funding was received. All "
                 "analysed data are publicly available and no ethical approval was required.", align="justify")
    add_para(cl, "We suggest the following reviewers, who work in osteoarthritis genomics and senescence "
                 "biology: [name and institution]; [name and institution]; [name and institution]. We request "
                 "that the following individuals be excluded from review: none.", align="justify")
    add_para(cl, "Thank you for considering our manuscript. We look forward to your response.", align="justify")
    add_para(cl, "")
    add_para(cl, "Yours sincerely,")
    add_para(cl, "Fangwei Xue, MD, PhD")
    add_para(cl, "On behalf of all authors")
    save_docx(cl, os.path.join(BASE, "Cover_letter.docx"))
    print("saved cover letter docx")
    return refs


if __name__ == "__main__":
    if "--v1" in sys.argv:
        build(out_name="Osteoarthritis_senescence_manuscript_v1.docx",
              fig_dir=os.path.join(BASE, "figures_v1"), legends=V1_LEGENDS,
              version_label="VERSION v1 — earlier uniform figure set (for comparison)")
    else:
        build(version_label="VERSION v2 — redesigned figure set (current)")
